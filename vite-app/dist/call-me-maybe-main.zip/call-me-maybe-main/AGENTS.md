# AGENTS.md

Rules for AI coding agents in call-me-maybe, a Playwright job-application
autofiller. Read [ARCHITECTURE.md](ARCHITECTURE.md) first, and its Invariants
section before touching `filler.py` or any adapter.

## Commands

```bash
python fill.py [--stealth]   # fill the application tabs open in the debug browser
python scrape.py              # collect LinkedIn search results into jobs.db (never applies)
python view.py                # browse/delete/mark applied; serves a page over jobs.db
python -m pytest tests -q     # keep green; covers the matcher and the job store
```

## Rules

- Put robustness in `filler.py`; keep adapters thin (see the design rule in
  ARCHITECTURE.md).
- Matching bug: add a failing test in `tests/test_filler.py` first, then fix.
  The matcher is the part most likely to regress.
- New field hint: check it isn't swallowed by an earlier hint (first match
  wins) and add a test for it.
- Debugging a form: set `debug_fields = true` in the `[fill]` section of `config.toml` and read the
  `[field]` lines.
- `config.toml` holds real personal data and a password (`[profile]`, `[eeo]`).
  Never print it, copy it into docs or tests, or stage it.
- Job data goes through `jobstore.py` only. Deleting is soft; don't hard-delete
  rows (see ARCHITECTURE.md, Invariants).
- Settings live in `config.toml`, one section per script; add a key to
  `config.example.toml` too.
- Keep `submit_application = false` (`[fill]` in config.toml) when running against real postings unless
  the user asks otherwise.
