# TODO

## Bugs

- Ashby: email not filled, EEO not answered.
  https://jobs.ashbyhq.com/spoton/38168423-ca06-4e9e-8e84-6d6eb8269404/application
- Greenhouse: education section not filled. Education hints were added to
  `filler.py`; not re-tested on this posting yet.
  https://job-boards.greenhouse.io/srsacquiom/jobs/5167539007?gh_src=734zx9sh7us
- Workday (Accenture): Application Questions has three required dropdowns
  with no hint yet: on-site requirements, interview accommodations, AI
  analysis consent.
  https://accenture.wd103.myworkdayjobs.com/AccentureCareers/job/NC---Charlotte/XMLNAME---Sr-Full-Stack-Frontend-Developer-6527018_14802039
- Workday (Sedgwick): first Create Account click once sent no request; cause
  unknown, retried for now. See
  [the postmortem](docs/postmortems/2026-10-22-workday-create-account-failures.md).

## Test URLs

- Greenhouse, Forward Deployed AI Engineer, West:
  https://job-boards.greenhouse.io/arizeai/jobs/6030953004?gh_src=bm4xoqj24us&t=3253f722teu
- Greenhouse, Senior Software Engineer (PHP):
  https://job-boards.greenhouse.io/nmi/jobs/5262856008?gh_src=f748c6f98us
- Ashby: https://jobs.ashbyhq.com/originhq/b498f9f5-d4ec-4948-be68-6019f309f738
- Workday (Accenture), job board to pick live postings from:
  https://accenture.wd103.myworkdayjobs.com/en-US/AccentureCareers
- Jobvite (generic adapter): https://jobs.jobvite.com/
- Rippling (generic adapter):
  https://ats.rippling.com/sparq/jobs/a310d517-aa11-4a5b-96ae-7b1488989335?jobSite=LinkedIn
