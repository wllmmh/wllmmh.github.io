"""SQLite store of scraped jobs, shared by scrape.py (adds jobs, checks for
duplicates) and view.py (lists, marks applied, deletes).

One row per job_id. Deleting is soft: the row keeps its data and gets a
deleted_at, so the scraper still treats the job as already seen.
"""
import csv
import glob
import json
import os
import sqlite3
from datetime import datetime

_ROOT = os.path.dirname(os.path.abspath(__file__))
RESULTS_DIR = os.path.join(_ROOT, "strict-search-results")
DB_PATH = os.path.join(RESULTS_DIR, "jobs.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS jobs (
    job_id     TEXT PRIMARY KEY,
    title      TEXT,
    location   TEXT,
    work_type  TEXT,
    company    TEXT,
    logo       TEXT,
    hours_ago  REAL,
    applicants TEXT,
    easy_apply INTEGER,
    applied    INTEGER NOT NULL DEFAULT 0,
    scraped_at TEXT,
    source     TEXT,
    deleted_at TEXT,
    dedupe_key TEXT
);
CREATE INDEX IF NOT EXISTS jobs_dedupe_key ON jobs (dedupe_key);
"""

# What list_jobs returns and add_job takes (deleted_at and dedupe_key are the store's own).
FIELDS = ["job_id", "title", "location", "work_type", "company", "logo", "hours_ago",
          "applicants", "easy_apply", "applied", "scraped_at", "source"]


def job_key(company, title):
    """Same employer + title counts as the same job, even under another jobId."""
    return f"{company.strip().lower()}\x1f{title.strip().lower()}"


def _key(job):
    """job_key, or None when the employer or title is missing (nothing to match on)."""
    company, title = (job.get("company") or ""), (job.get("title") or "")
    return job_key(company, title) if company.strip() and title.strip() else None


def connect(path=None):
    """Open the store, creating it on first use (importing any results CSVs beside it).
    WAL lets view.py read while scrape.py writes; the timeout waits out a writer instead of failing."""
    path = path or DB_PATH
    os.makedirs(os.path.dirname(path), exist_ok=True)
    conn = sqlite3.connect(path, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    fresh = conn.execute("SELECT 1 FROM sqlite_master WHERE name = 'jobs'").fetchone() is None
    conn.executescript(SCHEMA)
    if fresh:
        import_csvs(conn, os.path.dirname(path))
    return conn


def find_duplicate(conn, job_id, company="", title=""):
    """Why this job counts as already seen (its id, or its employer + title, is in the
    store, deleted or not), or None. Deleted rows count so the scraper never re-saves them."""
    row = conn.execute("SELECT deleted_at FROM jobs WHERE job_id = ?", (job_id,)).fetchone()
    if row:
        return "jobId deleted in the results page" if row["deleted_at"] else "jobId already saved"
    key = _key({"company": company, "title": title})
    if key:
        # Prefer a live match so the reason isn't "deleted" when the job is also still listed.
        row = conn.execute("SELECT deleted_at FROM jobs WHERE dedupe_key = ?"
                           " ORDER BY deleted_at IS NOT NULL LIMIT 1", (key,)).fetchone()
        if row:
            return ("same employer + title deleted in the results page" if row["deleted_at"]
                    else "same employer + title already saved")
    return None


def add_job(conn, job):
    """Insert a scraped job (a dict with FIELDS). False if its id is already in the store."""
    with conn:
        cur = conn.execute(
            f"INSERT OR IGNORE INTO jobs ({', '.join(FIELDS)}, dedupe_key)"
            f" VALUES ({', '.join(':' + f for f in FIELDS)}, :dedupe_key)",
            {**job, "dedupe_key": _key(job)})
    return cur.rowcount == 1


def list_jobs(conn, deleted=False):
    """Live jobs, or with deleted=True the soft-deleted ones (plus deleted_at)."""
    cols = ", ".join(FIELDS + ["deleted_at"])
    where = "deleted_at IS NOT NULL" if deleted else "deleted_at IS NULL"
    return [dict(r) for r in conn.execute(f"SELECT {cols} FROM jobs WHERE {where} ORDER BY job_id")]


def delete_job(conn, job_id):
    """Soft-delete. False if there's no such live job."""
    with conn:
        cur = conn.execute("UPDATE jobs SET deleted_at = ? WHERE job_id = ? AND deleted_at IS NULL",
                           (datetime.now().isoformat(timespec="seconds"), job_id))
    return cur.rowcount == 1


def restore_job(conn, job_id):
    """Undo a delete. False if there's no such deleted job. An id-only row (imported from
    deleted.json) has no details to show, so it's dropped and the scraper may find it again."""
    with conn:
        cur = conn.execute("UPDATE jobs SET deleted_at = NULL WHERE job_id = ? AND deleted_at IS NOT NULL"
                           " AND title IS NOT NULL", (job_id,))
        if not cur.rowcount:
            cur = conn.execute("DELETE FROM jobs WHERE job_id = ? AND deleted_at IS NOT NULL", (job_id,))
    return cur.rowcount == 1


def set_applied(conn, job_id, applied):
    with conn:
        cur = conn.execute("UPDATE jobs SET applied = ? WHERE job_id = ? AND deleted_at IS NULL",
                           (int(applied), job_id))
    return cur.rowcount == 1


def _from_csv(r):
    """A results-CSV row (all strings) as a FIELDS dict."""
    def flag(v):
        return {"true": 1, "false": 0}.get(v)
    return {
        "job_id": r["job_id"], "title": r.get("title"), "location": r.get("location"),
        "work_type": r.get("work_type"), "company": r.get("company"), "logo": r.get("logo"),
        "hours_ago": float(r["hours_ago"]) if r.get("hours_ago") else None,
        "applicants": r.get("applicants") or None, "easy_apply": flag(r.get("easy_apply")),
        "applied": flag(r.get("applied")) or 0, "scraped_at": r.get("scraped_at"), "source": r["source"],
    }


def import_csvs(conn, directory):
    """Load per-run results CSVs and a deleted.json ({job_id: deleted_at}) from directory.
    Safe to repeat: jobs already in the store are left alone."""
    newest = {}
    for path in glob.glob(os.path.join(directory, "*.csv")):
        source = os.path.splitext(os.path.basename(path))[0]
        with open(path, encoding="utf-8", newline="") as f:
            rows = [{**r, "source": source} for r in csv.DictReader(f) if r.get("job_id")]
        for r in rows:
            newest.setdefault(r["job_id"], []).append(_from_csv(r))
    for versions in newest.values():
        versions.sort(key=lambda j: j["scraped_at"] or "")
        job = versions[-1]   # the newest scrape of a repeated job wins
        job["applied"] = int(any(v["applied"] for v in versions))   # applied in any of them sticks
        add_job(conn, job)
    try:
        with open(os.path.join(directory, "deleted.json"), encoding="utf-8") as f:
            deleted = json.load(f)
    except FileNotFoundError:
        deleted = {}
    with conn:
        for job_id, at in deleted.items():
            # The job may have no CSV row (deleted.json can outlive it), leaving just the id.
            conn.execute("INSERT OR IGNORE INTO jobs (job_id) VALUES (?)", (job_id,))
            conn.execute("UPDATE jobs SET deleted_at = ? WHERE job_id = ?", (at, job_id))
