"""Applications log + dedupe.

Records every application attempt to applications/log.csv so you never apply
to the same job twice and have a paper trail of what was sent.
"""

import csv
import os
from datetime import datetime

LOG_DIR = "applications"
LOG_PATH = os.path.join(LOG_DIR, "log.csv")

FIELDS = ["timestamp", "url", "board", "company", "title", "resume", "status"]


def _ensure_log():
    os.makedirs(LOG_DIR, exist_ok=True)
    if not os.path.exists(LOG_PATH):
        with open(LOG_PATH, "w", newline="", encoding="utf-8") as f:
            csv.DictWriter(f, fieldnames=FIELDS).writeheader()


def already_applied(url: str) -> bool:
    """True if `url` was previously submitted (status == 'submitted')."""
    if not os.path.exists(LOG_PATH):
        return False
    with open(LOG_PATH, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if row.get("url") == url and row.get("status") == "submitted":
                return True
    return False


def record(url, board="", company="", title="", resume="", status="filled"):
    """Append a row to the log.

    status is typically one of: filled, submitted, skipped, error.
    """
    _ensure_log()
    with open(LOG_PATH, "a", newline="", encoding="utf-8") as f:
        csv.DictWriter(f, fieldnames=FIELDS).writerow({
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "url": url,
            "board": board,
            "company": company,
            "title": title,
            "resume": resume,
            "status": status,
        })
