"""Heuristic form field filler.

Given a Playwright page (or scope locator), find input/select/textarea
elements, work out what each one is asking for from its label text and HTML
attributes, and fill it from the user's config. Fields it can't confidently
map are returned as "unknown" so the caller can pause for manual entry or
just log them.
"""

import asyncio
import difflib
import re

import config
import resumes

# Map a canonical field name -> ordered list of substrings that, if found in
# a field's label/name/placeholder, identify it. First match wins, so order
# more specific keys before generic ones.
FIELD_HINTS = [
    # Link fields first: "Github Username" contains "name" and would otherwise
    # be swallowed by full_name.
    ("linkedin", ["linkedin"]),
    ("github", ["github"]),
    ("twitter", ["twitter"]),
    ("website", ["website", "portfolio", "personal site", "url"]),
    # Before the name hints: Workday's id "schoolName" holds "name" and "lname".
    ("school", ["school", "university attended", "college attended"]),
    ("first_name", ["first name", "firstname", "given name", "fname"]),
    ("last_name", ["last name", "lastname", "family name", "surname", "lname"]),
    ("full_name", ["full name", "your name", "name"]),
    ("preferred_contact_method", ["preferred contact", "contact method"]),
    ("email", ["email", "e-mail"]),
    ("country", ["phone_country_code", "country code", "phone code", "dial code",
                 "dialing code"]),
    # Before phone: Workday's "Phone Extension" would get the whole number.
    ("phone_extension", ["phone extension", "extension", "phone ext"]),
    ("phone", ["phone", "mobile", "telephone", "cell"]),
    # Residence before state: "...hire into the United States. Confirm your
    # current residence" has no "country" in it.
    ("country", ["country_code", "country", "residence", "where do you live",
                 "where do you currently live", "currently live in"]),
    ("state", ["state", "province", "region"]),
    ("city", ["city"]),
    # Before the address hints: Workday's id "addressSection_postalCode" has "address".
    ("postal_code", ["postal code", "postalcode", "postal_code", "zip"]),
    # Street address before location: "Address Line 1" must not get "City, State".
    ("address_line2", ["address line 2", "address2"]),
    ("street_address", ["address line", "street address", "address1", "street"]),
    ("location", ["location", "where are you based", "where you are located",
                  "where are you located", "address"]),
    ("current_company", ["current company", "employer", "company"]),
    ("current_title", ["current title", "job title", "current role"]),
    ("how_heard", ["how did you hear", "referral", "source"]),
    ("base_salary", ["base salary", "salary", "compensation expectation",
                     "compensation expectations", "desired compensation",
                     "expected salary", "salary expectation"]),
    # Education section: school/degree/discipline + start/end month/year.
    ("education_end_month", ["end date month", "end month"]),
    ("education_end_year", ["end date year", "end year"]),
    ("education_start_month", ["start date month", "start month"]),
    ("education_start_year", ["start date year", "start year"]),
    ("discipline", ["discipline", "field of study", "major"]),
    ("degree", ["degree"]),
]

# EEO / demographic field detection -> key in config.EEO
EEO_HINTS = [
    ("background_check", ["background check"]),
    ("hispanic_latino", ["hispanic", "latino"]),
    ("race", ["race"]),
    ("ethnicity", ["ethnicity", "ethnic"]),
    # More specific than "gender" -- must come first so "sexual orientation" and
    # "transgender" don't get swallowed by the gender hint (they contain "sex"/"gender").
    ("sexual_orientation", ["sexual orientation", "orientation"]),
    ("transgender", ["transgender", "trans "]),
    ("gender", ["gender identity", "gender", "what is your sex"]),
    ("veteran_status", ["veteran"]),
    ("disability_status", ["disability", "disabled"]),
    # "eligible to work...WITHOUT sponsorship" is asking whether you need sponsorship,
    # not whether you're authorized. Must come before authorized_to_work so the more
    # specific phrase wins.
    ("require_sponsorship", ["without sponsorship", "sponsorship", "sponsor", "visa"]),
    ("authorized_to_work", ["authorized to work", "work authorization",
                            "legally authorized", "eligible to work",
                            "authorized to work in the us", "authorized to work in the united states"]),
    ("pronouns", ["pronoun", "preferred pronoun"]),
]


# Phrases that signal a "are you based in / available in <region/timezone>?" question.
_LOCATION_AVAIL_SIGNALS = (
    "based in", "located in", "located within", "live in", "reside in",
    "work from", "able to work", "willing to work", "time zone", "timezone",
    "work hours", "working hours", "overlap with",
)


def location_availability_answer(text, profile=None):
    """Answer a 'are you based in / available in <region/timezone>?' question
    from the user's profile, or report their timezone if it's an open question.

    Works regardless of how the form collects the answer (Yes/No select, radio,
    or free-text) -- it returns a plain string and the caller routes it to the
    right widget. Returns the answer string, or None if this isn't such a question.

    Logic:
      - If the question names a region/timezone the user matches
        (profile["based_in_regions"]) -> "Yes".
      - If it names one they don't match -> "No".
      - If it's an open "what is your timezone?" question -> profile["timezone"].
    """
    profile_data = profile if profile is not None else config.PROFILE
    low = (text or "").lower()

    if not any(sig in low for sig in _LOCATION_AVAIL_SIGNALS):
        return None

    regions = [r.lower() for r in profile_data.get("based_in_regions", [])]

    # Open-ended "what timezone are you in?" -> answer with the timezone itself.
    asks_which = any(w in low for w in ("what time", "which time", "what is your time",
                                        "your timezone", "your time zone"))
    names_region = any(r in low for r in regions) if regions else False

    if asks_which and not _is_yesno_phrasing(low):
        return profile_data.get("timezone")

    # Yes/No style: does the named region match one of ours?
    if names_region:
        return "Yes"
    # Question names some region/timezone, but not one of ours -> No.
    if any(tok in low for tok in ("zone", "based in", "located", "live in",
                                  "reside", "area", "region")):
        return "No"
    return profile_data.get("timezone")


def _is_yesno_phrasing(low):
    """Heuristic: does the question read as a yes/no ('are you...', 'do you...')?"""
    return low.strip().startswith((
        "are you", "do you", "will you", "can you", "would you", "is your"))


def _is_salary_label(text):
    """True if the field label is asking for salary/compensation."""
    low = (text or "").lower()
    salary_subs = next((subs for key, subs in FIELD_HINTS if key == "base_salary"), [])
    return any(s in low for s in salary_subs)


# Phrases that indicate a sponsorship question is phrased as "can you work
# WITHOUT sponsorship?" (inverse of "do you need sponsorship?"). When the
# question uses this framing, the answer must be flipped: if we don't need
# sponsorship (require_sponsorship="No"), we answer "Yes" to "without sponsorship".
# Up to three words may sit between ("without requiring visa sponsorship").
_INVERSE_SPONSORSHIP = re.compile(
    r"\bwithout (?:\S+ ){0,3}sponsor"
    r"|\bno (?:\S+ ){0,2}sponsorship"
    r"|\bnot (?:\S+ ){0,3}sponsorship")

def _flip_yesno(value):
    """Invert a yes/no value (bool or string)."""
    if isinstance(value, bool):
        return not value
    return {"yes": "No", "no": "Yes"}.get(str(value).lower(), value)


# Text of the resume being uploaded (fill.apply_to sets it per job). Answers
# "have you worked with X?" -- Yes only if X is on it.
RESUME_TEXT = ""

# "Have you worked with React in a production environment?", "Do you have
# experience with TypeScript?" -> captures the technology.
_SKILL_QUESTION = re.compile(
    r"(?:have you (?:ever )?(?:worked|built|developed|shipped|used)"
    r"|do you have (?:any |professional |hands-on )?experience"
    r"|are you (?:experienced|proficient|familiar))"
    r"(?: with| in| using| on)? (.+?)"
    r"(?: in (?:a |an )?(?:production|professional|commercial)\b.*| professionally.*| (?:before|previously|in the past)\b.*|[?,(*]|\.(?:\s|$)|$)",
    re.I)


def skill_question_answer(text, resume_text=None):
    """Return "Yes" if the skill a question asks about is on the resume, else None
    (left for the user rather than answering No for them). "X or Y" counts if
    either is there."""
    resume_text = (RESUME_TEXT if resume_text is None else resume_text).lower()
    m = _SKILL_QUESTION.search(text or "")
    if not m or not resume_text:
        return None
    for skill in re.split(r",|/| or | and ", m[1].lower()):
        skill = skill.strip()
        if skill and re.search(rf"(?<![a-z0-9]){re.escape(skill)}(?![a-z0-9])", resume_text):
            return "Yes"
    return None


# "Why do you want to work here / for us / at <company>?" -> the
# why_interested_default answer (config.toml), not the cover letter.
_WHY_INTERESTED = re.compile(
    r"why (?:do|would) you (?:want|like|wish) to (?:work|join)"
    r"|why (?:are you )?interested in (?:working|joining)"
    r"|why (?:us|this company|our company|join)\b"
    r"|what (?:interests|excites|draws|attracts) you (?:about|to)"
    r"|(?:interest|excite|draw|attract)s? you (?:about|to) (?:this|our|the) (?:role|company|team|position|opportunity)",
    re.I)


def is_why_interested(text, company=""):
    low = (text or "").lower()
    if _WHY_INTERESTED.search(low):
        return True
    return bool(company) and re.search(rf"\bwhy {re.escape(company.lower())}\b", low) is not None


def why_interested_text(company=""):
    """The why_interested_default answer with {company} filled in. Single line
    breaks are unwrapped (it's written hard-wrapped in config.toml); blank
    lines stay paragraph breaks."""
    text = getattr(config, "WHY_INTERESTED_DEFAULT", "").strip()
    text = re.sub(r"(?<!\n)\n(?!\n)", " ", text)
    return text.replace("{company}", company or "your team")


# "Have you previously worked for <company> as an employee or contractor?",
# "Are you a current or former employee of X?", "...worked for us before?"
_PREVIOUS_WORKER = re.compile(
    r"\b(?:previously|ever|before|formerly|in the past)\b.{0,30}\b(?:worked|been employed|employed)"
    r" (?:for|by|at)\b"
    r"|\b(?:current or former|former) (?:employee|contractor|worker)"
    r"|\bworked (?:for|at) (?:us|our company|this company)\b",
    re.I)


def previous_worker_answer(text, company=""):
    """Return "Yes" if the question asks whether you've worked for this employer and
    it's in config previous_employers, "No" for any other employer; None if
    it isn't that question."""
    if not _PREVIOUS_WORKER.search(text or ""):
        return None
    low = (company or "").lower()
    worked = any(e.lower() in low for e in getattr(config, "PREVIOUS_EMPLOYERS", []) if e)
    return "Yes" if worked else "No"


# Common screening questions -> key in config.toml [screening]. Matched on
# phrases specific enough not to need a "?" or a word order.
SCREENING_HINTS = [
    ("government_employee", ["employee of a u.s. federal", "government employment",
                             "employed by a government", "government employee"]),
    ("debarred", ["debarred", "debarment"]),
    ("sanctioned_country_citizen", ["iran, cuba", "cuba, iran", "north korea or syria",
                                    "sanctioned countr", "embargoed countr"]),
    ("future_job_contact", ["regarding future positions", "future openings",
                            "future job opportunities", "future opportunities"]),
    ("of_legal_age", ["18 years of age", "18 years or older", "18 or older", "age of 18",
                      "minimum legal age", "legal working age"]),
    ("restrictive_agreement", ["non-compete", "noncompete", "non-solicit", "nonsolicit",
                               "restrictive covenant"]),
]

_ACK_STATEMENT = re.compile(r"(?:^|\|)\s*i (?:understand|acknowledge|attest|confirm|certify)\b"
                            r"|\bi have read and (?:consent|agree|accept|acknowledge|understand)\b")
_ACK_SELECT_YES = re.compile(r"select \W?yes\W? if you (?:acknowledge|agree|understand)")

# Abbreviations that must start a word: "lname" is inside "schoolName".
_WORD_START_HINTS = {"fname", "lname"}


def _hint_in(sub, text):
    if sub in _WORD_START_HINTS:
        return re.search(rf"(?<![a-z]){sub}", text) is not None
    return sub in text


# FIELD_HINTS are for short field labels; in long question text their
# words are incidental ("federal, state, or local", "already addressed").
_FIELD_HINT_MAX_LEN = 200


# A work-history entry's location ("workExperience-3--location") is where that
# job was, never your home location.
_WORK_HISTORY = re.compile(r"workexperience|work location|job location|employer location")
_HOME_LOCATION_SOURCES = {"profile:location", "profile:city", "profile:state",
                          "profile:country", "profile:postal_code", "profile:street_address"}
# Filled only when the form requires them (required attribute, or a "*" in
# the visible label): optional address details and field of study.
_ONLY_IF_REQUIRED = {"profile:discipline", "profile:street_address", "profile:postal_code"}


def leave_for_user(source, label, required):
    """True for fields the filler must not fill even though a hint matched:
    a work-history location (it isn't your home location), and optional
    field of study / address details. Required work-history locations are
    left for you."""
    low = (label or "").lower()
    if source in _HOME_LOCATION_SOURCES and _WORK_HISTORY.search(low):
        return True
    return source in _ONLY_IF_REQUIRED and not (required or "*" in low)


def _hint_value(text, company=""):
    """Return (source, config_value) for a label, or (None, None). `company`
    is the employer applied to (for "have you worked for us before?")."""
    low = (text or "").lower()
    # Statements to agree to ("I understand that... I-9", "I attest...",
    # "select yes if you acknowledge") -- first: their legalese mentions
    # visas, states, addresses.
    if (_ACK_STATEMENT.search(low) and "?" not in low) or _ACK_SELECT_YES.search(low):
        return "acknowledgment", "Yes"
    # Screening questions: before EEO/FIELD_HINTS ("U.S. Armed Services",
    # "federal, state, or local").
    for key, subs in SCREENING_HINTS:
        if any(sub in low for sub in subs):
            value = getattr(config, "SCREENING", {}).get(key)
            if value is not None:
                return "screening", value
    # "Unrestricted right to work" is No on any visa: authorized AND no
    # sponsorship needed. Before EEO, whose "visa" would make it sponsorship.
    if "unrestricted right to work" in low or "unrestricted work authorization" in low:
        eeo = config.EEO
        authorized = str(eeo.get("authorized_to_work")).lower() in ("yes", "true")
        sponsored = str(eeo.get("require_sponsorship")).lower() in ("yes", "true")
        return "eeo", "Yes" if authorized and not sponsored else "No"
    # EEO questions are checked first -- they're more specific.
    for key, subs in EEO_HINTS:
        if any(s in low for s in subs):
            value = config.EEO.get(key)
            # Sponsorship questions can be phrased as "do you need sponsorship?"
            # (answer our require_sponsorship value directly) OR as "can you work
            # without sponsorship?" (answer is the logical inverse).
            if key == "require_sponsorship" and value is not None:
                if _INVERSE_SPONSORSHIP.search(low):
                    value = _flip_yesno(value)
                    # "Authorized to work ... without sponsorship?" also needs
                    # the authorization itself.
                    auth = config.EEO.get("authorized_to_work")
                    if any(s in low for s in ("authorized", "eligible", "legally")) \
                            and auth is not None and str(auth).lower() in ("no", "false"):
                        value = "No"
            if isinstance(value, bool):
                value = "Yes" if value else "No"
            return "eeo", value
    # After EEO ("...ever require sponsorship to work") and before FIELD_HINTS
    # ("...for this company" would be current_company).
    previous = previous_worker_answer(text, company)
    if previous is not None:
        return "previous_worker", previous
    # Years of experience: before FIELD_HINTS so "...at a company" isn't swallowed by
    # current_company. Needs "experience" too, so "18 years of age" doesn't match.
    if "yoe" in low or ("year" in low and "experience" in low):
        value = config.PROFILE.get("years_of_experience")
        # "Do you have 5+ years...?" asks a threshold, not the number.
        m = re.search(r"(\d+)\s*\+?\s*(?:or more\s+)?years?", low)
        if m and value is not None and "how many" not in low:
            value = "Yes" if int(value) >= int(m[1]) else "No"
        return "profile:years_of_experience", value
    # Skill questions: before FIELD_HINTS so "...with Salesforce at a company"
    # isn't swallowed by current_company.
    skill = skill_question_answer(text)
    if skill is not None:
        return "skill", skill
    # "United States" would hit the "state" hint.
    low_fields = low.replace("united states", "us")
    if len(low_fields) > _FIELD_HINT_MAX_LEN:
        low_fields = ""
    for key, subs in FIELD_HINTS:
        if any(_hint_in(sub, low_fields) for sub in subs):
            p = config.PROFILE
            if key == "full_name":
                value = f"{p.get('first_name', '')} {p.get('last_name', '')}".strip()
            elif key == "location":
                value = f"{p.get('city', '')}, {p.get('state', '')}".strip(", ")
            elif key == "linkedin" and p.get(key):
                # Some forms reject linkedin.com/... without the www.
                value = re.sub(r"^(?:https?://)?(?:www\.)?linkedin\.com",
                               "https://www.linkedin.com", p[key].strip(), flags=re.I)
            else:
                value = p.get(key)
            return f"profile:{key}", value
    # Location/timezone availability questions ("are you based in PST?" etc.)
    loc_answer = location_availability_answer(text)
    if loc_answer is not None:
        return "location_avail", loc_answer
    return None, None


# JS: is `e` something a person can actually see? Scrolled into view, it
# must be at least 2x2px, inside the viewport (bot traps are often parked
# off-screen, e.g. left:-9999px, where no scrolling reaches), and not
# display/visibility/opacity-hidden itself or through an ancestor.
_VISIBLE_TO_USER_FN = """function visibleToUser(e) {
    e.scrollIntoView({block: 'center', inline: 'nearest'});
    const r = e.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    if (r.bottom <= 0 || r.right <= 0 || r.top >= innerHeight || r.left >= innerWidth) return false;
    const opts = {checkOpacity: true, checkVisibilityCSS: true};
    if (e.checkVisibility(opts)) return true;
    // A fade-in (Workday's dropdowns) sits at opacity 0 while it can't run
    // (window not painted): finish animations above e and look again. A
    // static opacity:0 bot trap has none, so it stays invisible.
    for (const a of document.getAnimations()) {
        const t = a.effect && a.effect.target;
        if (t && t.contains(e)) a.finish();
    }
    return e.checkVisibility(opts);
}"""

# A form field worth filling: visible to the user, or for a styled
# checkbox/radio (input made invisible), its label is. Not "uncovered":
# some real inputs sit under their own value text (Ant Design selects).
_FIELD_VISIBLE_JS = """e => {
    """ + _VISIBLE_TO_USER_FN + """
    if (visibleToUser(e)) return true;
    const label = ['checkbox', 'radio'].includes(e.type) && ((e.labels && e.labels[0]) || e.closest('label'));
    return !!label && visibleToUser(label);
}"""

# Click from inside the page, only if a person could click it: visible to
# the user and not covered by another element at its centre.
_CLICK_VISIBLE_JS = """e => {
    """ + _VISIBLE_TO_USER_FN + """
    if (!visibleToUser(e)) return false;
    const r = e.getBoundingClientRect();
    const hit = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
    if (!hit || (hit !== e && !e.contains(hit) && !hit.contains(e))) return false;
    e.click();
    return true;
}"""


async def click_visible(target, settle_s=3.0):
    """Click `target` (Locator or ElementHandle) via element.click(), but only
    if it's visibly clickable (_CLICK_VISIBLE_JS); never hidden elements,
    which may be honeypots. Unlike a Playwright click, this works when the
    browser window isn't being painted. Retries for `settle_s`: a popup or a
    freshly loaded step (Workday's loading mask) can briefly cover it.
    Returns whether it clicked."""
    for attempt in range(max(1, int(settle_s / 0.25))):
        if attempt:
            await asyncio.sleep(0.25)
        try:
            if await target.evaluate(_CLICK_VISIBLE_JS):
                return True
        except Exception:
            pass
    return False


async def click_visible_or_label(target):
    """For styled checkboxes/radios whose real <input> is invisible: click the
    input if visible, else its visible <label>."""
    # One try for the input itself: a styled one stays invisible for good.
    if await click_visible(target, settle_s=0):
        return True
    try:
        label = (await target.evaluate_handle(
            "e => (e.labels && e.labels[0]) || e.closest('label')")).as_element()
    except Exception:
        return False
    return label is not None and await click_visible(label)


def is_honeypot(label):
    """Bot traps (Workday's "beecatcher": "Enter website. This input is for
    robots only..."). Filling one flags the application as a bot."""
    low = (label or "").lower()
    return "beecatcher" in low or "robots only" in low or "if you're human" in low


async def _describe(handle):
    """Build the searchable label text for an element from its attributes
    and any associated <label>."""
    parts = await handle.evaluate(
        """el => {
            const bits = [];
            for (const a of ['name','id','placeholder','aria-label','aria-labelledby','data-qa']) {
                const v = el.getAttribute(a);
                if (v) bits.push(v);
            }
            // aria-labelledby: resolve the referenced element's text
            const labelledBy = el.getAttribute('aria-labelledby');
            if (labelledBy) {
                for (const id of labelledBy.split(/\\s+/)) {
                    const ref = document.getElementById(id);
                    if (ref) bits.push(ref.innerText);
                }
            }
            // associated <label for=id> or wrapping <label>
            if (el.id) {
                const l = document.querySelector(`label[for="${el.id}"]`);
                if (l) bits.push(l.innerText);
            }
            const wrap = el.closest('label');
            if (wrap) bits.push(wrap.innerText);
            // Walk up the DOM up to 12 levels looking for:
            //   - a direct-child label/legend
            //   - any preceding sibling with visible text (Rippling puts question
            //     text in a sibling div/span/p above the input wrapper)
            let node = el.parentElement;
            for (let i = 0; i < 12 && node; i++, node = node.parentElement) {
                const lbl = node.querySelector(':scope > label, :scope > legend');
                if (lbl && lbl.innerText.trim()) { bits.push(lbl.innerText.trim()); break; }
                let prev = node.previousElementSibling;
                while (prev) {
                    const txt = prev.innerText && prev.innerText.trim();
                    if (txt && txt.length > 1 && txt.length < 200) {
                        bits.push(txt);
                        break;
                    }
                    prev = prev.previousElementSibling;
                }
                if (prev) break;
            }
            return bits.join(' | ');
        }"""
    )
    return parts or ""


async def fill_form(scope, job_text="", company="", skip_ids=(), page=None,
                    autocomplete_ids=(), job_description=""):
    """Fill every fillable field under `scope` (a Page or Locator).

    Returns a dict: {"filled": [labels], "unknown": [labels], "required_empty": [labels]}.
    Does NOT submit and does NOT upload resumes -- adapters handle those, since
    upload widgets are board-specific.
    skip_ids: iterable of element id strings to leave untouched.
    page: the top-level Page object; pass when scope is an iframe so autocomplete
    suggestions that render outside the iframe can still be found and clicked.
    autocomplete_ids: dict of {element_id: value} for React autocomplete widgets
    needing type-then-click-suggestion (rather than plain fill). Filled inline in
    DOM order like any other field, so order/presence never matters. Values are
    used directly, bypassing label matching (these fields often have no label).
    """
    skip_ids = set(skip_ids)
    autocomplete_ids = dict(autocomplete_ids)
    result = {"filled": [], "unknown": [], "required_empty": []}

    inputs = await scope.locator(
        "input:not([type=hidden]):not([type=submit]):not([type=button]):not([type=file]), "
        "textarea, select, "
        # Div/span comboboxes (e.g. Rippling custom dropdowns) that aren't backed
        # by a real <input> -- identified by role=combobox on a non-input element.
        "div[role=combobox], span[role=combobox]"
    ).all()

    for handle in inputs:
        # Off-screen / zero-size / transparent fields are skipped: they're
        # often honeypots, and a person couldn't fill them anyway.
        try:
            if not await handle.evaluate(_FIELD_VISIBLE_JS):
                continue
        except Exception:
            continue

        el_id = await handle.get_attribute("id") or ""
        if el_id in skip_ids:
            continue

        label = await _describe(handle)
        if is_honeypot(f"{label} {await handle.get_attribute('data-automation-id') or ''}"):
            continue
        tag = await handle.evaluate("el => el.tagName.toLowerCase()")
        input_type = (await handle.get_attribute("type") or "").lower()
        required = await handle.evaluate(
            "el => el.required || el.getAttribute('aria-required') === 'true'"
        )

        if config.DEBUG_FIELDS:
            print(f"    [field] tag={tag} type={input_type or '-'} label={label!r}")

        # A radio's own label is just its option ("Yes"); _fill_yesno_radios
        # answers the group from its question instead.
        if input_type == "radio":
            continue

        # Autocomplete fields are matched by ID with an explicit value, and need
        # the type-then-click-suggestion path even if they look like plain inputs.
        if el_id in autocomplete_ids:
            try:
                await _fill_input(handle, str(autocomplete_ids[el_id]), scope,
                                  page=page, force_autocomplete=True)
                result["filled"].append(label or el_id)
            except Exception:
                result["unknown"].append(label or el_id)
            continue

        # Free-text "why do you want to work here?": checked before the hints so
        # "...for our company?" isn't taken for current_company.
        _is_question_input = tag == "input" and "?" in label
        if (tag == "textarea" or _is_question_input) and is_why_interested(label, company) \
                and why_interested_text(company):
            source, value = "why_interested", why_interested_text(company)
        else:
            source, value = _hint_value(label, company)

        # Base salary: prefer the max of a range in the job description, falling
        # back to the configured base_salary.
        if source == "profile:base_salary" and _is_salary_label(label):
            from_desc = max_salary_in_text(job_description)
            value = from_desc or config.PROFILE.get("base_salary")

        # Cover-letter / "why this company?" free-text fields.
        # Fires on any textarea, or on a text input when the label is phrased
        # as a question (contains "?") so we don't dump a paragraph into short
        # fields whose label happens to contain "why".
        if value is None and (tag == "textarea" or _is_question_input):
            low = label.lower()
            _COVER_SIGNALS = (
                "cover", "why", "tell us", "anything else", "additional",
                "interest you", "interests you", "draws you", "excites you",
                "what do you", "motivate", "passion", "why us", "why join",
                "why this", "what about", "why would you",
            )
            if any(k in low for k in _COVER_SIGNALS):
                value = resumes.select_cover_letter(job_text, company)
                source = "cover_letter"

        if leave_for_user(source, label, required):
            if required:
                result["required_empty"].append(label)
                result["unknown"].append(label)
            continue

        if source is not None and not value:
            # We recognised the field but the config value is intentionally empty
            # (e.g. current_company = ""). Skip silently -- don't surface as unknown.
            continue

        if value is None:
            if not label:
                # No label, name, placeholder, or aria-label -- can't identify it.
                continue
            if required:
                result["required_empty"].append(label)
            result["unknown"].append(label)
            continue

        try:
            if tag == "select":
                ok = await _select_option(handle, value)
                if not ok:
                    result["unknown"].append(label)
                    continue
            elif input_type == "checkbox":
                # Only "I have read and consent..." style boxes are ticked;
                # other checkboxes are skipped without reporting.
                if source != "acknowledgment":
                    continue
                if not await handle.is_checked() and not await click_visible_or_label(handle):
                    result["unknown"].append(label)
                    continue
            elif await handle.get_attribute("data-uxi-widget-type") == "selectinput":
                # Workday's search prompt: typing + Enter alone would keep
                # whatever Workday highlights (e.g. "Albania (+355)").
                if not await _fill_prompt_search(handle, value):
                    result["unknown"].append(label)
                    continue
            else:
                # Location/city/school are remote-filtered search autocompletes:
                # type to filter, then pick a suggestion.
                force_ac = source in ("profile:location", "profile:city", "profile:school")
                filled = await _fill_input(handle, value if isinstance(value, list) else str(value),
                                           scope, page=page,
                                           force_autocomplete=force_ac)
                if not filled:
                    result["unknown"].append(label)
                    continue
            result["filled"].append(label or tag)
        except Exception:
            result["unknown"].append(label or tag)

    await _fill_yesno_buttons(scope, result, company)
    await _fill_yesno_radios(scope, result, company)
    await _fill_choice_radios(scope, result, company)
    await _fill_button_dropdowns(scope, result, page, company)

    return result


# JS: the question text for a widget -- its Workday formField label, else the
# nearest preceding sibling text of `node` or one of its ancestors (Gem,
# Rippling put it in a span above).
_QUESTION_BEFORE_JS = """node => {
    // Workday: each question is a formField-* with its own label/legend
    // (which may be long legalese, so no length cap here).
    const field = node.closest('[data-automation-id^="formField-"]');
    const own = field && field.querySelector('label, legend');
    if (own && own.innerText.trim()) return own.innerText.trim();
    for (let i = 0; node && i < 8; i++, node = node.parentElement)
        for (let prev = node.previousElementSibling; prev; prev = prev.previousElementSibling) {
            const t = prev.innerText && prev.innerText.trim();
            if (t && t.length > 4 && t.length < 300) return t;
        }
    return '';
}"""

# Runs on a "Yes" radio: finds its group (smallest ancestor that also holds a
# "No" radio), whether it's answered, and the question beside it.
_RADIO_GROUP_JS = """el => {
    const text = r => ((r.labels && r.labels[0]) || r.closest('label') || {}).innerText || '';
    if (!/^\\s*yes\\s*$/i.test(text(el))) return null;
    let group = el.parentElement, no = null;
    for (let i = 0; i < 8 && group && !no; i++) {
        no = [...group.querySelectorAll('input[type=radio]')]
            .find(r => /^\\s*no\\s*$/i.test(text(r)));
        if (!no) group = group.parentElement;
    }
    if (!no) return null;
    const answered = [...group.querySelectorAll('input[type=radio]')].some(r => r.checked);
    const fieldset = group.closest('fieldset');
    const legend = fieldset && fieldset.querySelector('legend');
    const question = legend ? legend.innerText.trim() : (""" + _QUESTION_BEFORE_JS + """)(group);
    return {question, answered, no};
}"""


async def _fill_yesno_radios(scope, result, company=""):
    """Answer Yes/No radio groups (e.g. Gem) from their question text.

    Each radio's label is only "Yes"/"No"; the question sits beside the
    group. Groups already answered are left alone. Clicks the option's
    <label>, since the input is usually hidden behind a styled one.
    """
    for yes in await scope.locator("input[type=radio]").all():
        try:
            info = await yes.evaluate(_RADIO_GROUP_JS)
            if not info or info["answered"] or not info["question"]:
                continue
            question = info["question"]
            _, value = _hint_value(question, company)
            if value is None:
                result["unknown"].append(question[:80])
                continue
            click_yes = str(value).lower() in ("yes", "true", "1")
            if config.DEBUG_FIELDS:
                print(f"    [radio] {question[:80]!r} -> {value!r} -> {'Yes' if click_yes else 'No'}")
            target = await yes.evaluate_handle(
                """(el, clickYes) => {
                    const r = clickYes ? el : (""" + _RADIO_GROUP_JS + """)(el).no;
                    return (r.labels && r.labels[0]) || r.closest('label') || r;
                }""", click_yes)
            if not await click_visible(target):
                result["unknown"].append(question[:80])
                continue
            result["filled"].append(question[:80])
        except Exception:
            continue


# Runs on a radio: its group's question and option labels, or null when the
# group is Yes/No (_fill_yesno_radios' job) or already answered. Ashby puts the
# question in a <label for=fieldset> rather than a <legend>.
_CHOICE_GROUP_JS = """el => {
    const text = r => (((r.labels && r.labels[0]) || r.closest('label') || {}).innerText || '').trim();
    const radios = el.name ? [...document.getElementsByName(el.name)].filter(r => r.type === 'radio') : [el];
    if (radios[0] !== el || radios.some(r => r.checked)) return null;
    const options = radios.map(text);
    if (options.some(t => /^(yes|no)$/i.test(t))) return null;
    const fieldset = el.closest('fieldset');
    const own = fieldset && [...fieldset.querySelectorAll('legend, label')]
        .find(l => !radios.some(r => l.contains(r) || (r.labels && [...r.labels].includes(l))));
    const question = own ? own.innerText.trim() : (""" + _QUESTION_BEFORE_JS + """)(el.closest('fieldset') || el.parentElement);
    return {question, options};
}"""


def choice_option_index(question, value, options):
    """best_option_index for a Yes/No answer to a question whose options are
    statements. Sponsorship: Yes -> the option requiring it ("Requires visa
    sponsorship"), No -> the negated one ("No sponsorship required")."""
    if value is None:
        return None
    low = str(value).lower()
    if low in ("yes", "no") and "sponsor" in question.lower():
        neg = re.compile(r"\b(?:no|not|don't|without)\b", re.I)
        for i, t in enumerate(options):
            if "sponsor" in t.lower() and bool(neg.search(t)) == (low == "no"):
                return i
    return best_option_index(value, options)


async def _fill_choice_radios(scope, result, company=""):
    """Answer radio groups whose options aren't plain Yes/No ("Authorized to
    work (No sponsorship required)" / "Requires visa sponsorship"): map the
    question via _hint_value, then pick the option with best_option_index."""
    for radio in await scope.locator("input[type=radio]").all():
        try:
            info = await radio.evaluate(_CHOICE_GROUP_JS)
            if not info or not info["question"]:
                continue
            question = info["question"]
            _, value = _hint_value(question, company)
            idx = choice_option_index(question, value, info["options"])
            if config.DEBUG_FIELDS:
                print(f"    [radio] {question[:80]!r} -> {value!r} -> "
                      f"{info['options'][idx] if idx is not None else None!r}")
            if idx is None:
                result["unknown"].append(question[:80])
                continue
            target = await radio.evaluate_handle(
                """(el, i) => {
                    const r = [...document.getElementsByName(el.name)].filter(r => r.type === 'radio')[i] || el;
                    return (r.labels && r.labels[0]) || r.closest('label') || r;
                }""", idx)
            if not await click_visible(target):
                result["unknown"].append(question[:80])
                continue
            result["filled"].append(question[:80])
        except Exception:
            continue


async def _fill_yesno_buttons(scope, result, company=""):
    """Click Yes/No button pairs rendered as <button> elements (e.g. Ashby).

    Finds containers that hold a Yes and a No button, reads the question text
    from a sibling/ancestor label, maps it via _hint_value, and clicks the
    matching button.
    """
    # Not dropdown triggers: an answered Workday dropdown is a <button
    # aria-haspopup> whose text is just "Yes"/"No".
    yes_btns = await scope.locator("button:not([aria-haspopup])").filter(
        has_text=re.compile(r"^Yes$", re.I)).all()
    if not yes_btns:
        return

    for yes_btn in yes_btns:
        try:
            if not await yes_btn.is_visible():
                continue

            # Read question text and locate the paired No button in one round-trip.
            info = await yes_btn.evaluate(
                """el => {
                    // Walk up to find the No sibling button and question text.
                    let node = el.parentElement;
                    let noBtn = null;
                    let question = '';
                    for (let i = 0; i < 8 && node; i++, node = node.parentElement) {
                        if (!noBtn) {
                            const btns = Array.from(node.querySelectorAll('button'));
                            const nb = btns.find(b => /^no$/i.test(b.innerText.trim()) && !b.hasAttribute('aria-haspopup'));
                            if (nb) noBtn = nb;
                        }
                        if (!question) {
                            let prev = node.previousElementSibling;
                            while (prev) {
                                const txt = prev.innerText && prev.innerText.trim();
                                if (txt && txt.length > 4 && txt.length < 300) {
                                    question = txt;
                                    break;
                                }
                                prev = prev.previousElementSibling;
                            }
                        }
                        if (noBtn && question) break;
                    }
                    return { question, hasNo: !!noBtn };
                }"""
            )

            question = info.get("question", "")
            has_no = info.get("hasNo", False)
            if not question or not has_no:
                continue

            source, value = _hint_value(question, company)
            if value is None:
                continue

            click_yes = str(value).lower() in ("yes", "true", "1")

            if config.DEBUG_FIELDS:
                print(f"    [yesno] {question[:80]!r} -> {value!r} -> {'Yes' if click_yes else 'No'}")

            if click_yes:
                await yes_btn.click()
            else:
                # Re-locate the No button paired with this Yes button.
                no_btn = await yes_btn.evaluate_handle(
                    """el => {
                        let node = el.parentElement;
                        for (let i = 0; i < 8 && node; i++, node = node.parentElement) {
                            const btns = Array.from(node.querySelectorAll('button'));
                            const nb = btns.find(b => /^no$/i.test(b.innerText.trim()) && !b.hasAttribute('aria-haspopup'));
                            if (nb) return nb;
                        }
                        return null;
                    }"""
                )
                await no_btn.as_element().click()

            result["filled"].append(question[:80])
        except Exception:
            continue


async def _pick_autocomplete(handle, value, scope, page=None, wait_for_dropdown=False,
                             dropdown_timeout=1500):
    """After typing into a field, scan visible DOM elements for text matching
    `value` and click the best match. Checks the outer page first (handles
    cases like Greenhouse where the listbox renders outside an iframe), then
    falls back to scope. Returns True if something was clicked."""

    # Selector covering common dropdown item patterns without matching nav/list elements.
    ITEM_SEL = (
        "[role=option], [role=listbox] li, ul[role=listbox] li, "
        ".pac-item, .select__option, [class*=suggestion-item], [class*=autocomplete-item]"
    )

    async def _scan(ctx):
        """True: clicked a match. False: options shown, none match. None: no options."""
        # One visible-filtered locator so the texts we read and the element we
        # click share index order; all_inner_texts() reads every option in one
        # round-trip instead of two per option.
        visible = ctx.locator(ITEM_SEL).filter(visible=True)
        try:
            texts = await visible.all_inner_texts()
        except Exception:
            return None
        if not texts:
            return None

        idx = best_option_index(value, [t.strip() for t in texts])
        if idx is None:
            return False

        # force=True skips actionability waits; the option is already visible.
        try:
            await visible.nth(idx).click(force=True, timeout=1000)
            return True
        except Exception:
            return False

    # The menu may render in the outer page OR inside the iframe scope, so check
    # both. react-select inside a Greenhouse iframe renders in the iframe body.
    import asyncio
    contexts = [scope] if page is None else [page, scope]

    if not wait_for_dropdown:
        # Plain inputs: only act on an already-present dropdown, never wait.
        for ctx in contexts:
            if await _scan(ctx):
                return True
        return False

    # Poll until an option that actually MATCHES our value appears, then click
    # it. This waits exactly as long as the (possibly remote) search needs --
    # no fixed sleep, no clicking before the right result has loaded.
    # A plain text field (e.g. Greenhouse's "What city do you live in?") never
    # shows a menu, so stop if none has appeared within 1.5s instead of waiting
    # out the whole timeout.
    loop = asyncio.get_event_loop()
    start = loop.time()
    seen_menu = False
    while loop.time() - start < dropdown_timeout / 1000.0:
        for ctx in contexts:
            found = await _scan(ctx)
            if found:
                return True
            seen_menu = seen_menu or found is not None
        if not seen_menu and loop.time() - start > 1.5:
            break
        await asyncio.sleep(0.1)

    return False


async def _fill_input(handle, value, scope, page=None, force_autocomplete=False):
    """Fill a text/tel/email input.

    Three kinds of fields:
      - search autocomplete (location/city/school): must TYPE to filter, then click match.
        Signalled by force_autocomplete=True.
      - select dropdown (react-select EEO/sponsorship/etc): just CLICK to open and
        click the option -- no typing needed (and typing can interfere).
      - plain text input: fill() and done.
    value may be a list of preferred options (see best_option_index); text
    inputs get the first one. Returns False if no option matched.
    """
    text = value[0] if isinstance(value, list) else value
    try:
        await handle.click(timeout=2000)
    except Exception:
        # A select that already shows a value (Ant Design on Dayforce) covers its
        # input with the value text; a normal click scroll-retries for 30s.
        await handle.click(force=True)

    if force_autocomplete:
        # Search-style: type to filter the remote/long option list, then pick.
        # Location/country lookups hit a remote service, so allow a longer wait
        # for suggestions to arrive.
        await handle.fill("")
        await handle.type(text, delay=20)
        await _pick_autocomplete(handle, value, scope, page=page,
                                 wait_for_dropdown=True, dropdown_timeout=5000)
        return True

    is_select_dropdown = await handle.evaluate(
        "el => el.getAttribute('role') === 'combobox' || "
        "el.closest('[role=combobox]') !== null || "
        "el.hasAttribute('list') || "
        "(el.id || '').startsWith('react-select') || "
        "el.closest('[class*=select__control]') !== null || "
        "el.closest('.select-shell, [class*=select__]') !== null || "
        "el.getAttribute('aria-autocomplete') === 'list' || "
        "el.getAttribute('role') === 'searchbox'"
    )

    if is_select_dropdown:
        # react-select: the click above opened the menu; pick the option that
        # best matches the config value.
        if await _select_via_keyboard(handle, value, scope, page):
            return True
        # _select_via_keyboard already waited up to its timeout for options
        # to appear; if we're here the options are available but the selector
        # didn't match them. Try once immediately -- no further polling.
        if await _pick_autocomplete(handle, value, scope, page=page, wait_for_dropdown=False):
            return True
        # Long menus load options in pages (Greenhouse discipline shows 100 of
        # ~300), so the answer may not be rendered yet: type each choice to filter.
        for choice in (value if isinstance(value, list) else [value]):
            await handle.fill("")
            await handle.type(str(choice), delay=20)
            if await _pick_autocomplete(handle, value, scope, page=page,
                                        wait_for_dropdown=True, dropdown_timeout=2000):
                return True
        # Nothing matched: clear and close the menu, leave the field to the caller.
        await handle.fill("")
        await handle.press("Escape")
        return False
    else:
        # Plain text input: just fill it. No dropdown scan -- that's only for
        # combobox/autocomplete fields and would add a needless per-field delay.
        await handle.fill(text)

    return True


async def _read_open_options(scope, page):
    """Return (visible_locator, texts) for options in the open dropdown menu,
    checking the iframe scope and the outer page. texts and locator.nth() share
    the same index order. Texts are read in one round-trip (all_inner_texts)."""
    OPT_SEL = "[role=option], .select__option, [class*=select__option]"
    contexts = [scope] if page is None else [page, scope]
    for ctx in contexts:
        visible = ctx.locator(OPT_SEL).filter(visible=True)
        try:
            texts = await visible.all_inner_texts()
        except Exception:
            continue
        texts = [t.strip() for t in texts]
        if any(texts):
            return visible, texts
    return None, []


async def _select_via_keyboard(handle, value, scope, page, timeout=2000):
    """Select a dropdown option from an already-open menu:
      1. poll until the menu's options are present (no fixed sleep)
      2. score them against the config value (best_option_index)
      3. click the matched option directly (instant, even in long lists);
         fall back to ArrowDown x idx + Enter if the click is intercepted.
    No typing/searching, no per-keystroke stepping through long lists."""
    import asyncio

    # Poll for options to render instead of a fixed wait -- acts as soon as the
    # menu is populated.
    deadline = asyncio.get_event_loop().time() + timeout / 1000.0
    visible, texts = None, []
    while asyncio.get_event_loop().time() < deadline:
        visible, texts = await _read_open_options(scope, page)
        if texts:
            break
        await asyncio.sleep(0.05)
    if not texts:
        return False

    idx = best_option_index(value, texts)
    if idx is None:
        return False

    # Click the matched option directly -- O(1), no arrow-stepping through a long
    # country list. force=True skips actionability waits (the option is already
    # rendered since we read it); a normal click would pause waiting for the menu
    # to stop animating. No scroll_into_view (react-select repositions on scroll).
    try:
        await visible.nth(idx).click(force=True, timeout=1000)
        return True
    except Exception:
        pass

    # Last resort: keyboard navigation.
    try:
        # On open, react-select auto-highlights the first option (index 0), so
        # ArrowDown idx times lands on the target.
        for _ in range(idx):
            await handle.press("ArrowDown")
        await handle.press("Enter")
        return True
    except Exception:
        return False


# Phrases that mean "I don't want to answer". Note: "self-describe"/"self-identify"
# are NOT here -- "I prefer to self-describe" is volunteering info, the opposite of
# declining, and must not be treated as a decline option.
_DECLINE_SIGNALS = ("decline", "prefer not", "don't wish", "do not wish",
                    "choose not", "no answer", "not listed", "rather not",
                    "wish not", "don't want", "do not want")


def max_salary_in_text(text):
    """Find the largest plausible salary figure in a job description and return
    it as a digits-only string, or None if none found.

    Handles ranges like "$115,000 - $130,000 USD" (returns "130000") and shorthand
    like "$130k" (returns "130000"). Only counts figures >= 1000 (or >= 10 with a
    'k' suffix) to avoid picking up years, counts, etc.
    """
    if not text:
        return None

    best = None
    # $115,000 / 115,000 / $130k / 130K  (optional $, optional commas, optional k)
    for m in re.finditer(r"\$?\s*([0-9][0-9,]*)(\.[0-9]+)?\s*([kK])?", text):
        digits = m.group(1).replace(",", "")
        if not digits:
            continue
        try:
            amount = int(digits)
        except ValueError:
            continue
        suffix_k = m.group(3)
        if suffix_k:
            amount *= 1000
        elif amount < 1000:
            # bare small numbers (years, "5+ years", etc.) are not salaries
            continue
        # plausible salary band guard
        if amount < 10000 or amount > 10_000_000:
            continue
        if best is None or amount > best:
            best = amount

    return str(best) if best is not None else None


def _number_fits(n, text):
    """True if option text like "6 - 8 years", "Less than 6", "10+" or "at least 5" holds n."""
    nums = [int(x.replace(",", "")) for x in re.findall(r"\d[\d,]*", text)]
    if len(nums) >= 2:
        return nums[0] <= n <= nums[1]
    if len(nums) != 1:
        return False
    x = nums[0]
    if any(w in text for w in ("less", "under", "fewer", "below", "<")):
        return n < x
    if any(w in text for w in ("up to", "at most")):
        return n <= x
    # Inclusive phrasings first: "5 or greater" / "5 and above" include 5.
    if any(w in text for w in ("+", "or more", "at least", "and above", "or above",
                               "or greater", "and up")):
        return n >= x
    if any(w in text for w in ("more than", "over", "greater", "above", ">")):
        return n > x
    return n == x


def best_option_index(value, option_texts):
    """Given a config value and a list of option label strings, return the index
    of the best match, or None. Pure function -- works for native <select> and
    react-select alike. Match priority:
      0. single-letter value (e.g. "M"): match option == "M" or whose first word
         starts with that letter ("Male"). Avoids "M" matching "feMale".
      1. exact (case-insensitive)
      2. config value is a substring of the option (shortest such option)
      3. option is a substring of the config value
      4. decline/prefer-not family, if the config value signals it
      5. word overlap (any shared non-stopword)
    """
    texts = [t.lower().strip() for t in option_texts]
    # A list value is ordered preferences matched exactly, so a missing first
    # choice falls to the next one rather than a loose near-miss ("Public Health").
    if isinstance(value, list):
        for v in value:
            if str(v).lower().strip() in texts:
                return texts.index(str(v).lower().strip())
        return None

    low = str(value).lower().strip()

    # Single-letter values are ambiguous for substring matching ("m" is inside
    # "female"), so match by word boundary: exact letter, or a word starting with it.
    if len(low) == 1 and low.isalpha():
        for i, t in enumerate(texts):
            if t == low:
                return i
        for i, t in enumerate(texts):
            words = t.replace("/", " ").split()
            if any(w.startswith(low) for w in words):
                return i
        return None

    for i, t in enumerate(texts):
        if t == low:
            return i

    # "No" -> "No, please do not contact me", not "Yes, notify me" (which
    # merely contains "no").
    if low in ("yes", "no"):
        for i, t in enumerate(texts):
            if re.match(rf"{low}\b", t):
                return i

    # Numeric value (years of experience, salary): pick the option whose range holds it.
    if low.isdigit():
        n = int(low)
        for i, t in enumerate(texts):
            if _number_fits(n, t):
                return i

    # Shortest containing option is the closest: "United States" -> "United States
    # of America", not "United States Minor Outlying Islands".
    containing = [i for i, t in enumerate(texts) if t and low in t]
    if containing:
        return min(containing, key=lambda i: len(texts[i]))
    for i, t in enumerate(texts):
        if t and t in low:
            return i

    # Decline/prefer-not family runs BEFORE generic word overlap: a value like
    # "Decline to self-identify" should map to "I don't wish to answer", not to
    # "I wish to self-describe" (which only shares the stopword "to").
    if any(sig in low for sig in _DECLINE_SIGNALS):
        for i, t in enumerate(texts):
            if any(sig in t for sig in _DECLINE_SIGNALS):
                return i

    # Word overlap (handles e.g. "He/Him" vs config "he/him/his"). Ignore
    # stopwords so shared filler like "to"/"of" doesn't create false matches.
    # Score every option rather than taking the first that shares a word, and
    # make negation agree: "I am not a protected veteran" must not pick "I
    # identify as ... protected veterans". Closest overall wording wins.
    _STOP = {"to", "of", "or", "and", "the", "a", "an", "in", "do", "i", "my",
             "you", "your", "is", "are", "not", "no", "am", "as"}
    _NEG = re.compile(r"\b(?:not|no|don't|do not|never|non)\b")
    def _words(s):
        return set(w.rstrip("s") for w in re.findall(r"[a-z0-9']+", s)
                   if len(w) > 1 and w not in _STOP)
    value_words = _words(low)
    negated = bool(_NEG.search(low))
    scored = [(len(value_words & _words(t)), difflib.SequenceMatcher(None, low, t).ratio(), i)
              for i, t in enumerate(texts) if value_words & _words(t)]
    if negated and any(_NEG.search(texts[i]) for _, _, i in scored):
        scored = [x for x in scored if _NEG.search(texts[x[2]])]
    if scored:
        return max(scored, key=lambda x: (x[1], x[0], -x[2]))[2]

    return None


async def _select_option(handle, value):
    """Choose the <option> whose text best matches `value`. Returns True/False."""
    options = await handle.evaluate(
        "el => Array.from(el.options).map(o => ({value:o.value, text:o.text.trim()}))"
    )
    idx = best_option_index(value, [o["text"] for o in options])
    if idx is None:
        return False
    await handle.select_option(options[idx]["value"])
    return True


# A dropdown button still showing its placeholder, i.e. unanswered.
_PLACEHOLDER_TEXT = re.compile(r"^\s*(?:select|choose|pick)\b.{0,25}$", re.I)


async def _fill_button_dropdowns(scope, result, page=None, company=""):
    """Answer custom dropdowns that are a plain <button> opening a role=option
    list (e.g. Gem's "Select an option"), from the question text beside them.
    Buttons already showing an answer don't match the placeholder and are
    left alone."""
    placeholders = scope.locator("button").filter(has_text=_PLACEHOLDER_TEXT)
    tried = set()
    while True:
        # Re-query each round: answering one drops it from `placeholders`, so
        # a locator list taken up front would shift and skip the next one.
        btn = question = None
        for cand in await placeholders.all():
            try:
                if await cand.is_visible():
                    q = await cand.evaluate(_QUESTION_BEFORE_JS)
                    if q and q not in tried:
                        btn, question = cand, q
                        break
            except Exception:
                continue
        if btn is None:
            return
        tried.add(question)
        try:
            _, value = _hint_value(question, company)
            if value is None:
                result["unknown"].append(question[:80])
                continue
            # Only the list this button opens: other option lists can be
            # showing too (Workday's Skills suggestions), so mark what's
            # visible before opening and ignore it after.
            root = page or btn.page
            await root.evaluate("""() => document.querySelectorAll('[role=option]').forEach(
                o => { if (o.offsetParent) o.dataset.cmmBefore = '1'; })""")
            if not await click_visible(btn):
                result["unknown"].append(question[:80])
                continue
            await asyncio.sleep(0.3)
            options = root.locator("[role=option]:not([data-cmm-before])").filter(visible=True)
            texts = [t.strip() for t in await options.all_inner_texts()]
            idx = best_option_index(value, texts) if texts else None
            if config.DEBUG_FIELDS:
                print(f"    [dropdown] {question[:80]!r} -> {value!r} -> "
                      f"{texts[idx] if idx is not None else None!r} of {texts}")
            if idx is None:
                await root.keyboard.press("Escape")
                result["unknown"].append(question[:80])
                continue
            placeholder = (await btn.inner_text()).strip()
            if not await click_visible(options.nth(idx)):
                await root.keyboard.press("Escape")
                result["unknown"].append(question[:80])
                continue
            # Accenture's Workday takes over a second to show the choice.
            for _ in range(8):
                await asyncio.sleep(0.25)
                if (await btn.inner_text()).strip() != placeholder:
                    break
            if (await btn.inner_text()).strip() == placeholder:
                # Clicked but not selected: don't report it as answered.
                await root.keyboard.press("Escape")
                result["unknown"].append(question[:80])
                continue
            result["filled"].append(question[:80])
        except Exception:
            continue


async def _fill_prompt_search(handle, value, timeout_s=4):
    """Fill a Workday search prompt (data-uxi-widget-type=selectinput, e.g.
    "How Did You Hear About Us?", "Country Phone Code"): type the value and
    press Enter, then Workday either selects a lone match itself or lists the
    matches, of which we click the best_option_index one. A wrong earlier
    selection is removed first. Clicks go through element.click() so they
    work even when the browser window isn't being painted."""
    page = handle.page
    box = handle.locator("xpath=ancestor::*[@data-automation-id='multiSelectContainer'][1]")
    selected = box.locator("[data-automation-id=selectedItem]")

    async def chosen():
        return [t.strip() for t in await selected.all_inner_texts()]

    current = await chosen()
    if current and best_option_index(value, current) is not None:
        return True
    for charm in await selected.locator("[data-automation-id=DELETE_charm]").all():
        await click_visible(charm)

    term = value[0] if isinstance(value, list) else str(value)
    await handle.evaluate("e => { e.scrollIntoView({block: 'center'}); e.focus(); }")
    await handle.fill(term)
    await handle.press("Enter")
    options = page.locator("[data-automation-id=activeListContainer] [role=option]")
    try:
        for _ in range(int(timeout_s / 0.25)):
            await asyncio.sleep(0.25)
            if await chosen():
                break
            texts = [t.strip() for t in await options.all_inner_texts()]
            idx = best_option_index(value, texts) if texts else None
            if idx is not None:
                leaf = options.nth(idx).locator("[data-automation-id=promptLeafNode]").first
                await click_visible(leaf if await leaf.count() else options.nth(idx))
                await asyncio.sleep(0.5)
                break
        current = await chosen()
        if config.DEBUG_FIELDS:
            print(f"    [prompt] {term!r} -> {current}")
        return bool(current) and best_option_index(value, current) is not None
    finally:
        await page.keyboard.press("Escape")
