# Architecture

call-me-maybe fills job applications with async Playwright, in the tabs of a
remote-debugging browser. For each open application tab it detects the job,
picks a resume, lets a board adapter fill the form, then pauses for review or
submits, and logs the attempt.

## Components

```
fill.py            Entry point. Attaches to the browser and, per open
                    application tab (apply_to): detect title/company/description,
                    pick a resume, call the adapter, pause/guard, submit if
                    allowed, log. --stealth: launch flags for a started browser.
browser.py          STEALTH + attach_browser: attach over CDP at cdp_url, else
                    start Brave/Chrome with remote debugging (shared by all scripts).
gmail.py            Watches the inbox in a Gmail tab for Workday verification /
                    password-reset mail; opens only matching messages.
view-results.py     Serves strict-search results and opens them in the browser.
scrape.py           Standalone LinkedIn search scraper: clicks each result with a
                    human-like cursor, saves jobs passing its own filters to
                    strict-search-results/<keywords>_<date>_<time>.csv, one file per run, deduped
                    within the run (by jobId and employer + title).
scrape.toml         scrape.py's keywords, filters and pacing; cdp_url for every script.
filler.py           THE BRAIN. Heuristic field filler + all matching logic.
resumes.py          Job-title keyword -> resume file / cover-letter text.
applog.py           applications/log.csv + dedupe (only "submitted" blocks a re-run).
profile.toml        [profile] + [eeo]: personal info and demographic answers. Gitignored;
                    start from profile.example.toml.
config.toml         Run flags, resume_rules, cover letter, browser/stealth settings.
                    Gitignored; start from config.example.toml.
config.py           Loads config.toml (else config.example.toml; keys become
                    config.UPPERCASE names) and profile.toml (config.PROFILE,
                    config.EEO; empty if missing).
adapters/
  __init__.py       pick_adapter(url) routes by host substring, else generic.
  common.py         detect_job, detect_job_description, upload_resume,
                    find_submit_button, pause_for_manual_action.
  greenhouse.py     #grnhse_iframe scope + candidate-location autocomplete.
  ashby.py          Waits for the React form, then fill_form + upload.
  workday.py        Drives the wizard: Apply -> sign-in -> resume upload ->
                    fill each step -> stop before Submit.
  dayforce.py       Clicks Apply -> "Apply without an Account", then generic.apply.
  talenthop.py      Aggregator: Apply Now (logs in if asked) -> Proceed to
                    Application, loads the posting here, then its board's adapter.
  workable.py       "Import resume from" -> My computer (parses the resume into
                    the form), then generic.apply.
  generic.py        Fallback: finds the form (iframe or page), uploads, fills,
                    clicks Next across multi-page forms. Also, generically, what
                    workday.py does: one sign-in/create-account pass (Gmail
                    verification), resume on a later empty upload, slow saves.
```

## Data flow

`fill.apply_to` calls `adapter.apply(page, resume_path, job_text, company,
job_description)`, which returns `{"filled", "unknown", "required_empty",
"resume_uploaded"}`. Then `fill.py`:

1. pauses if any field is unmapped (`MANUAL_FILL_PAUSE`);
2. saves a screenshot and the page HTML to `applications/<timestamp>-<board>/`
   (`DRY_RUN_SCREENSHOT`);
3. pauses or refuses if required fields are empty (`CHECK_REQUIRED_BEFORE_SUBMIT`);
4. clicks `common.find_submit_button` if `SUBMIT_APPLICATION`, otherwise pauses
   for review;
5. records the outcome in `applications/log.csv`.

Adapters never click the final submit button. `fill.py` owns that.

## Design rule

Robustness lives in `filler.py`, not adapters. An adapter only does what
can't be discovered heuristically: where the form is (iframe, modal), how to
move between steps (wizards, sign-in), and fields with no usable label (passed
by `id` via `autocomplete_ids`). `generic.py` gets everything else by calling
`filler.fill_form`.

## Invariants

These apply to every ATS. Break one and forms silently stop filling.

### 1. Fill by label, never by DOM order
`fill_form` iterates all inputs and matches each by its label text. `_describe`
builds the label from name/id/placeholder/aria-label, the associated
`<label>`/`<legend>`, and nearby preceding text. Field order and presence vary
per form, so never write "fill field N, then N+1". A field that needs special
handling is keyed by `id` (see `autocomplete_ids`).

### 2. Three input archetypes: detect, don't assume
`_fill_input` branches on:
- **Plain text** (name, email, phone, URLs): `fill()` only. No dropdown scan;
  scanning every plain field adds a visible per-field delay.
- **Search autocomplete** (location/city/school): must `type()` to fire React
  onChange and filter a remote list, then click the matching suggestion.
  Triggered by `force_autocomplete` (from `autocomplete_ids`, or the
  `profile:location`/`city`/`school` sources).
- **Select dropdown** (react-select: country, EEO, sponsorship, pronouns,
  yes/no): click to open, then select. **Do not type**: the option list is
  fixed and typing interferes.

`is_select_dropdown` in `_fill_input` keys off react-select markers
(`id^=react-select`, `.select__control` ancestor, `aria-autocomplete`,
`role=combobox/searchbox`). If an ATS renames those classes, update that
`evaluate()` expression.

### 3. The listbox may render outside the iframe
Greenhouse embeds the form in `#grnhse_iframe`, but option menus can render in
the top-level page DOM. Every option scan checks both (`contexts = [page,
scope]`), so adapters must pass `page=page` to `fill_form`.

### 4. Never `scroll_into_view` a react-select option
react-select repositions its menu on scroll, which triggers another scroll:
the page scrolls up and down forever. Playwright's normal `click()` scrolls to
stabilize the element and hits the same loop. **Always click options with
`click(force=True, timeout=1000)`**; the option is already known visible
because we just read it.

### 5. Poll until the matching option appears; no fixed sleeps
Poll (`while time < deadline`) and run the scan each iteration. The scan only
succeeds when an option matching the config value exists, then clicks
immediately. Location/city searches use a 5s bound (remote); plain dropdowns
about 2s.

### 6. Read all option texts in one round-trip
Use `locator(SEL).filter(visible=True).all_inner_texts()` once, match in
Python with `best_option_index`, then click `visible.nth(idx)`. Texts and
`nth(idx)` share index order because they come from the same locator.
Per-option `is_visible()` + `inner_text()` calls cost two round-trips per
option per poll and make selection visibly slow.

### 7. Option matching is centralized in `best_option_index`
A pure, unit-tested function used for native `<select>` and react-select.
Order matters:
1. single-letter values ("M") match by word start, not substring, so "M"
   doesn't match "feMale";
2. exact, then value-in-option, then option-in-value;
3. the decline/prefer-not family **before** generic word overlap, so a real
   decline option beats a coincidental word match;
4. word overlap ignores stopwords ("to", "of", "not", ...), so "Decline to
   self-identify" doesn't match "I wish to self-describe".

"self-describe"/"self-identify" are not decline signals: "I prefer to
self-describe" volunteers information.

### 8. Field hints are first-match substring matches
`EEO_HINTS` and `FIELD_HINTS` match substrings and the first match wins, so
order and specificity matter. "sexual orientation" contains "sex" and
"transgender" contains "gender", so both hints sit before the gender hint, and
gender uses "gender identity"/"gender", not bare "sex". When adding a question
type, check it isn't swallowed by an earlier broad hint (e.g. "name").

### 9. Salary: prefer the range max from the job description
`max_salary_in_text(job_description)` returns the largest plausible figure
("$115,000 - $130,000 USD" -> 130000, "$130k" -> 130000) and ignores years and
counts. Falls back to `PROFILE["base_salary"]`. The description comes from
`common.detect_job_description` via `fill.py` -> adapter ->
`fill_form(job_description=...)`.

### 10. Timezone / "are you based in X?" questions
`location_availability_answer` answers from `PROFILE["based_in_regions"]` /
`["timezone"]`. It returns a plain string ("Yes"/"No"/the timezone) so it
works with whatever widget the form uses.

### 11. Stop waiting the moment the option is there
Every dropdown path (`_select_via_keyboard`, `_pick_autocomplete`) returns as
soon as a match is found. No sleep before or after clicking an option. The
`_pick_autocomplete` fallback after `_select_via_keyboard` uses
`wait_for_dropdown=False` (single pass): the options are already rendered.

### 12. End-of-run pauses
With `SUBMIT_APPLICATION=False`, `fill.py` pauses after each form ("Review
the filled form…"). With it `True` and nothing unmapped, nothing pauses. The
browser is always left open.

## When an ATS changes its markup

1. Set `debug_fields = true` in config.toml and run; check how each field's label and type
   are detected.
2. Dropdowns stop selecting: check `is_select_dropdown` and the option
   selectors `ITEM_SEL` / `OPT_SEL` in `filler.py` against the new DOM.
3. Greenhouse city stops filling: confirm `candidate-location` is still the
   element `id` in `greenhouse.py`'s `autocomplete_ids`.
4. Listbox moved relative to the iframe: both contexts are already checked;
   verify `page=page` is still passed.
5. Add a failing unit test for any new matching bug before fixing it.
