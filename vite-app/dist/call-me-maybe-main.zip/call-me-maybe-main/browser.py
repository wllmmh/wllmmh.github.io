"""The remote-debugging browser every script works in.

fill.py, scrape.py and view.py attach to the browser at
cdp_url (scrape.toml) over CDP, starting one if none is listening, and
leave it open afterwards. config.toml's `browser` / `brave_path` pick which, and
`stealth_mode` its launch flags.
"""

import asyncio
import os
import shutil
import subprocess
import sys
from urllib.parse import urlparse

from playwright_stealth import Stealth

import config

# Mask only the WebDriver automation flag; let real Chrome supply the rest.
STEALTH = Stealth(
    navigator_webdriver=True,
    chrome_app=False, chrome_csi=False, chrome_load_times=False,
    chrome_runtime=False, hairline=False, iframe_content_window=False,
    media_codecs=False, navigator_hardware_concurrency=False,
    navigator_languages=False, navigator_languages_override=None,
    navigator_permissions=False, navigator_platform=False,
    navigator_platform_override=None, navigator_plugins=False,
    navigator_user_agent=False, navigator_vendor=False,
    error_prototype=False, sec_ch_ua=False, webgl_vendor=False,
)


def _find_browser(name):
    """Path to Brave or Chrome: brave_path (for Brave), then PATH (Linux), then the
    usual macOS and Windows install dirs. None if not found."""
    configured = [config.BRAVE_PATH] if name == "brave" else []
    on_path = ["brave-browser", "brave"] if name == "brave" else ["google-chrome", "chrome"]
    mac = ("/Applications/Brave Browser.app/Contents/MacOS/Brave Browser" if name == "brave"
           else "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome")
    install = (r"BraveSoftware\Brave-Browser\Application\brave.exe" if name == "brave"
               else r"Google\Chrome\Application\chrome.exe")
    windows = [os.path.join(os.environ[v], install)
               for v in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA") if os.environ.get(v)]
    for exe in [*configured, *map(shutil.which, on_path), mac, *windows]:
        if exe and os.path.exists(exe):
            return exe
    return None


async def attach_browser(p, cdp_url, stealth=None):
    """Attach to the browser already listening at cdp_url, else start one with remote debugging on.

    Returns (browser, started). A started browser uses its own profile dir (recent Chrome
    refuses remote debugging on the default profile), is detached so it outlives this
    script, and needs a one-time login by the caller. It gets config.STEALTH_ARGS when
    `stealth` (default: config stealth_mode == "stealth"), else config.STANDARD_ARGS;
    flags can't change a browser that's already running.
    """
    if stealth is None:
        stealth = config.STEALTH_MODE == "stealth"
    try:
        return await p.chromium.connect_over_cdp(cdp_url), False
    except Exception as first_error:
        err = first_error
    name = "brave" if config.BROWSER == "brave" else "chrome"
    exe = _find_browser(name)
    if not exe:
        hint = f"brave_path = {config.BRAVE_PATH!r} doesn't exist" if name == "brave" else "Chrome isn't installed"
        sys.exit(f"Couldn't attach to a browser at {cdp_url} ({err}) and couldn't find {name} to start: {hint}.")
    port = urlparse(cdp_url).port
    print(f"No browser at {cdp_url}; starting one with remote debugging on port {port}...")
    args = config.STEALTH_ARGS if stealth else config.STANDARD_ARGS
    subprocess.Popen(
        [exe, f"--remote-debugging-port={port}",
         f"--user-data-dir={os.path.join(os.path.expanduser('~'), '.config', f'{name}-strict-search')}", *args],
        stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        # Off this script's session (POSIX) or console (Windows), so Ctrl+C here doesn't close it.
        start_new_session=True,
        creationflags=(subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
                       if sys.platform == "win32" else 0),
    )
    for _ in range(40):
        await asyncio.sleep(0.5)
        try:
            return await p.chromium.connect_over_cdp(cdp_url), True
        except Exception as e:
            err = e
    sys.exit(f"Started {exe} but couldn't attach at {cdp_url} ({err}).")
