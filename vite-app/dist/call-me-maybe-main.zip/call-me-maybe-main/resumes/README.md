# Resume store

Drop your resume PDFs here, then map them in `config.toml` (`resume_rules` /
`default_resume`). Example:

- `ai-resume.pdf` — used for AI / agent / ML roles
- `frontend-resume.pdf` — used for React / frontend roles
- `quant-resume.pdf` — used for quant / trading / research roles
- `full-stack-resume.pdf` — default fallback

The PDFs themselves are gitignored so you don't commit personal documents.
