"""Serve search-results-view.html with strict-search-results/ and open it in the browser.

The page opens as a tab in the remote-debugging browser at cdp_url
(scrape.toml), started if it isn't running, so jobs opened from it land
where fill.py can fill them. Only those two paths are served, so the rest of
the repo (profile.toml) stays private.
"""
import asyncio
import http.server
import csv
import glob
import json
import os
import posixpath
import re
import tempfile
import threading
import tomllib
from datetime import datetime
import webbrowser
from urllib.parse import unquote, urlparse

# Playwright's bundled Node driver calls url.parse() on connect_over_cdp; hide its DEP0169 warning.
os.environ["NODE_OPTIONS"] = (os.environ.get("NODE_OPTIONS", "") + " --disable-warning=DEP0169").strip()

ROOT = os.path.dirname(os.path.abspath(__file__))
PAGE = "/search-results-view.html"
CSV_DIR = "/strict-search-results/"
RESULTS = os.path.join(ROOT, "strict-search-results")
DELETED_PATH = os.path.join(RESULTS, "deleted.json")  # read by scrape.py
_lock = threading.Lock()


def _replace(path, write):
    """Write via a temp file so a crash never leaves a half-written file."""
    fd, tmp = tempfile.mkstemp(dir=RESULTS)
    with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
        write(f)
    os.replace(tmp, path)


def mark_deleted(job_id):
    """Add job_id to deleted.json ({job_id: deleted_at}) and drop its rows from every results CSV."""
    with _lock:
        try:
            with open(DELETED_PATH, encoding="utf-8") as f:
                deleted = json.load(f)
        except FileNotFoundError:
            deleted = {}
        deleted[job_id] = datetime.now().isoformat(timespec="seconds")
        _replace(DELETED_PATH, lambda f: json.dump(deleted, f, indent=2))
        for path in glob.glob(os.path.join(RESULTS, "*.csv")):
            with open(path, encoding="utf-8", newline="") as f:
                rows = list(csv.reader(f))
            kept = [r for i, r in enumerate(rows) if i == 0 or not r or r[0] != job_id]  # job_id is column 0
            if len(kept) != len(rows):
                _replace(path, lambda f: csv.writer(f).writerows(kept))


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kw):
        super().__init__(*args, directory=ROOT, **kw)

    def do_GET(self):
        path = posixpath.normpath(unquote(urlparse(self.path).path))  # resolves any ".."
        if self.path.endswith("/") and path != "/":
            path += "/"
        if path == "/":
            self.send_response(302)
            self.send_header("Location", PAGE)
            self.end_headers()
        elif path == PAGE or path.startswith(CSV_DIR):
            self.path = path
            super().do_GET()
        else:
            self.send_error(404)

    do_HEAD = do_GET

    def do_POST(self):
        # Requiring application/json makes browsers preflight cross-site posts, which we never answer.
        if self.path != "/api/delete" or self.headers.get("Content-Type") != "application/json":
            return self.send_error(404)
        try:
            job_id = str(json.loads(self.rfile.read(int(self.headers["Content-Length"])))["job_id"])
        except (ValueError, KeyError, TypeError):
            return self.send_error(400)
        if not re.fullmatch(r"\d+", job_id):
            return self.send_error(400)
        mark_deleted(job_id)
        self.send_response(204)
        self.end_headers()

    def log_message(self, *args):
        pass


async def open_in_debug_browser(url):
    """Open url in a new tab of the cdp_url browser, starting it if needed.
    The browser outlives this script."""
    from playwright.async_api import async_playwright
    from adapters.common import new_tab
    from browser import attach_browser
    with open(os.path.join(ROOT, "scrape.toml"), "rb") as f:
        cdp_url = tomllib.load(f)["cdp_url"]
    async with async_playwright() as p:
        browser, _ = await attach_browser(p, cdp_url)
        context = browser.contexts[0]
        # A tab beside an existing one (not the Gmail tab), not a new window.
        near = [pg for pg in context.pages if "mail.google.com" not in pg.url] or context.pages
        if near:
            page = await new_tab(near[-1], url)
        else:
            page = await context.new_page()
            await page.goto(url)
        await page.bring_to_front()


if __name__ == "__main__":
    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    url = f"http://127.0.0.1:{server.server_port}{PAGE}"
    print(f"Serving {url} (Ctrl+C to stop)")
    threading.Thread(target=server.serve_forever, daemon=True).start()
    try:
        asyncio.run(open_in_debug_browser(url))
    except (Exception, SystemExit) as e:  # attach_browser sys.exit()s when it can't start one
        print(f"Couldn't open it in the debug browser ({e}); opening the default browser.")
        webbrowser.open(url)
    try:
        threading.Event().wait()
    except KeyboardInterrupt:
        pass
