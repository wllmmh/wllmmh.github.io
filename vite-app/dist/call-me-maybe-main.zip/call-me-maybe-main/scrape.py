"""Strict LinkedIn job-search scraper.

Collects job ids, employers, titles and logos into a CSV; it never applies.
Starts on a LinkedIn search-results tab already open in the browser (or opens
SEARCH_URL when new_search is set or there's none), then clicks every search result
with human-like mouse movement, reads the job details pane, and appends jobs
that pass the filters in scrape.toml to CSV_PATH (deduped by jobId).
Clicks "Next" and repeats until there are no more pages. Browser settings come
from config.toml.

Usage:
    python scrape.py
"""

import asyncio
import csv
import itertools
import json
import math
import os
import random
import re
import sys
import tomllib
from datetime import datetime
from urllib.parse import parse_qs, quote_plus, urlencode, urlparse

# Playwright's bundled Node driver calls url.parse() on connect_over_cdp; hide its DEP0169 warning.
os.environ["NODE_OPTIONS"] = (os.environ.get("NODE_OPTIONS", "") + " --disable-warning=DEP0169").strip()

from playwright.async_api import async_playwright
from playwright.async_api import TimeoutError as PlaywrightTimeoutError

from browser import STEALTH, attach_browser

# ---------------------------------------------------------------------------
# scrape.py config
# ---------------------------------------------------------------------------
# Edit scrape.toml (next to this file), not these names.
_ROOT = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(_ROOT, "scrape.toml"), "rb") as _f:
    _CONFIG = tomllib.load(_f)

KEYWORDS = _CONFIG["keywords"]
CDP_URL = _CONFIG["cdp_url"]
SEARCH_URL = (
    f"https://www.linkedin.com/jobs/search-results/?keywords={quote_plus(KEYWORDS)}"
    + _CONFIG["search_filters"]
)
PAGE_SIZE = 25  # LinkedIn shows 25 results per page
START_PAGE = _CONFIG.get("start_page", 1)
if START_PAGE > 1:
    SEARCH_URL += f"&start={(START_PAGE - 1) * PAGE_SIZE}"
# False: start on a search-results tab already open in the browser, if any.
NEW_SEARCH = _CONFIG.get("new_search", True)
MAX_APPLICANTS = _CONFIG["max_applicants"]
MAX_MINUTES_AGO = _CONFIG["max_minutes_ago"]
TITLE_EXCLUDE_KEYWORDS = _CONFIG["title_exclude_keywords"]
# A work type is a <span> with exactly that text in the details pane.
WORK_TYPES = _CONFIG["work_types"]
ALL_WORK_TYPES = ["On-site", "Hybrid", "Remote"]
PAUSE_MIN_SECONDS = _CONFIG["pause_min_seconds"]
PAUSE_MAX_SECONDS = _CONFIG["pause_max_seconds"]
CLICK_ATTEMPTS = _CONFIG["click_attempts"]
MAX_PAGES = _CONFIG.get("max_pages", 0)  # 0: no limit

# Beside this file, not the working directory: view.py serves it from there.
CSV_DIR = os.path.join(_ROOT, "strict-search-results")
# {job_id: deleted_at}, written by view.py when you delete a listing in the page.
DELETED_PATH = os.path.join(CSV_DIR, "deleted.json")
# One CSV per run, named <keywords>_<start time>; capped so long keywords stay under Windows' path limit.
_SAFE_KEYWORDS = re.sub(r"[^\w-]+", "-", KEYWORDS).strip("-")[:60]
CSV_PATH = os.path.join(CSV_DIR, f"{_SAFE_KEYWORDS}_{datetime.now():%Y-%m-%d_%H-%M-%S}.csv")

# One clickable job card in the results pane. If the run reports 0 cards,
# inspect a card in DevTools and update this.
# Matching on the componentkey prefix skips the pane's footer buttons ("Privacy & Terms").
RESULT_SELECTOR = '[componentkey="SearchResultsMainContent"] div[role="button"][componentkey^="job-card-component-ref-"]'
NEXT_SELECTOR = 'button:has(span:text-is("Next"))'
DETAILS_SELECTOR ='[data-sdui-screen="com.linkedin.sdui.flagshipnav.jobs.SemanticJobDetails"]'

FIELDS = ["job_id", "title", "location", "work_type", "company", "logo", "hours_ago", "applicants", "applied", "easy_apply", "scraped_at"]


# ---------------------------------------------------------------------------
# Parsing
# ---------------------------------------------------------------------------
_POSTED_RE = re.compile(r"(\d+)\s+(minute|hour)s?\s+ago$", re.I)
_APPLIED_RE = re.compile(r"(\d[\d,]*)\s+(?:(?:people|person)\s+clicked apply|applicants)$", re.I)
_OVER_RE = re.compile(r"Over\s+(\d[\d,]*)\s+applicants", re.I)


def minutes_ago(text):
    """"3 hours ago" -> 180, "15 minutes ago" -> 15, anything else -> None."""
    m = _POSTED_RE.search((text or "").strip())
    if not m:
        return None
    n = int(m.group(1))
    return n * 60 if m.group(2).lower() == "hour" else n


def applicant_count(text):
    """"45 people clicked apply" -> 45, "1 person clicked apply" -> 1,
    "45 applicants" -> 45, "Over 100 applicants" -> 101, else None."""
    text = (text or "").strip()
    m = _OVER_RE.fullmatch(text)  # first: _APPLIED_RE would also match its "100 applicants" tail
    if m:
        return int(m.group(1).replace(",", "")) + 1
    m = _APPLIED_RE.search(text)
    return int(m.group(1).replace(",", "")) if m else None


def applicants_label(text):
    """CSV value for the applicants column: the count, "100+" for "Over 100 applicants", or None."""
    m = _OVER_RE.fullmatch((text or "").strip())
    if m:
        return m.group(1).replace(",", "") + "+"
    return applicant_count(text)


def job_id_from_url(url):
    return (parse_qs(urlparse(url).query).get("currentJobId") or [None])[0]


def _start(url):
    return int((parse_qs(urlparse(url).query).get("start") or ["0"])[0])


def page_number(url):
    """1-based result page of a search-results URL."""
    return _start(url) // PAGE_SIZE + 1


def next_page_url(url):
    """The search URL one page on, without the selected job."""
    parts = urlparse(url)
    query = parse_qs(parts.query)
    query.pop("currentJobId", None)
    query["start"] = [str(_start(url) + PAGE_SIZE)]
    return parts._replace(query=urlencode(query, doseq=True)).geturl()


# ---------------------------------------------------------------------------
# Human-like mouse
# ---------------------------------------------------------------------------
# Playwright doesn't expose the cursor position, so track it ourselves.
_mouse = [0.0, 0.0]


def human_path(a, b):
    """Points along a fresh random cubic Bezier curve from a to b. Points bunch
    up near b (ease-out), so with a per-point delay the cursor slows on arrival."""
    (ax, ay), (bx, by) = a, b
    dx, dy = bx - ax, by - ay
    dist = math.hypot(dx, dy) or 1.0
    nx, ny = -dy / dist, dx / dist  # unit normal to the straight line
    spread = max(dist * random.uniform(0.1, 0.4), 15)
    (c1x, c1y), (c2x, c2y) = [
        (ax + dx * u + nx * off, ay + dy * u + ny * off)
        for u, off in ((random.uniform(0.15, 0.4), random.uniform(-spread, spread)),
                       (random.uniform(0.6, 0.85), random.uniform(-spread, spread)))
    ]
    steps = max(15, int(dist / random.uniform(5, 12)))
    ease = random.uniform(2.0, 3.5)
    points = []
    for i in range(1, steps + 1):
        t = 1 - (1 - i / steps) ** ease
        mt = 1 - t
        points.append((
            mt**3 * ax + 3 * mt * mt * t * c1x + 3 * mt * t * t * c2x + t**3 * bx,
            mt**3 * ay + 3 * mt * mt * t * c1y + 3 * mt * t * t * c2y + t**3 * by,
        ))
    return points


async def human_click(page, locator):
    """Scroll `locator` into view, glide to a random point inside it, click."""
    await locator.scroll_into_view_if_needed(timeout=5000)
    box = await locator.bounding_box()
    if box is None:
        return False
    # Left/middle of the box: keeps clear of the dismiss "X" on job cards.
    x = box["x"] + box["width"] * random.uniform(0.15, 0.7)
    y = box["y"] + box["height"] * random.uniform(0.25, 0.75)
    for px, py in human_path(tuple(_mouse), (x, y)):
        await page.mouse.move(px, py)
        await asyncio.sleep(random.uniform(0.004, 0.016))
    _mouse[:] = [x, y]
    await page.mouse.click(x, y, delay=random.randint(40, 130))
    return True


# ---------------------------------------------------------------------------
# Scraping
# ---------------------------------------------------------------------------
async def read_details(page):
    """Read title/company/logo/posted/applicants/Easy Apply from the job details pane."""
    return await page.evaluate(
        r"""([sel, workTypes]) => {
            const root = document.querySelector(sel);
            if (!root) return null;
            const text = el => (el && el.innerText || '').trim();
            const company = root.querySelector('div[aria-label^="Company, "]');
            // Companies without a logo get an svg placeholder in the figure; don't fall through to some later img.
            const logo = root.querySelector('figure')?.querySelector('img');
            const postedEl = [...root.querySelectorAll('span > strong')]
                .find(el => /(minute|hour)s? ago$/i.test(text(el)));
            return {
                title: text(root.querySelector('p > a[href*="/jobs/view/"]')),
                company: text(company && (company.closest('a') || company.querySelector('a'))),
                logo: logo ? logo.src : '',
                posted: text(postedEl),
                // The location is the first span of the same <p> as the "N hours ago" strong.
                location: text(postedEl && postedEl.closest('p') && postedEl.closest('p').querySelector('span')),
                applied: [...root.querySelectorAll('p > span')].map(text)
                    .find(t => /clicked apply$/i.test(t))
                    || [...root.querySelectorAll('span')].map(text)
                    .find(t => /^(Over )?[\d,]+ applicants$/i.test(t)) || '',
                already_applied: [...root.querySelectorAll('span')].some(s => /^Applied( |$)/.test(text(s))),
                // Easy Apply is a <button>; other jobs get an "Apply" link to the company site.
                easy_apply: [...root.querySelectorAll('button')].some(b => text(b) === 'Easy Apply'),
                work_types: [...new Set([...root.querySelectorAll('span')].map(text)
                    .filter(t => workTypes.includes(t)))],
            };
        }""",
        [DETAILS_SELECTOR, ALL_WORK_TYPES],
    )


async def wait_for_job_change(page, old_id, timeout=5.0):
    deadline = asyncio.get_event_loop().time() + timeout
    while asyncio.get_event_loop().time() < deadline:
        job_id = job_id_from_url(page.url)
        if job_id and job_id != old_id:
            return job_id
        await asyncio.sleep(0.1)
    return None


def job_key(company, title):
    """Same employer + title counts as the same job, even under another jobId."""
    return (company.strip().lower(), title.strip().lower())


def load_deleted():
    """Job ids deleted in the results page, as a dict so each lookup is O(1)."""
    try:
        with open(DELETED_PATH, encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}


def save_row(row):
    os.makedirs(os.path.dirname(CSV_PATH), exist_ok=True)
    new_file = not os.path.exists(CSV_PATH)
    with open(CSV_PATH, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        if new_file:
            writer.writeheader()
        writer.writerow(row)


def skip_reason(details):
    """Every filter this job fails, joined with "; ", or None if it should be saved."""
    if not details or not details["title"]:
        return "no job details"
    reasons = []
    mins = minutes_ago(details["posted"])
    if mins is None:
        reasons.append("no 'hours/minutes ago'")
    elif mins > MAX_MINUTES_AGO:
        unit = _POSTED_RE.search(details["posted"].strip()).group(2).lower()
        ago = f"{mins // 60} hours" if unit == "hour" else f"{mins} min"
        reasons.append(f"posted {ago} ago (max {MAX_MINUTES_AGO} min)")
    # No "clicked apply" count shown: keep the job, the applicants column stays blank.
    applicants = applicant_count(details["applied"])
    if applicants is not None and applicants > MAX_APPLICANTS:
        reasons.append(f"{applicants_label(details['applied'])} applicants (max {MAX_APPLICANTS})")
    reasons += title_work_type_reasons(details["title"], details.get("work_types"))
    return "; ".join(reasons) or None


def title_work_type_reasons(title, work_types):
    """The filters that need only what a result card shows, so they can run before clicking it."""
    reasons = []
    excluded = [k for k in TITLE_EXCLUDE_KEYWORDS if k.lower() in title.lower()]
    if excluded:
        reasons.append(f"title has excluded keyword {excluded}")
    # No work type shown: keep the job.
    found = set(work_types or [])
    if found and (found - set(WORK_TYPES) or not found & set(WORK_TYPES)):
        reasons.append(f"not {'/'.join(WORK_TYPES)} (shows {', '.join(sorted(found))})")
    return reasons


async def read_card(card):
    """Title/company/work type from a result card, without opening it.
    The card's <p>s are title, company, location ("Bethesda, MD (Remote)")."""
    return await card.evaluate(
        r"""(card, workTypes) => {
            const ps = [...card.querySelectorAll('p')];
            const text = el => (el && el.textContent || '').trim();
            // The title <p> also holds a visually hidden "<title> (Verified job)" span.
            const title = text(ps[0] && (ps[0].querySelector('span[aria-hidden="true"]') || ps[0]));
            const m = text(ps[2]).match(/\(([^)]+)\)$/);
            return {
                job_id: (card.getAttribute('componentkey') || '').replace('job-card-component-ref-', ''),
                title, company: text(ps[1]),
                work_types: m && workTypes.includes(m[1]) ? [m[1]] : [],
            };
        }""",
        ALL_WORK_TYPES,
    )


def card_skip_reason(c, seen_ids, seen_keys, deleted):
    """Why to skip a result card without clicking it, or None to open it."""
    if c["job_id"] in deleted:
        return "deleted in the results page"
    if c["job_id"] in seen_ids:
        return "jobId already saved"
    if not c["title"]:
        return None  # card not rendered yet; let the details pane decide
    if c["company"] and job_key(c["company"], c["title"]) in seen_keys:
        return "same employer + title already saved"
    return "; ".join(title_work_type_reasons(c["title"], c["work_types"])) or None


async def scrape_page(page, page_num, seen_ids, seen_keys, deleted):
    cards = page.locator(RESULT_SELECTOR)
    print(f"\n=== Page {page_num}: {await cards.count()} card(s) ===")
    i = 0
    # Re-count each pass: LinkedIn renders more cards as the list scrolls.
    while i < await cards.count():
        card = cards.nth(i)
        i += 1
        # Scrolling (not clicking) keeps LinkedIn rendering the later cards.
        try:
            await card.scroll_into_view_if_needed(timeout=3000)
            c = await read_card(card)
        except Exception:
            c = None
        reason = c and card_skip_reason(c, seen_ids, seen_keys, deleted)
        if reason:
            print(f"  [{i}] {c['job_id']} ⏭️ skipped (card): {c['title']} @ {c['company'] or '?'},"
                  f" reason: {reason}")
            continue
        old_id = job_id_from_url(page.url)
        # The list re-renders after load and after Next, detaching the card
        # mid-click; retrying re-resolves the locator to the new element.
        error = None
        for _ in range(CLICK_ATTEMPTS):
            try:
                if await human_click(page, card):
                    error = None
                    break
                error = "card has no on-screen box to click"
            except Exception as e:
                error = f"click failed: {str(e).splitlines()[0]}"
            await asyncio.sleep(1)
        if error:
            print(f"  [{i}] ⏭️ skipped, reason: {error}")
            continue
        if "/jobs/search-results" not in page.url:
            print(f"  [{i}] ⏭️ skipped, reason: click left the search page ({page.url}), going back")
            await page.go_back()
            continue
        job_id = await wait_for_job_change(page, old_id)
        if job_id in deleted:
            print(f"  [{i}] {job_id} ⏭️ skipped, reason: deleted in the results page")
            continue
        pause = random.uniform(PAUSE_MIN_SECONDS, PAUSE_MAX_SECONDS)
        print(f"  Waiting {pause:.1f} seconds...")
        await asyncio.sleep(pause)
        if not job_id:
            try:
                what = " ".join((await card.inner_text(timeout=1000)).split())[:80]
            except Exception:
                what = "?"
            print(f"  [{i}] ⏭️ skipped, reason: jobId in the URL didn't change after the click"
                  f" (element text: {what!r})")
            continue

        details = await read_details(page)
        if job_id in seen_ids:
            reason = "jobId already saved"
        else:
            reason = skip_reason(details)
            if not reason and job_key(details["company"], details["title"]) in seen_keys:
                reason = "same employer + title already saved"
        if reason:
            label = f" {details['title'] or '?'} @ {details['company'] or '?'}," if details else ""
            print(f"  [{i}] {job_id} ⏭️ skipped:{label} reason: {reason}")
            continue
        seen_ids.add(job_id)
        seen_keys.add(job_key(details["company"], details["title"]))
        await asyncio.to_thread(save_row, {
            "job_id": job_id,
            "title": details["title"],
            "location": details["location"],
            "work_type": "/".join(sorted(details["work_types"])),
            "company": details["company"],
            "logo": details["logo"],
            "hours_ago": round(minutes_ago(details["posted"]) / 60, 2),
            "applicants": applicants_label(details["applied"]),
            "applied": str(details["already_applied"]).lower(),
            "easy_apply": str(details["easy_apply"]).lower(),
            "scraped_at": datetime.now().isoformat(timespec="seconds"),
        })
        print(f"  [{i}] {job_id} ✅ saved: {details['title']} @ {details['company']}")


async def click_next(page):
    """Click "Next" and wait for the results to change. Prints why and returns
    False when there's no next page or the click didn't load one."""
    btn = page.locator(NEXT_SELECTOR).filter(visible=True).first
    if not await btn.count():
        print(f"\n  Stopping: no visible Next button ({NEXT_SELECTOR}).")
        return False
    if not await btn.is_enabled():
        print("\n  Stopping: Next button is disabled (last page).")
        return False
    first_card = page.locator(RESULT_SELECTOR).first
    before = await first_card.inner_text() if await first_card.count() else ""
    for attempt in range(4):  # first click + 2 retries, then the URL
        if attempt < 3:
            print("\n  Clicking Next..." if not attempt else f"  Retrying Next ({attempt}/2)...")
            if not await human_click(page, btn):
                print("  Stopping: Next button has no on-screen box to click.")
                return False
        else:
            # A throttled LinkedIn can ignore Next clicks for a while; loading
            # the next page's URL still works.
            url = next_page_url(page.url)
            print(f"  Opening the next page's URL instead: {url}")
            try:
                await page.goto(url)
            except PlaywrightTimeoutError:
                pass
        deadline = asyncio.get_event_loop().time() + 15
        while asyncio.get_event_loop().time() < deadline:
            await asyncio.sleep(0.5)
            if await first_card.count() and await first_card.inner_text() != before:
                return True
        print("  The results didn't change within 15s.")
    print("  Stopping: neither Next nor the next page's URL loaded a new page.")
    return False


async def run():
    async with STEALTH.use_async(async_playwright()) as p:
        browser, started = await attach_browser(p, CDP_URL)
        # A search-results tab already open, unless new_search asks for a fresh
        # search: the one showing in its window, else the newest.
        open_tabs = [] if NEW_SEARCH or started else [
            pg for ctx in browser.contexts for pg in ctx.pages
            if "linkedin.com/jobs/search-results" in pg.url]
        shown = [pg for pg in open_tabs
                 if await pg.evaluate("document.visibilityState") == "visible"]
        if open_tabs:
            page = (shown or open_tabs)[-1]
            start_page = page_number(page.url)
            print(f"Starting on the open search tab (page {start_page}): {page.url}")
            await page.bring_to_front()
        else:
            # The default context holds the logged-in session.
            page = await browser.contexts[0].new_page()
            start_page = START_PAGE
            if started:
                try:
                    await page.goto(SEARCH_URL)
                except PlaywrightTimeoutError:
                    pass
                input("Log in to LinkedIn in the new browser, then press Enter to start the search...")
            # Login usually redirects to the feed, so (re)open the search.
            await page.goto(SEARCH_URL)
        await page.wait_for_selector(RESULT_SELECTOR, timeout=30000)

        # Dedupe within this run only; earlier runs' CSVs are not checked.
        seen_ids, seen_keys = set(), set()
        deleted = load_deleted()
        for page_num in itertools.count(start_page):
            await scrape_page(page, page_num, seen_ids, seen_keys, deleted)
            if page_num - start_page + 1 == MAX_PAGES or not await click_next(page):
                break

        print(f"\nDone. Results in {CSV_PATH}")


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")  # the emoji below crash a cp1252 stdout (Windows, redirected)
    try:
        asyncio.run(run())
    except (KeyboardInterrupt, asyncio.exceptions.CancelledError):
        print("\nStopped.")
