import os
import tomllib

import config

_EXAMPLE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config.example.toml")


def test_example_has_a_section_per_script():
    with open(_EXAMPLE, "rb") as f:
        example = tomllib.load(f)
    assert set(example) == {"browser", "scrape", "fill", "profile", "eeo"}
    assert {"cdp_url", "browser", "stealth_args"} <= set(example["browser"])
    assert {"keywords", "search_filters"} <= set(example["scrape"])
    assert {"submit_application", "resume_rules", "screening"} <= set(example["fill"])


def test_sections_are_exposed_as_config_names():
    assert config.CDP_URL and config.STANDARD_ARGS      # [browser]
    assert config.SUBMIT_APPLICATION in (True, False)    # [fill]
    assert isinstance(config.SCREENING, dict)            # [fill.screening]
    assert config.SCRAPE["keywords"]                     # [scrape]
