import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import filler
import config


def test_profile_field_hint(monkeypatch):
    monkeypatch.setattr(config, "PROFILE", {"email": "me@x.com", "first_name": "Will"})
    monkeypatch.setattr(config, "EEO", {})
    assert filler._hint_value("Email address") == ("profile:email", "me@x.com")
    assert filler._hint_value("First name") == ("profile:first_name", "Will")


def test_eeo_checked_before_profile(monkeypatch):
    # "gender" must resolve to EEO, not be mistaken for a profile field.
    monkeypatch.setattr(config, "EEO", {"gender": "Decline"})
    monkeypatch.setattr(config, "PROFILE", {})
    assert filler._hint_value("Gender") == ("eeo", "Decline")


def test_sexual_orientation_not_mistaken_for_gender(monkeypatch):
    # "sexual orientation" contains "sex" -- must not match the gender hint.
    monkeypatch.setattr(config, "EEO", {"gender": "M", "sexual_orientation": "Decline"})
    monkeypatch.setattr(config, "PROFILE", {})
    assert filler._hint_value("How would you describe your sexual orientation?") \
        == ("eeo", "Decline")


def test_transgender_not_mistaken_for_gender(monkeypatch):
    # "transgender" contains "gender" -- must not match the gender hint.
    monkeypatch.setattr(config, "EEO", {"gender": "M", "transgender": "Decline"})
    monkeypatch.setattr(config, "PROFILE", {})
    assert filler._hint_value("Do you identify as transgender?") == ("eeo", "Decline")


def test_gender_identity_still_matches_gender(monkeypatch):
    monkeypatch.setattr(config, "EEO", {"gender": "M"})
    monkeypatch.setattr(config, "PROFILE", {})
    assert filler._hint_value("How would you describe your gender identity?") \
        == ("eeo", "M")


def test_work_authorization_hint(monkeypatch):
    monkeypatch.setattr(config, "EEO", {
        "authorized_to_work": "Yes", "require_sponsorship": "No"})
    monkeypatch.setattr(config, "PROFILE", {})
    assert filler._hint_value("Are you legally authorized to work?") == ("eeo", "Yes")
    assert filler._hint_value("Do you require sponsorship?") == ("eeo", "No")


# --- Yes/No button questions (Ashby-style) ---
# _fill_yesno_buttons reads the question text via JS evaluate, maps it through
# _hint_value, then clicks Yes if value.lower() in ("yes","true","1"), else No.
# These tests cover the two layers: hint resolution and click decision.

def test_yesno_without_employer_sponsorship_flips(monkeypatch):
    # Ashby: "Are you legally authorized to work in your current country of
    # residence without employer sponsorship?"
    # Routes to require_sponsorship (contains "without employer sponsorship" —
    # an inverse phrase), so "No" flips to "Yes" -> click Yes.
    monkeypatch.setattr(config, "EEO", {"require_sponsorship": "No"})
    monkeypatch.setattr(config, "PROFILE", {})
    _, val = filler._hint_value(
        "Are you legally authorized to work in your current country of residence without employer sponsorship?"
    )
    assert str(val).lower() == "yes"


def test_yesno_require_visa_sponsorship_direct(monkeypatch):
    # Ashby: "Do you now, or will you in the future, require visa sponsorship
    # for legal employment to work remotely in your country of residence?"
    # Direct phrasing — no flip — so "No" stays "No" -> click No.
    monkeypatch.setattr(config, "EEO", {"require_sponsorship": "No"})
    monkeypatch.setattr(config, "PROFILE", {})
    _, val = filler._hint_value(
        "Do you now, or will you in the future, require visa sponsorship for legal employment to work remotely in your country of residence?"
    )
    assert str(val).lower() == "no"


def test_yesno_click_yes_when_value_is_yes():
    assert str("Yes").lower() in ("yes", "true", "1")


def test_yesno_click_no_when_value_is_no():
    assert str("No").lower() not in ("yes", "true", "1")


def test_sponsorship_inverse_phrasing_flips_answer(monkeypatch):
    # "without sponsorship" is the inverse framing: if we don't need sponsorship
    # (require_sponsorship="No"), the correct answer to "can you work without
    # sponsorship?" is "Yes".
    monkeypatch.setattr(config, "EEO", {"require_sponsorship": "No"})
    monkeypatch.setattr(config, "PROFILE", {})
    assert filler._hint_value(
        "Are you eligible to work in the United States now or in the future without sponsorship?"
    ) == ("eeo", "Yes")


def test_sponsorship_direct_phrasing_unchanged(monkeypatch):
    # Direct "do you require sponsorship?" must NOT be flipped.
    monkeypatch.setattr(config, "EEO", {"require_sponsorship": "No"})
    monkeypatch.setattr(config, "PROFILE", {})
    assert filler._hint_value("Do you require sponsorship?") == ("eeo", "No")
    assert filler._hint_value("Will you now or in the future require visa sponsorship?") == ("eeo", "No")


def test_sponsorship_inverse_when_needs_sponsorship(monkeypatch):
    # If the user DOES need sponsorship (require_sponsorship="Yes"), the answer
    # to "can you work without sponsorship?" should be "No".
    monkeypatch.setattr(config, "EEO", {"require_sponsorship": "Yes"})
    monkeypatch.setattr(config, "PROFILE", {})
    assert filler._hint_value(
        "Are you eligible to work without sponsorship?"
    ) == ("eeo", "No")


def test_right_to_work_or_sponsorship_radio_options(monkeypatch):
    # Ashby (monday.com): a radio group whose options aren't Yes/No.
    q = ("Do you have the legal right to work in the country where this role is "
         "based, or would you require visa sponsorship from our company?")
    options = ["Authorized to work (No sponsorship required)", "Requires visa sponsorship"]
    monkeypatch.setattr(config, "PROFILE", {})
    for need, want in (("No", 0), ("Yes", 1)):
        monkeypatch.setattr(config, "EEO", {"require_sponsorship": need})
        _, value = filler._hint_value(q)
        assert filler.choice_option_index(q, value, options) == want


def test_unknown_field_returns_none(monkeypatch):
    monkeypatch.setattr(config, "EEO", {})
    monkeypatch.setattr(config, "PROFILE", {})
    assert filler._hint_value("Favorite color") == (None, None)


# --- best_option_index: the reusable option-matcher used for native <select>
#     and react-select keyboard navigation alike ---

def test_best_option_exact_match():
    opts = ["Yes", "No", "Decline to self-identify"]
    assert filler.best_option_index("Yes", opts) == 0


def test_best_option_value_substring_of_option():
    opts = ["Female", "Male", "Decline to self-identify"]
    assert filler.best_option_index("decline", opts) == 2


def test_best_option_option_substring_of_value():
    opts = ["Yes", "No"]
    assert filler.best_option_index("Yes, I require sponsorship", opts) == 0


def test_best_option_word_overlap_pronouns():
    # config "he/him/his" should match an option labelled "He/Him"
    opts = ["She/Her", "He/Him", "They/Them", "Prefer not to say"]
    assert filler.best_option_index("he/him/his", opts) == 1


def test_best_option_decline_family_fallback():
    # config says "Decline to self-identify" but this form calls it "I don't wish to answer"
    opts = ["Male", "Female", "I don't wish to answer"]
    assert filler.best_option_index("Decline to self-identify", opts) == 2


def test_best_option_not_listed_is_decline_signal():
    opts = ["He/Him", "She/Her", "Not listed"]
    assert filler.best_option_index("prefer not to say", opts) == 2


def test_best_option_decline_beats_self_describe():
    # "Decline to self-identify" must map to "I don't wish to answer", NOT to
    # "I wish to self-describe" (the two only share the stopword "to").
    opts = ["Asian", "White", "I wish to self-describe", "I don't wish to answer"]
    assert filler.best_option_index("Decline to self-identify", opts) == 3


def test_best_option_prefer_to_self_describe_is_not_decline():
    # "I prefer to self-describe" is volunteering info, NOT declining -- must not
    # win over the real decline option just because it contains "prefer".
    opts = ["Asian", "White", "I prefer to self-describe", "I don't wish to answer"]
    assert filler.best_option_index("Decline to self-identify", opts) == 3


# --- max_salary_in_text: pull the top of a salary range from a job description ---

def test_salary_range_returns_max():
    text = "Salary range, depending on experience:\n\n$115,000 - $130,000 USD"
    assert filler.max_salary_in_text(text) == "130000"


def test_salary_k_shorthand():
    assert filler.max_salary_in_text("We offer $130k - $160k") == "160000"


def test_salary_single_value():
    assert filler.max_salary_in_text("Compensation: $200,000") == "200000"


def test_salary_none_when_no_money():
    assert filler.max_salary_in_text("5+ years experience, founded in 2024") is None


def test_salary_label_detection():
    assert filler._is_salary_label("What are your salary expectations?")
    assert filler._is_salary_label("Base salary")
    assert filler._is_salary_label("Compensation expectations")
    assert not filler._is_salary_label("First name")


def test_best_option_stopword_only_overlap_is_no_match():
    # Sharing only stopwords ("to") must not count as a match.
    opts = ["Relocate to the office", "Work from home"]
    assert filler.best_option_index("Are you able to travel", opts) is None


def test_best_option_no_match_returns_none():
    opts = ["Red", "Green", "Blue"]
    assert filler.best_option_index("Decline to self-identify", opts) is None


# --- location_availability_answer: timezone/region "are you based in X?" questions.
#     Works for Yes/No, select, and free-text inputs (returns a plain string). ---

_PST_PROFILE = {"timezone": "PST",
                "based_in_regions": ["pst", "pacific", "san francisco", "bay area",
                                     "california", "us", "remote"]}


def test_location_avail_matching_region_yes():
    q = "Are you based in the San Francisco Bay area/PST time zone?"
    assert filler.location_availability_answer(q, _PST_PROFILE) == "Yes"


def test_location_avail_nonmatching_region_no():
    q = "Are you located in the EST time zone?"
    assert filler.location_availability_answer(q, _PST_PROFILE) == "No"


def test_location_avail_open_question_returns_timezone():
    q = "What time zone are you in?"
    assert filler.location_availability_answer(q, _PST_PROFILE) == "PST"


def test_location_avail_california_yes():
    assert filler.location_availability_answer("Do you live in California?", _PST_PROFILE) == "Yes"


def test_location_avail_not_a_location_question():
    assert filler.location_availability_answer("What is your favorite color?", _PST_PROFILE) is None
    assert filler.location_availability_answer("What pronouns do you use?", _PST_PROFILE) is None


def test_location_avail_routes_through_hint_value(monkeypatch):
    monkeypatch.setattr(config, "EEO", {})
    monkeypatch.setattr(config, "PROFILE", _PST_PROFILE)
    src, val = filler._hint_value("Are you based in the PST time zone?")
    assert src == "location_avail"
    assert val == "Yes"


# --- years of experience ---

def test_years_of_experience_hint(monkeypatch):
    monkeypatch.setattr(config, "EEO", {})
    monkeypatch.setattr(config, "PROFILE", {"years_of_experience": 6, "current_company": "X"})
    yoe = ("profile:years_of_experience", 6)
    assert filler._hint_value("Years of experience") == yoe
    assert filler._hint_value("How many years of professional experience do you have?") == yoe
    assert filler._hint_value("YOE") == yoe
    # Not swallowed by the company hint.
    assert filler._hint_value("Years of experience at a startup company") == yoe


def test_years_of_experience_threshold_question(monkeypatch):
    monkeypatch.setattr(config, "EEO", {})
    monkeypatch.setattr(config, "PROFILE", {"years_of_experience": 6})
    assert filler._hint_value("Do you have 5+ years of experience with React?") \
        == ("profile:years_of_experience", "Yes")
    assert filler._hint_value("Do you have 8 or more years of experience?") \
        == ("profile:years_of_experience", "No")


def test_years_needs_experience(monkeypatch):
    # "years" alone (age questions) is not a YOE field.
    monkeypatch.setattr(config, "EEO", {})
    monkeypatch.setattr(config, "PROFILE", {"years_of_experience": 6})
    assert filler._hint_value("Are you at least 18 years of age?")[0] != "profile:years_of_experience"
    assert filler._hint_value("Tell us about your experience")[0] != "profile:years_of_experience"


def test_best_option_index_numeric_ranges():
    opts = ["Select...", "0-2 years", "3-5 years", "6-9 years", "10+ years"]
    assert filler.best_option_index("6", opts) == 3
    assert filler.best_option_index(12, opts) == 4
    assert filler.best_option_index("1", ["Less than 2", "2-4", "5+"]) == 0
    assert filler.best_option_index("150000", ["$100,000 - $150,000", "$150,001+"]) == 0


def test_best_option_index_bounded_ranges():
    opts = ["Select...", "Less than 6 tears", "6 - 8 years", "8 - 10 years", "more than 10 years"]
    assert filler.best_option_index("5", opts) == 1
    assert filler.best_option_index("6", opts) == 2
    assert filler.best_option_index("9", opts) == 3
    assert filler.best_option_index("10", opts) == 3
    assert filler.best_option_index("11", opts) == 4
    opts = ["Under 2 years", "2–4 years", "5 or more years"]
    assert filler.best_option_index("1", opts) == 0
    assert filler.best_option_index("3", opts) == 1
    assert filler.best_option_index("5", opts) == 2
    assert filler.best_option_index("4", ["Up to 4 years", "At least 5 years"]) == 0
    assert filler.best_option_index("7", ["Up to 4 years", "At least 5 years"]) == 1
    assert filler.best_option_index("5", ["Under 5", "5 years and above"]) == 1


def test_best_option_index_preference_list():
    # A list value is ordered preferences, matched exactly -- no loose fallback.
    prefs = ["Public Policy", "Public Policy Analysis", "Public Administration"]
    opts = ["Public Administration", "Public Health", "Public Policy", "Public Relations"]
    assert filler.best_option_index(prefs, opts) == 2
    assert filler.best_option_index(prefs, ["Public Administration", "Public Health"]) == 0
    assert filler.best_option_index(prefs, ["Public Health", "Political Science"]) is None


def test_link_fields_not_swallowed_by_name(monkeypatch):
    # "Username" contains "name" -- must not match the full_name hint.
    monkeypatch.setattr(config, "EEO", {})
    monkeypatch.setattr(config, "PROFILE", {"first_name": "A", "last_name": "B",
                                             "github": "gh", "website": "site"})
    assert filler._hint_value("Github Username / Profile*") == ("profile:github", "gh")
    assert filler._hint_value("Portfolio name or URL") == ("profile:website", "site")
    assert filler._hint_value("Full name") == ("profile:full_name", "A B")
    assert filler._hint_value("Your name") == ("profile:full_name", "A B")


def test_background_check(monkeypatch):
    monkeypatch.setattr(config, "EEO", {"background_check": True, "authorized_to_work": True})
    monkeypatch.setattr(config, "PROFILE", {"state": "CA"})
    q = ("If extended an offer of employment, would you be willing to consent to a "
         "background check conducted in accordance with applicable law?*")
    assert filler._hint_value(q) == ("eeo", "Yes")
    assert filler._hint_value("Do you consent to a background check in your state?") == ("eeo", "Yes")


def test_street_address_not_location(monkeypatch):
    # "Address Line 1" is a street address -- must not get "City, State".
    monkeypatch.setattr(config, "EEO", {})
    monkeypatch.setattr(config, "PROFILE", {"city": "Springfield", "state": "IL"})
    assert filler._hint_value("address1 | Address Line 1")[0] == "profile:street_address"
    assert filler._hint_value("Street Address")[0] == "profile:street_address"
    assert filler._hint_value("Email Address")[0] == "profile:email"
    assert filler._hint_value("Address") == ("profile:location", "Springfield, IL")


def test_where_you_are_located_is_location(monkeypatch):
    # Ashby free-text question; "located" alone is too broad ("are you located in PST?").
    monkeypatch.setattr(config, "EEO", {})
    monkeypatch.setattr(config, "PROFILE", {"city": "Springfield", "state": "IL"})
    label = "a22719fa-62d8-4907-b3b4-8943cdc1a2c0 | Please tell us where you are located. | Type here..."
    assert filler._hint_value(label) == ("profile:location", "Springfield, IL")
    assert filler._hint_value("Where are you located?") == ("profile:location", "Springfield, IL")


def test_country_dialing_code_uses_country(monkeypatch):
    # Dayforce: "Country dialing code" must get the country, not the phone number.
    monkeypatch.setattr(config, "EEO", {})
    monkeypatch.setattr(config, "PROFILE", {"country": "United States", "phone": "5551234567"})
    assert filler._hint_value("rc_select_4 | Country dialing code | Home Phone Number") \
        == ("profile:country", "United States")


def test_best_option_index_prefers_closest_substring():
    dial = ["🇦🇬 +1 Antigua and Barbuda", "🇨🇦 +1 Canada", "🇺🇸 +1 United States of America"]
    assert filler.best_option_index("United States", dial) == 2
    countries = ["United Kingdom", "United States Minor Outlying Islands", "United States of America"]
    assert filler.best_option_index("United States", countries) == 2


def test_preferred_contact_method(monkeypatch):
    monkeypatch.setattr(config, "EEO", {})
    monkeypatch.setattr(config, "PROFILE", {"preferred_contact_method": "Email", "email": "e"})
    assert filler._hint_value("preferredContactMethod | Preferred Contact Method") \
        == ("profile:preferred_contact_method", "Email")


def test_skill_question_yes_when_resume_mentions_it(monkeypatch):
    monkeypatch.setattr(config, "EEO", {})
    monkeypatch.setattr(config, "PROFILE", {})
    monkeypatch.setattr(filler, "RESUME_TEXT", "Built UIs in React and TypeScript.")
    assert filler._hint_value("Have you worked with React in a production environment?") \
        == ("skill", "Yes")
    assert filler._hint_value("Do you have experience with TypeScript?") == ("skill", "Yes")
    assert filler._hint_value("Have you worked with Vue or React?") == ("skill", "Yes")


def test_skill_question_left_for_manual_when_resume_silent(monkeypatch):
    # Not on the resume -> don't claim it, and don't answer No for the user either.
    monkeypatch.setattr(config, "EEO", {})
    monkeypatch.setattr(config, "PROFILE", {})
    monkeypatch.setattr(filler, "RESUME_TEXT", "Built UIs in React.")
    assert filler._hint_value("Have you worked with Kotlin in production?") == (None, None)


def test_skill_question_word_boundary(monkeypatch):
    # "Go" must not match inside "Google".
    monkeypatch.setattr(config, "EEO", {})
    monkeypatch.setattr(config, "PROFILE", {})
    monkeypatch.setattr(filler, "RESUME_TEXT", "Worked at Google.")
    assert filler._hint_value("Have you worked with Go?") == (None, None)


def test_skill_years_question_still_years_of_experience(monkeypatch):
    monkeypatch.setattr(config, "EEO", {})
    monkeypatch.setattr(config, "PROFILE", {"years_of_experience": 7})
    monkeypatch.setattr(filler, "RESUME_TEXT", "TypeScript")
    assert filler._hint_value(
        "How many years of experience do you have working with TypeScript?") \
        == ("profile:years_of_experience", 7)


def test_skill_question_keeps_dotted_names(monkeypatch):
    monkeypatch.setattr(filler, "RESUME_TEXT", "APIs in Node.js")
    assert filler.skill_question_answer("Have you worked with Node.js?") == "Yes"
    assert filler.skill_question_answer("Do you have experience with Rust.") is None


def test_why_interested_questions():
    for q in ("Why do you want to work here?", "Why do you want to work for us?",
              "Why do you want to work for our company?", "Why Quo?",
              "Why are you interested in joining Quo?", "What interests you about this role?",
              "What draws you to Quo?", "Why would you like to join our team?"):
        assert filler.is_why_interested(q, "Quo"), q
    for q in ("Cover letter", "Anything else you'd like us to know?",
              "Why are you leaving your current role?", "Company"):
        assert not filler.is_why_interested(q, "Quo"), q


def test_why_interested_text_unwraps_lines(monkeypatch):
    import config
    monkeypatch.setattr(config, "WHY_INTERESTED_DEFAULT",
                        "One two\nthree at {company}.\n\nFour\nfive.\n")
    assert filler.why_interested_text("Quo") == "One two three at Quo.\n\nFour five."


def test_sponsorship_inverse_with_words_between(monkeypatch):
    # "without REQUIRING sponsorship" is the inverse framing too.
    monkeypatch.setattr(config, "EEO", {"authorized_to_work": "Yes", "require_sponsorship": "No"})
    monkeypatch.setattr(config, "PROFILE", {})
    q = ("Are you legally authorized to work in the United States or Canada without "
         "requiring sponsorship now or in the future?")
    assert filler._hint_value(q) == ("eeo", "Yes")
    assert filler._hint_value("Can you work here without needing visa sponsorship?") == ("eeo", "Yes")
    assert filler._hint_value("Will you not require sponsorship?") == ("eeo", "Yes")


def test_authorized_without_sponsorship_needs_authorization(monkeypatch):
    # Not authorized at all -> "authorized ... without sponsorship?" is No.
    monkeypatch.setattr(config, "EEO", {"authorized_to_work": "No", "require_sponsorship": "No"})
    monkeypatch.setattr(config, "PROFILE", {})
    assert filler._hint_value(
        "Are you legally authorized to work in the US without requiring sponsorship?") == ("eeo", "No")


def test_residence_question_is_country(monkeypatch):
    # "United States" contains "state" -- must not be taken for the state field.
    monkeypatch.setattr(config, "EEO", {})
    monkeypatch.setattr(config, "PROFILE", {"country": "United States", "state": "CA"})
    q = ("We would like to hire this role into the United States or Canada. "
         "Please confirm your current residence.")
    assert filler._hint_value(q) == ("profile:country", "United States")
    assert filler._hint_value("Which country do you currently live in?") == \
        ("profile:country", "United States")
    assert filler._hint_value("Country of residence") == ("profile:country", "United States")
    assert filler._hint_value("State") == ("profile:state", "CA")


def test_united_states_not_taken_for_state_field(monkeypatch):
    monkeypatch.setattr(config, "EEO", {})
    monkeypatch.setattr(config, "PROFILE", {"state": "CA", "based_in_regions": ["united states"]})
    assert filler._hint_value("Are you based in the United States?") == ("location_avail", "Yes")


def test_linkedin_url_gets_www(monkeypatch):
    monkeypatch.setattr(config, "EEO", {})
    for given in ("https://linkedin.com/in/someone", "linkedin.com/in/someone",
                  "http://linkedin.com/in/someone", "https://www.linkedin.com/in/someone"):
        monkeypatch.setattr(config, "PROFILE", {"linkedin": given})
        assert filler._hint_value("LinkedIn Profile") == \
            ("profile:linkedin", "https://www.linkedin.com/in/someone"), given


def test_honeypot_detected():
    # Workday's beecatcher: "Enter website" would otherwise hit the website hint.
    assert filler.is_honeypot("beecatcher | Enter website. This input is for robots only, do not enter if you're human.")
    assert filler.is_honeypot("beecatcher")
    assert not filler.is_honeypot("Website | Personal website")


def test_postal_code_not_taken_for_location(monkeypatch):
    # Workday's id "addressSection_postalCode" contains "address" -> location.
    monkeypatch.setattr(config, "EEO", {})
    monkeypatch.setattr(config, "PROFILE", {"postal_code": "12345", "city": "X", "state": "Y"})
    for label in ("addressSection_postalCode | Postal Code", "Postal Code", "ZIP code", "Zip"):
        assert filler._hint_value(label) == ("profile:postal_code", "12345"), label
    # Codes that aren't postal still go elsewhere.
    assert filler._hint_value("Country Code")[0] != "profile:postal_code"


SALESFORCE_Q = ("Have you previously worked for Salesforce as an employee or contractor, or are you "
                "a current Salesforce contractor? CURRENT EMPLOYEES: Please apply internally.")


def test_previous_worker_no_unless_listed(monkeypatch):
    import config
    monkeypatch.setattr(config, "PREVIOUS_EMPLOYERS", ["Microsoft"])
    monkeypatch.setattr(config, "EEO", {"require_sponsorship": "No"})
    monkeypatch.setattr(config, "PROFILE", {"current_company": "Acme"})
    assert filler._hint_value(SALESFORCE_Q, "Salesforce, Inc.") == ("previous_worker", "No")
    assert filler._hint_value("Have you ever worked for us before?", "Acme Corp") == ("previous_worker", "No")
    assert filler._hint_value("Are you a current or former employee of Quo?", "Quo") == ("previous_worker", "No")
    q = "Have you ever been employed by Microsoft as an employee, contractor, or vendor?"
    assert filler._hint_value(q, "Microsoft Corporation") == ("previous_worker", "Yes")


def test_previous_worker_not_confused(monkeypatch):
    import config
    monkeypatch.setattr(config, "PREVIOUS_EMPLOYERS", ["Microsoft"])
    monkeypatch.setattr(config, "EEO", {"require_sponsorship": "No"})
    monkeypatch.setattr(config, "PROFILE", {})
    monkeypatch.setattr(filler, "RESUME_TEXT", "React")
    assert filler._hint_value("Have you worked with React before?", "Acme")[0] == "skill"
    # Sponsorship ("...ever require sponsorship to work in the US") stays EEO.
    assert filler._hint_value("Will you ever require sponsorship to work in the US?", "Acme")[0] == "eeo"


UNRESTRICTED_Q = ("Do you have the unrestricted right to work in the country to which you're applying? "
                  "(You must answer \"No\" if you are on any visa or possess any government issued work "
                  "authorization document that has an expiration date)")


def test_unrestricted_right_to_work(monkeypatch):
    # Mentions "visa" but isn't the sponsorship question.
    monkeypatch.setattr(config, "PROFILE", {})
    monkeypatch.setattr(config, "EEO", {"authorized_to_work": "Yes", "require_sponsorship": "No"})
    assert filler._hint_value(UNRESTRICTED_Q) == ("eeo", "Yes")
    monkeypatch.setattr(config, "EEO", {"authorized_to_work": "Yes", "require_sponsorship": "Yes"})
    assert filler._hint_value(UNRESTRICTED_Q) == ("eeo", "No")


def test_acknowledgment_statements_are_yes(monkeypatch):
    monkeypatch.setattr(config, "PROFILE", {"state": "NV", "city": "X"})
    monkeypatch.setattr(config, "EEO", {"require_sponsorship": "No"})
    for s in ("I understand that upon employment, proof of legal right to work in the US and "
              "completion of an I-9 form will be required.",
              "I attest/confirm that I have no post-government employment restrictions that have "
              "not already been addressed or disclosed in the previous questions.",
              "I acknowledge that I have read, reviewed and answered the above questions truthfully. "
              "Please select \"yes\" if you acknowledge."):
        assert filler._hint_value(s) == ("acknowledgment", "Yes"), s[:40]
    # A question isn't an acknowledgment.
    assert filler._hint_value("I understand React. Do you?")[0] != "acknowledgment"


def test_long_question_not_matched_on_field_words(monkeypatch):
    # "federal, state, or local" isn't the State field.
    monkeypatch.setattr(config, "PROFILE", {"state": "NV", "country": "United States"})
    monkeypatch.setattr(config, "EEO", {})
    q = ("Government Employment: In the last 5 years, have you been an employee of a U.S. federal, "
         "state, or local government, including a \"special Government employee\" (defined under "
         "18 U.S.C. §202), or a member of the U.S. Armed Services?")
    assert filler._hint_value(q)[0] != "profile:state"
    # Short labels still work.
    assert filler._hint_value("State") == ("profile:state", "NV")
    assert filler._hint_value("State*") == ("profile:state", "NV")


GOV_Q = ("Government Employment: In the last 5 years, have you been an employee of a U.S. federal, "
         "state, or local government, including a \"special Government employee\" (defined under "
         "18 U.S.C. §202), or a member of the U.S. Armed Services (including Reserve and Guard components)?")
DEBAR_Q = ("Are you currently or have you in the past been debarred, suspended, proposed for "
           "debarment or declared ineligible for award of a contract by any federal agency?")
EXPORT_Q = ("As a U.S. company that exports software and technology internationally, we must comply "
            "with U.S. export control laws. Are you a citizen, national or permanent resident of "
            "Iran, Cuba, North Korea or Syria?")
FUTURE_Q = "Regarding future positions at Salesforce, please select one of the following options"


def test_screening_questions(monkeypatch):
    import config
    monkeypatch.setattr(config, "SCREENING", {
        "government_employee": "No", "debarred": "No",
        "sanctioned_country_citizen": "No", "future_job_contact": "No"})
    monkeypatch.setattr(config, "PROFILE", {"state": "NV", "country": "United States"})
    monkeypatch.setattr(config, "EEO", {"require_sponsorship": "No", "veteran_status": "No"})
    for q in (GOV_Q, DEBAR_Q, EXPORT_Q, FUTURE_Q):
        assert filler._hint_value(q, "Salesforce, Inc.") == ("screening", "No"), q[:40]


AGE_QS = [
    ("Accenture is committed to not hiring employees who are not of the minimum legal age to "
     "work. For individuals under the age of 18 we have to confirm that they are legally "
     "entitled to work. Are you at least 18 years of age?*"),
    "Are you at least 18 years of age?*",
    "Are you 18 years or older?",
    "Are you over the age of 18?",
]
NONCOMPETE_Q = ("Have you entered into a non-disclosure, non-solicit, or non-compete agreement or "
                "understanding of any kind? This may have been in an offer letter, employment "
                "agreement, agreement signed with a promotion, handbook acknowledgement or other "
                "type of agreement.*")


def test_age_and_restrictive_agreement_questions(monkeypatch):
    import config
    monkeypatch.setattr(config, "SCREENING", {"of_legal_age": "Yes", "restrictive_agreement": "No"})
    monkeypatch.setattr(config, "PROFILE", {"state": "NV", "country": "United States"})
    monkeypatch.setattr(config, "EEO", {"authorized_to_work": "Yes", "require_sponsorship": "No"})
    for q in AGE_QS:
        assert filler._hint_value(q, "Accenture") == ("screening", "Yes"), q[:40]
    assert filler._hint_value(NONCOMPETE_Q, "Accenture") == ("screening", "No")
    assert filler._hint_value("Do you have a non-compete agreement?", "Acme") == ("screening", "No")
    # Not swallowed: "18 years of experience" stays a years-of-experience question.
    assert filler._hint_value("How many years of experience do you have?", "Acme")[0] != "screening"


def test_yes_no_prefers_option_starting_with_it():
    opts = ["Select One", "Yes, notify", "No, please do not contact me"]
    assert filler.best_option_index("No", opts) == 2
    assert filler.best_option_index("Yes", opts) == 1


VETERAN_OPTS = ["Select One",
                "I identify as one or more of the classifications of protected veterans listed above.",
                "I identify as a veteran, just not a protected veteran.",
                "I am not a veteran.",
                "I do not wish to self-identify."]


def test_negated_value_never_picks_the_affirmative_option():
    # Word overlap alone ("protected") picked the protected-veteran option.
    assert filler.best_option_index("I am not a protected veteran", VETERAN_OPTS) == 3


def test_terms_consent_is_acknowledgment(monkeypatch):
    monkeypatch.setattr(config, "PROFILE", {})
    monkeypatch.setattr(config, "EEO", {})
    label = ("acceptTermsAndAgreements | termsAndConditions--acceptTermsAndAgreements | "
             "Yes, I have read and consent to the terms and conditions*")
    assert filler._hint_value(label) == ("acknowledgment", "Yes")


def test_phone_extension_not_phone(monkeypatch):
    monkeypatch.setattr(config, "EEO", {})
    monkeypatch.setattr(config, "PROFILE", {"phone": "5550100"})
    assert filler._hint_value("phoneNumber--extension | Phone Extension") == ("profile:phone_extension", None)
    assert filler._hint_value("Phone Number") == ("profile:phone", "5550100")


def test_school_name_not_last_name(monkeypatch):
    # "schoolName" contains "lname".
    monkeypatch.setattr(config, "EEO", {})
    monkeypatch.setattr(config, "PROFILE", {"school": "U of A", "last_name": "Doe", "first_name": "J"})
    assert filler._hint_value("schoolName | education-4--schoolName | School or University") == ("profile:school", "U of A")
    assert filler._hint_value("lname") == ("profile:last_name", "Doe")
    assert filler._hint_value("applicant_lname") == ("profile:last_name", "Doe")
    assert filler._hint_value("fname") == ("profile:first_name", "J")


def test_work_history_location_never_home_location():
    label = "location | workExperience-16--location | Location | Location"
    assert filler.leave_for_user("profile:location", label, required=False)
    assert filler.leave_for_user("profile:location", label, required=True)
    assert filler.leave_for_user("profile:city", "Work Location", required=False)
    # Your own address fields still fill.
    assert not filler.leave_for_user("profile:location", "Location*", required=True)
    assert not filler.leave_for_user("profile:city", "address--city | City*", required=True)


def test_field_of_study_only_when_required():
    label = "education-376--fieldOfStudy | Search | Field of Study | Field of Study"
    assert filler.leave_for_user("profile:discipline", label, required=False)
    assert not filler.leave_for_user("profile:discipline", label, required=True)


def test_new_address_fields_only_when_required():
    assert filler.leave_for_user("profile:street_address", "Street address", required=False)
    assert not filler.leave_for_user("profile:street_address", "Address Line 1*", required=False)
    assert not filler.leave_for_user("profile:street_address", "Address Line 1", required=True)
    assert filler.leave_for_user("profile:postal_code", "Zip code", required=False)
    assert not filler.leave_for_user("profile:postal_code", "Postal Code*", required=False)


def test_describe_flat_form_uses_own_label_not_first_sibling_label():
    # rustlabs.ai: every <label for> and <input> are siblings in one section.
    # The walk-up took the section's first label ("Full name") for every field,
    # so Email and Phone got the full name.
    import asyncio
    from playwright.async_api import async_playwright

    html = """<form><section><p>You</p>
      <label for="qa-name">Full name</label><input id="qa-name" name="full_name">
      <label for="qa-email">Email</label><input id="qa-email" type="email" name="email">
      <label for="qa-phone">Mobile number, with country code</label>
      <input id="qa-phone" type="tel" name="phone">
      <label>Years as a professional software engineer</label>
      <div role="radiogroup"><label><input type="radio" name="yrs"><span>5+</span></label></div>
      <label for="qa-linkedin">LinkedIn profile link</label><input id="qa-linkedin">
    </section></form>"""

    async def describe_all():
        async with async_playwright() as p:
            browser = await p.chromium.launch()
            page = await browser.new_page()
            await page.set_content(html)
            out = [await filler._describe(page.locator(f"#{i}"))
                   for i in ("qa-name", "qa-email", "qa-phone", "qa-linkedin")]
            await browser.close()
            return out

    name, email, phone, linkedin = asyncio.run(describe_all())
    assert "Full name" in name
    assert "Full name" not in email and "Email" in email
    assert "Full name" not in phone and "Mobile number" in phone
    # An unattached label earlier in the container isn't this field's label.
    assert "Years" not in linkedin and "LinkedIn profile link" in linkedin


def test_phone_with_country_code_is_phone(monkeypatch):
    # "country code" is the dial-code dropdown hint; a phone number that must
    # include one is still the phone field.
    monkeypatch.setattr(config, "PROFILE", {"phone": "555", "country": "US"})
    monkeypatch.setattr(config, "EEO", {})
    assert filler._hint_value("phone | Mobile number, with country code") == ("profile:phone", "555")
    assert filler._hint_value("Phone number (including country code)") == ("profile:phone", "555")
    assert filler._hint_value("Country code")[0] == "profile:country"


# --- Workday labels, as _describe builds them on the live form.

def test_middle_name_not_swallowed_by_full_name(monkeypatch):
    # "middleName" contains "name"; with no middle_name configured it's skipped.
    monkeypatch.setattr(config, "PROFILE", {"first_name": "Will", "last_name": "H"})
    monkeypatch.setattr(config, "EEO", {})
    label = "middleName | name--middleName | Middle Name | Middle Name"
    assert filler._hint_value(label) == ("profile:middle_name", None)


def test_work_history_fields_left_alone(monkeypatch):
    # Each entry is one past job (from the resume parse): never your profile's
    # name, title, location, or years of experience.
    monkeypatch.setattr(config, "PROFILE", {"first_name": "Will", "last_name": "H",
                                            "years_of_experience": 8})
    monkeypatch.setattr(config, "EEO", {})
    for label in ("companyName | workExperience-447--companyName | Company* | Company*",
                  "jobTitle | workExperience-447--jobTitle | Job Title* | Job Title*",
                  "workExperience-447--startDate-dateSectionYear-input | Year | 09"):
        source, _ = filler._hint_value(label)
        assert filler.leave_for_user(source, label, required=True), label


def test_indexed_work_history_ids_left_alone(monkeypatch):
    # Non-Workday repeaters: an indexed id marks one past job.
    monkeypatch.setattr(config, "PROFILE", {"first_name": "Will", "last_name": "H",
                                            "current_company": "Acme"})
    monkeypatch.setattr(config, "EEO", {})
    for label in ("experience[0][company] | Company", "employment-1-company | Company Name",
                  "work_history_2_employer | Employer"):
        source, _ = filler._hint_value(label)
        assert filler.leave_for_user(source, label, required=False), label


def test_employment_word_alone_not_work_history(monkeypatch):
    # "employment" in a question or a current-employer field isn't a history entry.
    monkeypatch.setattr(config, "PROFILE", {"current_company": "Acme"})
    monkeypatch.setattr(config, "EEO", {})
    label = "current_employment_company | Current company"
    source, _ = filler._hint_value(label)
    assert not filler.leave_for_user(source, label, required=False)
