import json

from adapters.common import job_posting_from_ld


def test_job_posting_from_ld_plain():
    blob = json.dumps({"@type": "JobPosting", "title": "Frontend Engineer",
                       "hiringOrganization": {"@type": "Organization", "name": "Quo"},
                       "description": "<h2>About</h2><p>React &amp; TypeScript</p>"})
    assert job_posting_from_ld([blob]) == {
        "title": "Frontend Engineer", "company": "Quo",
        "description": "About React & TypeScript"}


def test_job_posting_from_ld_graph_and_junk():
    graph = json.dumps({"@graph": [{"@type": "Organization", "name": "X"},
                                   {"@type": ["JobPosting"], "title": "SWE"}]})
    got = job_posting_from_ld(["not json", json.dumps({"@type": "WebSite"}), graph])
    assert got["title"] == "SWE"
    assert job_posting_from_ld(["{}"]) == {}


def test_job_posting_from_ld_strips_workday_company_code():
    blob = json.dumps({"@type": "JobPosting", "title": "FDE",
                       "hiringOrganization": {"name": "100 Salesforce, Inc."}})
    assert job_posting_from_ld([blob])["company"] == "Salesforce, Inc."
    blob = json.dumps({"@type": "JobPosting", "hiringOrganization": {"name": "3M"}})
    assert job_posting_from_ld([blob])["company"] == "3M"
