import importlib.util
import math
import os
import random

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_spec = importlib.util.spec_from_file_location("scrape", os.path.join(_ROOT, "scrape.py"))
scrape = importlib.util.module_from_spec(_spec)
import sys
sys.path.insert(0, _ROOT)
_spec.loader.exec_module(scrape)


def test_minutes_ago():
    assert scrape.minutes_ago("3 hours ago") == 180
    assert scrape.minutes_ago("Reposted 1 hour ago") == 60
    assert scrape.minutes_ago("15 minutes ago") == 15
    assert scrape.minutes_ago("2 days ago") is None


def test_applicant_count():
    assert scrape.applicant_count("45 people clicked apply") == 45
    assert scrape.applicant_count("1 person clicked apply") == 1
    assert scrape.applicant_count("1,204 people clicked apply") == 1204
    assert scrape.applicant_count("45 applicants") == 45
    assert scrape.applicant_count("Be an early applicant") is None
    # "Over 100" is at least 101, so max_applicants = 100 still skips it.
    assert scrape.applicant_count("Over 100 applicants") == 101
    assert scrape.applicant_count("Over 1,000 applicants") == 1001


def test_applicants_label():
    assert scrape.applicants_label("45 people clicked apply") == 45
    assert scrape.applicants_label("45 applicants") == 45
    assert scrape.applicants_label("Over 100 applicants") == "100+"
    assert scrape.applicants_label("Over 1,000 applicants") == "1000+"
    assert scrape.applicants_label("") is None


def test_job_id_from_url():
    url = "https://www.linkedin.com/jobs/search-results/?keywords=x&currentJobId=4482173839"
    assert scrape.job_id_from_url(url) == "4482173839"
    assert scrape.job_id_from_url("https://www.linkedin.com/feed/") is None


def test_next_page_url_advances_start_and_drops_job():
    url = ("https://www.linkedin.com/jobs/search-results/?currentJobId=4483715326"
           "&keywords=Typescript&start=125&f_SAL=f_SA_id_225001%3A272001")
    nxt = scrape.next_page_url(url)
    assert "start=150" in nxt and "currentJobId" not in nxt
    assert "keywords=Typescript" in nxt and "f_SAL=f_SA_id_225001%3A272001" in nxt
    assert "start=25" in scrape.next_page_url("https://www.linkedin.com/jobs/search-results/?keywords=x")


def test_page_number():
    assert scrape.page_number("https://www.linkedin.com/jobs/search-results/?start=125") == 6
    assert scrape.page_number("https://www.linkedin.com/jobs/search-results/?keywords=x") == 1


def test_human_path_curves_ends_at_target_and_slows_down():
    random.seed(7)
    a, b = (0.0, 0.0), (400.0, 0.0)
    pts = scrape.human_path(a, b)
    assert pts[-1] == b
    assert max(abs(y) for _, y in pts) > 5  # not a straight line
    step = lambda p, q: math.hypot(q[0] - p[0], q[1] - p[1])
    assert step(pts[-2], pts[-1]) < step(a, pts[0])  # decelerates near b


def test_skip_reason_filters(monkeypatch):
    monkeypatch.setattr(scrape, "MAX_APPLICANTS", 50)
    monkeypatch.setattr(scrape, "MAX_MINUTES_AGO", 120)
    monkeypatch.setattr(scrape, "TITLE_EXCLUDE_KEYWORDS", ["Manager"])
    monkeypatch.setattr(scrape, "WORK_TYPES", ["Remote"])
    ok = {"title": "TS Engineer", "posted": "1 hour ago", "applied": "3 people clicked apply",
          "work_types": ["Remote"]}
    assert scrape.skip_reason(ok) is None
    assert scrape.skip_reason({**ok, "applied": ""}) is None
    assert "posted 3 hours ago" in scrape.skip_reason({**ok, "posted": "3 hours ago"})
    assert "posted 150 min ago" in scrape.skip_reason({**ok, "posted": "150 minutes ago"})
    assert scrape.skip_reason({**ok, "applied": "51 people clicked apply"})
    assert "100+ applicants" in scrape.skip_reason({**ok, "applied": "Over 100 applicants"})
    assert "51 applicants" in scrape.skip_reason({**ok, "applied": "51 people clicked apply"})
    assert scrape.skip_reason({**ok, "title": "Engineering manager"})
    assert scrape.skip_reason({**ok, "work_types": ["Hybrid"]})
    assert scrape.skip_reason({**ok, "work_types": ["Remote", "On-site"]})
    assert scrape.skip_reason({**ok, "work_types": []}) is None  # no work type shown: keep


def test_card_skip_reason(monkeypatch, tmp_path):
    monkeypatch.setattr(scrape, "TITLE_EXCLUDE_KEYWORDS", ["Manager"])
    monkeypatch.setattr(scrape, "WORK_TYPES", ["Remote"])
    conn = scrape.jobstore.connect(str(tmp_path / "jobs.db"))
    c = {"job_id": "1", "title": "TS Engineer", "company": "Acme", "work_types": ["Remote"]}
    skip = lambda card: scrape.card_skip_reason(card, conn)
    assert skip(c) is None
    assert skip({**c, "work_types": []}) is None
    assert skip({**c, "title": ""}) is None
    assert skip({**c, "work_types": ["Hybrid"]})
    assert skip({**c, "title": "Eng Manager"})
    row = {"job_id": "9", "title": "ts engineer", "location": "", "work_type": "", "company": "ACME", "logo": "",
           "hours_ago": 1.0, "applicants": None, "easy_apply": True, "applied": False, "scraped_at": "", "source": "t"}
    scrape.jobstore.add_job(conn, row)
    assert "employer + title" in skip(c)  # an earlier run saved the same employer + title
    assert "jobId" in skip({**c, "job_id": "9", "title": "", "company": ""})
    scrape.jobstore.delete_job(conn, "9")
    assert "deleted" in skip(c)
