import importlib.util
import math
import os
import random

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_spec = importlib.util.spec_from_file_location("scrape", os.path.join(_ROOT, "scrape.py"))
scrape = importlib.util.module_from_spec(_spec)
import sys
sys.path.insert(0, _ROOT)
_spec.loader.exec_module(scrape)


def test_minutes_ago():
    assert scrape.minutes_ago("3 hours ago") == 180
    assert scrape.minutes_ago("Reposted 1 hour ago") == 60
    assert scrape.minutes_ago("15 minutes ago") == 15
    assert scrape.minutes_ago("2 days ago") is None


def test_load_deleted(tmp_path, monkeypatch):
    monkeypatch.setattr(scrape, "DELETED_PATH", str(tmp_path / "deleted.json"))
    assert scrape.load_deleted() == {}
    (tmp_path / "deleted.json").write_text('{"123": "2026-10-21T18:30:00"}')
    assert "123" in scrape.load_deleted()
    assert "456" not in scrape.load_deleted()


def test_applicant_count():
    assert scrape.applicant_count("45 people clicked apply") == 45
    assert scrape.applicant_count("1 person clicked apply") == 1
    assert scrape.applicant_count("1,204 people clicked apply") == 1204
    assert scrape.applicant_count("45 applicants") == 45
    assert scrape.applicant_count("Be an early applicant") is None
    # "Over 100" is at least 101, so max_applicants = 100 still skips it.
    assert scrape.applicant_count("Over 100 applicants") == 101
    assert scrape.applicant_count("Over 1,000 applicants") == 1001


def test_applicants_label():
    assert scrape.applicants_label("45 people clicked apply") == 45
    assert scrape.applicants_label("45 applicants") == 45
    assert scrape.applicants_label("Over 100 applicants") == "100+"
    assert scrape.applicants_label("Over 1,000 applicants") == "1000+"
    assert scrape.applicants_label("") is None


def test_job_id_from_url():
    url = "https://www.linkedin.com/jobs/search-results/?keywords=x&currentJobId=4482173839"
    assert scrape.job_id_from_url(url) == "4482173839"
    assert scrape.job_id_from_url("https://www.linkedin.com/feed/") is None


def test_human_path_curves_ends_at_target_and_slows_down():
    random.seed(7)
    a, b = (0.0, 0.0), (400.0, 0.0)
    pts = scrape.human_path(a, b)
    assert pts[-1] == b
    assert max(abs(y) for _, y in pts) > 5  # not a straight line
    step = lambda p, q: math.hypot(q[0] - p[0], q[1] - p[1])
    assert step(pts[-2], pts[-1]) < step(a, pts[0])  # decelerates near b


def test_job_key_ignores_case_and_spacing():
    assert scrape.job_key(" acme", "ts engineer ") == scrape.job_key("Acme", "TS Engineer")


def test_skip_reason_filters(monkeypatch):
    monkeypatch.setattr(scrape, "MAX_APPLICANTS", 50)
    monkeypatch.setattr(scrape, "MAX_MINUTES_AGO", 120)
    monkeypatch.setattr(scrape, "TITLE_EXCLUDE_KEYWORDS", ["Manager"])
    monkeypatch.setattr(scrape, "WORK_TYPES", ["Remote"])
    ok = {"title": "TS Engineer", "posted": "1 hour ago", "applied": "3 people clicked apply",
          "work_types": ["Remote"]}
    assert scrape.skip_reason(ok) is None
    assert scrape.skip_reason({**ok, "applied": ""}) is None
    assert "posted 3 hours ago" in scrape.skip_reason({**ok, "posted": "3 hours ago"})
    assert "posted 150 min ago" in scrape.skip_reason({**ok, "posted": "150 minutes ago"})
    assert scrape.skip_reason({**ok, "applied": "51 people clicked apply"})
    assert "100+ applicants" in scrape.skip_reason({**ok, "applied": "Over 100 applicants"})
    assert "51 applicants" in scrape.skip_reason({**ok, "applied": "51 people clicked apply"})
    assert scrape.skip_reason({**ok, "title": "Engineering manager"})
    assert scrape.skip_reason({**ok, "work_types": ["Hybrid"]})
    assert scrape.skip_reason({**ok, "work_types": ["Remote", "On-site"]})
    assert scrape.skip_reason({**ok, "work_types": []}) is None  # no work type shown: keep


def test_card_skip_reason(monkeypatch):
    monkeypatch.setattr(scrape, "TITLE_EXCLUDE_KEYWORDS", ["Manager"])
    monkeypatch.setattr(scrape, "WORK_TYPES", ["Remote"])
    c = {"job_id": "1", "title": "TS Engineer", "company": "Acme", "work_types": ["Remote"]}
    skip = lambda card, ids=(), keys=(), deleted=(): scrape.card_skip_reason(card, ids, keys, deleted)
    assert skip(c) is None
    assert skip({**c, "work_types": []}) is None
    assert skip({**c, "title": ""}) is None
    assert skip({**c, "work_types": ["Hybrid"]})
    assert skip({**c, "title": "Eng Manager"})
    assert skip(c, ids={"1"})
    assert skip(c, deleted={"1": "x"})
    assert skip(c, keys={scrape.job_key("acme", "ts engineer")})
