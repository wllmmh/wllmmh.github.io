import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import jobstore


def job(job_id="1", **kw):
    return {"job_id": job_id, "title": "TS Engineer", "location": "Remote", "work_type": "Remote",
            "company": "Acme", "logo": "", "hours_ago": 2.0, "applicants": 5, "easy_apply": True,
            "applied": False, "scraped_at": "2026-10-27T08:00:00", "source": "run", **kw}


def store(tmp_path):
    return jobstore.connect(str(tmp_path / "jobs.db"))


def test_job_key_ignores_case_and_spacing():
    assert jobstore.job_key(" acme", "ts engineer ") == jobstore.job_key("Acme", "TS Engineer")


def test_add_job_ignores_a_known_id(tmp_path):
    conn = store(tmp_path)
    assert jobstore.add_job(conn, job())
    assert not jobstore.add_job(conn, job(title="Other"))
    assert [j["title"] for j in jobstore.list_jobs(conn)] == ["TS Engineer"]


def test_find_duplicate_by_id_and_by_employer_and_title(tmp_path):
    conn = store(tmp_path)
    assert jobstore.find_duplicate(conn, "1", "Acme", "TS Engineer") is None
    jobstore.add_job(conn, job())
    assert "jobId" in jobstore.find_duplicate(conn, "1")
    assert "employer + title" in jobstore.find_duplicate(conn, "2", "ACME ", "ts engineer")
    assert jobstore.find_duplicate(conn, "2", "Acme", "Other") is None
    assert jobstore.find_duplicate(conn, "2", "", "") is None  # nothing to match on


def test_deleted_jobs_still_count_as_duplicates(tmp_path):
    conn = store(tmp_path)
    jobstore.add_job(conn, job())
    assert jobstore.delete_job(conn, "1")
    assert "deleted" in jobstore.find_duplicate(conn, "1")
    assert "deleted" in jobstore.find_duplicate(conn, "2", "Acme", "TS Engineer")
    assert not jobstore.add_job(conn, job(title="Changed"))
    assert jobstore.list_jobs(conn) == []
    assert [j["job_id"] for j in jobstore.list_jobs(conn, deleted=True)] == ["1"]


def test_live_match_beats_deleted_one(tmp_path):
    conn = store(tmp_path)
    jobstore.add_job(conn, job("1"))
    jobstore.add_job(conn, job("2"))
    jobstore.delete_job(conn, "1")
    assert "already saved" in jobstore.find_duplicate(conn, "3", "Acme", "TS Engineer")


def test_restore(tmp_path):
    conn = store(tmp_path)
    jobstore.add_job(conn, job())
    assert not jobstore.restore_job(conn, "1")  # not deleted
    jobstore.delete_job(conn, "1")
    assert not jobstore.delete_job(conn, "1")  # already deleted
    assert jobstore.restore_job(conn, "1")
    assert [j["job_id"] for j in jobstore.list_jobs(conn)] == ["1"]
    assert jobstore.find_duplicate(conn, "1") == "jobId already saved"


def test_set_applied(tmp_path):
    conn = store(tmp_path)
    jobstore.add_job(conn, job())
    assert jobstore.set_applied(conn, "1", True)
    assert jobstore.list_jobs(conn)[0]["applied"] == 1
    assert not jobstore.set_applied(conn, "nope", True)


def test_first_connect_imports_old_csvs_and_deleted_json(tmp_path):
    header = "job_id,title,location,work_type,company,logo,hours_ago,applicants,applied,easy_apply,scraped_at\n"
    (tmp_path / "A_2026-10-26.csv").write_text(
        header + "1,Old title,NYC,Remote,Acme,,3.0,5,false,true,2026-10-26T09:00:00\n")
    (tmp_path / "B_2026-10-27.csv").write_text(
        header + "1,New title,NYC,Remote,Acme,,1.0,100+,true,false,2026-10-27T09:00:00\n"
        "2,Other,LA,Remote,Beta,,1.0,,false,true,2026-10-27T09:00:00\n")
    (tmp_path / "deleted.json").write_text(json.dumps({"3": "2026-10-25T10:00:00", "2": "2026-10-27T10:00:00"}))
    conn = store(tmp_path)
    live = jobstore.list_jobs(conn)
    assert [(j["job_id"], j["title"], j["applied"], j["applicants"], j["source"]) for j in live] == [
        ("1", "New title", 1, "100+", "B_2026-10-27")]
    assert sorted(j["job_id"] for j in jobstore.list_jobs(conn, deleted=True)) == ["2", "3"]
    assert "deleted" in jobstore.find_duplicate(conn, "3")
    assert "deleted" in jobstore.find_duplicate(conn, "9", "Beta", "Other")
    # Reconnecting doesn't import twice or resurrect anything.
    assert len(jobstore.list_jobs(store(tmp_path))) == 1


def test_restoring_an_id_only_row_forgets_it(tmp_path):
    (tmp_path / "deleted.json").write_text(json.dumps({"3": "2026-10-25T10:00:00"}))
    conn = store(tmp_path)
    assert jobstore.restore_job(conn, "3")
    assert jobstore.find_duplicate(conn, "3") is None
