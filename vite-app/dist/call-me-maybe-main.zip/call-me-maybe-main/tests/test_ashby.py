import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import inspect
import re
import adapters.ashby as ashby


def test_ashby_apply_uses_wait_for_not_polling_loop():
    # The adapter must wait for form fields via wait_for(), not a manual polling
    # loop — polling caused a 15-second hang when :has-text() locators were slow.
    src = inspect.getsource(ashby)
    assert "wait_for_timeout" not in src
    assert "wait_for" in src


def test_ashby_apply_waits_for_input_not_button():
    # Must wait on an input/textarea selector so it returns as soon as the form
    # mounts, not after exhausting a timeout waiting for a button that may not exist.
    src = inspect.getsource(ashby)
    assert "input" in src
    assert "Apply for this Job" not in src


class _FakeLocator:
    def __init__(self, page, sel):
        self.page, self.sel = page, sel

    @property
    def first(self):
        return self

    def _matches(self):
        # Evaluate a[href$=..] / a[href*=..] alternatives against the page's link.
        href = self.page.href
        for op, val in re.findall(r'a\[href([$*])="([^"]+)"\]', self.sel):
            if (href.endswith(val) if op == "$" else val in href):
                return True
        return False

    async def count(self):
        return 1 if self._matches() else 0

    async def click(self, **kw):
        self.page.clicked.append(self.sel)
        self.page.url = self.page.href

    async def wait_for(self, **kw):
        pass


class _FakePage:
    def __init__(self, url):
        self.url, self.clicked = url, []
        # The Overview tab's apply link keeps the posting's query string.
        base, _, query = url.partition("?")
        self.href = base.rstrip("/") + "/application" + (f"?{query}" if query else "")

    def locator(self, sel):
        return _FakeLocator(self, sel)


def _run_apply(monkeypatch, url):
    import asyncio

    async def fake_fill(*a, **kw):
        return {"filled": 0, "unknown": 0, "required_empty": []}

    async def fake_upload(*a, **kw):
        return True

    monkeypatch.setattr(ashby.filler, "fill_form", fake_fill)
    monkeypatch.setattr(ashby.common, "upload_resume", fake_upload)
    page = _FakePage(url)
    asyncio.run(ashby.apply(page, "resume.pdf"))
    return page


def test_ashby_apply_opens_application_tab_from_overview(monkeypatch):
    # A posting opened on its Overview tab has no form; the adapter must click
    # through ("Apply for this Job" / Application tab, both link to /application).
    page = _run_apply(monkeypatch, "https://jobs.ashbyhq.com/acme/123")
    assert page.clicked
    assert page.url.endswith("/application")


def test_ashby_apply_opens_application_tab_with_query_string(monkeypatch):
    # From LinkedIn the link is /application?src=Linkedin -- not "ends with /application".
    page = _run_apply(monkeypatch, "https://jobs.ashbyhq.com/acme/123?src=Linkedin")
    assert page.clicked
    assert page.url.split("?")[0].endswith("/application")


def test_ashby_apply_stays_on_application_tab(monkeypatch):
    page = _run_apply(monkeypatch, "https://jobs.ashbyhq.com/acme/123/application")
    assert not page.clicked
    page = _run_apply(monkeypatch, "https://jobs.ashbyhq.com/acme/123/application?src=Linkedin")
    assert not page.clicked
