from gmail import extract_code, extract_link, subject_matches


def test_extract_code():
    assert extract_code("Your verification code is 482913") == "482913"
    assert extract_code("Verification Code: AB12CD") == "AB12CD"
    assert extract_code("482913 is your Workday verification code") == "482913"
    assert extract_code("Verify your candidate account") is None


def test_extract_code_ignores_unrelated_ids():
    # A requisition id or year in the subject isn't the code.
    assert extract_code("Application received: JR349466") is None
    assert extract_code("Salesforce 2026 - your code is 551203") == "551203"


def test_subject_matches_only_workday_account_mail():
    assert subject_matches("Reset your password for your candidate account", "reset")
    assert not subject_matches("Reset your password for your candidate account", "verify")
    assert subject_matches("Create your Candidate Home Hub Account with Commerce!", "verify")
    assert not subject_matches("Verify your email address", "verify")
    assert subject_matches("Verify your email address", "verify",
                           sender="salesforce", tenant="salesforce")
    assert subject_matches("Verify your email address", "verify", sender="Commerce Workday")
    assert subject_matches("Your Workday verification code is 123456", "verify")
    assert subject_matches("Verify your candidate account", "verify",
                           sender="Accenture Careers accenture@otp.workday.com", tenant="accenture")
    assert not subject_matches("Thanks for Applying to Commerce!", "verify")
    assert not subject_matches("Reset your Netflix password", "reset")
    assert not subject_matches("Your Amazon verification code", "verify")


LINKS = [
    "mailto:me@example.com",
    "http://salesforce.com/",
    "https://salesforce.wd12.myworkdayjobs.com/External_Career_Site/passwordreset/abc123",
    "https://acme.wd5.myworkdayjobs.com/en-US/Careers/activate/xyz?redirect=1",
]


def test_extract_link():
    assert extract_link(LINKS, "reset") == LINKS[2]
    assert extract_link(LINKS, "verify") == LINKS[3]
    assert extract_link(LINKS[:2], "reset") is None
    # Must be a Workday host, not just a path that looks right.
    assert extract_link(["https://evil.example.com/passwordreset/abc"], "reset") is None


def test_extract_link_on_given_host():
    links = ["https://jobs.acme-ats.com/account/verify?t=1", "https://acme.com/privacy"]
    assert extract_link(links, "verify") is None  # not a Workday host
    assert extract_link(links, "verify", host="jobs.acme-ats.com") == links[0]
