import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import applog


def test_record_and_dedupe(tmp_path, monkeypatch):
    monkeypatch.setattr(applog, "LOG_DIR", str(tmp_path))
    monkeypatch.setattr(applog, "LOG_PATH", str(tmp_path / "log.csv"))

    url = "https://job-boards.greenhouse.io/acme/jobs/123"
    assert applog.already_applied(url) is False

    applog.record(url, board="greenhouse", company="Acme", title="Eng", status="filled")
    # 'filled' should not count as already-applied
    assert applog.already_applied(url) is False

    applog.record(url, board="greenhouse", company="Acme", title="Eng", status="submitted")
    assert applog.already_applied(url) is True


def test_record_creates_header(tmp_path, monkeypatch):
    monkeypatch.setattr(applog, "LOG_DIR", str(tmp_path))
    monkeypatch.setattr(applog, "LOG_PATH", str(tmp_path / "log.csv"))
    applog.record("https://x.com/job", status="submitted")
    content = (tmp_path / "log.csv").read_text()
    assert "timestamp,url,board,company,title,resume,status" in content
