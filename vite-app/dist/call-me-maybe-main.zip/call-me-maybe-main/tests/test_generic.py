import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import asyncio

import adapters.generic as generic

JOB = "https://jobs.ashbyhq.com/acme/123"


def test_apply_href_application_and_apply_paths():
    assert generic._is_apply_href(JOB + "/application", JOB)
    assert generic._is_apply_href(JOB + "/apply/", JOB)
    assert generic._is_apply_href("https://boards.example.com/jobs/9/apply", "https://boards.example.com/jobs/9")


def test_apply_href_rejects_current_page_other_sites_and_other_paths():
    assert not generic._is_apply_href(JOB + "/application", JOB + "/application/")
    assert not generic._is_apply_href("https://other.com/acme/123/application", JOB)
    assert not generic._is_apply_href(JOB + "/applications-faq", JOB)
    assert not generic._is_apply_href("https://jobs.ashbyhq.com/acme", JOB)


class _Link:
    async def get_attribute(self, name):
        return None


class _Page:
    url = JOB

    async def wait_for_load_state(self, *a, **kw):
        pass


def _run(monkeypatch, fields_now, link):
    waits, clicks = [], []

    async def wait_for_fields(page, timeout_ms):
        waits.append(timeout_ms)
        return fields_now if len(waits) == 1 else True

    async def apply_link(page):
        return link

    async def click(loc):
        clicks.append(loc)
        return True

    monkeypatch.setattr(generic, "_wait_for_fields", wait_for_fields)
    monkeypatch.setattr(generic, "_apply_link", apply_link)
    monkeypatch.setattr(generic, "_click", click)
    opened = asyncio.run(generic._open_application_form(_Page()))
    return opened, waits, clicks


def test_open_form_leaves_a_page_that_has_fields(monkeypatch):
    opened, waits, clicks = _run(monkeypatch, fields_now=True, link=_Link())
    assert not opened and not clicks and len(waits) == 1


def test_open_form_follows_apply_link_once(monkeypatch):
    link = _Link()
    opened, waits, clicks = _run(monkeypatch, fields_now=False, link=link)
    assert opened and clicks == [link] and len(waits) == 2


def test_open_form_without_link_gives_up_after_one_wait(monkeypatch):
    opened, waits, clicks = _run(monkeypatch, fields_now=False, link=None)
    assert not opened and not clicks and len(waits) == 1


def test_apply_opens_form_once_across_pages(monkeypatch):
    # Multi-page forms re-scan each page; the click-through must not repeat.
    calls, pages = [], []

    async def open_form(page):
        calls.append(page)

    async def scope(page):
        return page

    async def visible(loc):
        return []

    async def upload(*a, **kw):
        return True

    async def fill(*a, **kw):
        pages.append(1)
        return {"filled": [], "unknown": [], "required_empty": []}

    async def next_btn(page):
        return object() if len(pages) < 3 else None

    async def click(loc):
        return True

    async def advanced(scope, before):
        return True

    async def field_ids(scope):
        return []

    class Page(_Page):
        def locator(self, sel):
            return None

        async def wait_for_timeout(self, ms):
            pass

    for name, fn in [("_open_application_form", open_form), ("get_form_scope", scope),
                     ("_visible", visible), ("_find_next_button", next_btn),
                     ("_click", click), ("_advanced", advanced), ("_field_ids", field_ids),
                     ("_upload_again", upload)]:
        monkeypatch.setattr(generic, name, fn)
    monkeypatch.setattr(generic.common, "upload_resume", upload)
    monkeypatch.setattr(generic.filler, "fill_form", fill)
    asyncio.run(generic.apply(Page(), "resume.pdf"))
    assert len(pages) == 3 and len(calls) == 1
