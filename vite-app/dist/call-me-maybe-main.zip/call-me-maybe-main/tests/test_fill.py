from fill import is_application_tab


def test_is_application_tab():
    assert is_application_tab("https://job-boards.greenhouse.io/acme/jobs/123")
    assert is_application_tab("https://jobs.ashbyhq.com/acme/abc/application")
    assert is_application_tab("https://careers.example.com/apply")
    assert not is_application_tab("https://www.linkedin.com/jobs/view/123")
    assert not is_application_tab("https://linkedin.com/feed")
    assert not is_application_tab("http://127.0.0.1:40123/search-results-view.html")
    assert not is_application_tab("chrome://newtab/")
    assert not is_application_tab("about:blank")


def test_dayforce_routed():
    import adapters
    url = "https://jobs.dayforcehcm.com/en-US/vantagerisk/109972/jobs/DF350?external=true"
    assert adapters.pick_adapter(url).NAME == "dayforce"


def test_talenthop_routed():
    import adapters
    url = "https://www.talenthop.com/apply-with-ai/054e54c3-07b7-4cb7-a467-3c6568d9b4bb"
    assert adapters.pick_adapter(url).NAME == "talenthop"


def test_is_apply_text():
    from adapters.common import is_apply_text
    assert is_apply_text("Apply for This Job")
    assert is_apply_text("  Apply Now")
    assert is_apply_text("APPLY")
    assert not is_apply_text("Applied")
    assert not is_apply_text("How to apply")
    assert not is_apply_text("Application status")


def test_gmail_tab_is_not_an_application():
    assert not is_application_tab("https://mail.google.com/mail/u/0/#inbox")


def test_continue_application_is_an_apply_link():
    from adapters.common import is_apply_text
    assert is_apply_text("Continue Application")
    assert not is_apply_text("Continue")


def test_workable_routed():
    import adapters
    assert adapters.pick_adapter("https://jobs.workable.com/view/abc/some-job").NAME == "workable"
    assert adapters.pick_adapter("https://apply.workable.com/acme/j/ABC123/").NAME == "workable"


def test_is_media_only():
    from adapters.common import is_media_only
    assert is_media_only(".jpg,.jpeg,.gif,.png,image/jpeg,image/gif,image/png")
    assert is_media_only("image/*")
    # Accenture's chat widget: "Upload Video" next to the real Apply link.
    assert is_media_only("video/mp4,video/x-m4v,video/*")
    assert not is_media_only(".pdf,.doc,.docx,application/pdf")
    assert not is_media_only(".pdf,.png")
    assert not is_media_only(None)
    assert not is_media_only("")
