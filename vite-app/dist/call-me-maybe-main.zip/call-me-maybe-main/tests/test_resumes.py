import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import resumes
import config


def test_select_resume_matches_keyword(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "RESUME_DIR", str(tmp_path))
    monkeypatch.setattr(config, "DEFAULT_RESUME", "general.pdf")
    monkeypatch.setattr(config, "RESUME_RULES", [
        (["ai", "agent"], "ai.pdf"),
        (["react", "frontend"], "frontend.pdf"),
    ])
    (tmp_path / "ai.pdf").write_text("x")
    (tmp_path / "frontend.pdf").write_text("x")
    (tmp_path / "general.pdf").write_text("x")

    assert resumes.select_resume("Senior AI Engineer").endswith("ai.pdf")
    assert resumes.select_resume("Frontend React Dev").endswith("frontend.pdf")


def test_select_resume_first_rule_wins(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "RESUME_DIR", str(tmp_path))
    monkeypatch.setattr(config, "DEFAULT_RESUME", "general.pdf")
    monkeypatch.setattr(config, "RESUME_RULES", [
        (["ai"], "ai.pdf"),
        (["react"], "frontend.pdf"),
    ])
    (tmp_path / "ai.pdf").write_text("x")
    (tmp_path / "frontend.pdf").write_text("x")
    # both keywords present -> first rule (ai) wins
    assert resumes.select_resume("AI engineer using React").endswith("ai.pdf")


def test_select_resume_falls_back_to_default(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "RESUME_DIR", str(tmp_path))
    monkeypatch.setattr(config, "DEFAULT_RESUME", "general.pdf")
    monkeypatch.setattr(config, "RESUME_RULES", [(["ai"], "ai.pdf")])
    (tmp_path / "general.pdf").write_text("x")
    assert resumes.select_resume("Accountant").endswith("general.pdf")


def test_select_resume_missing_file_raises(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "RESUME_DIR", str(tmp_path))
    monkeypatch.setattr(config, "DEFAULT_RESUME", "nope.pdf")
    monkeypatch.setattr(config, "RESUME_RULES", [])
    try:
        resumes.select_resume("anything")
        assert False, "expected FileNotFoundError"
    except FileNotFoundError:
        pass


def test_cover_letter_substitutes_company(monkeypatch):
    monkeypatch.setattr(config, "COVER_LETTER_RULES", [])
    monkeypatch.setattr(config, "COVER_LETTER_DEFAULT", "Hello {company}!")
    assert resumes.select_cover_letter("dev", "Acme") == "Hello Acme!"


def test_cover_letter_keyword_override(monkeypatch):
    monkeypatch.setattr(config, "COVER_LETTER_RULES", [(["ai"], "AI letter for {company}")])
    monkeypatch.setattr(config, "COVER_LETTER_DEFAULT", "default")
    assert resumes.select_cover_letter("AI role", "Acme") == "AI letter for Acme"


def _three_resumes(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "RESUME_DIR", str(tmp_path))
    monkeypatch.setattr(config, "DEFAULT_RESUME", "general.pdf")
    monkeypatch.setattr(config, "RESUME_RULES", [
        (["ai", "agent"], "ai.pdf"),
        (["react", "frontend", "ui"], "frontend.pdf"),
    ])
    for name in ("ai.pdf", "frontend.pdf", "general.pdf"):
        (tmp_path / name).write_text("x")


def test_select_resume_matches_whole_words(tmp_path, monkeypatch):
    # "ui" inside "Build", "ai" inside "Maintainer" are not keywords.
    _three_resumes(tmp_path, monkeypatch)
    assert resumes.select_resume("Build Maintainer").endswith("general.pdf")


def test_select_resume_falls_back_to_description(tmp_path, monkeypatch):
    # Title matched nothing: the rule with the most hits in the JD wins.
    _three_resumes(tmp_path, monkeypatch)
    jd = "Frontend role. React, React Native, frontend tooling. Some AI features."
    assert resumes.select_resume("Software Engineer", jd).endswith("frontend.pdf")


def test_select_resume_title_beats_description(tmp_path, monkeypatch):
    _three_resumes(tmp_path, monkeypatch)
    jd = "React React React frontend frontend"
    assert resumes.select_resume("AI Engineer", jd).endswith("ai.pdf")


def test_select_resume_ignores_passing_jd_mentions(tmp_path, monkeypatch):
    # One or two incidental hits aren't enough to override the default.
    _three_resumes(tmp_path, monkeypatch)
    assert resumes.select_resume("Software Engineer", "We use AI.").endswith("general.pdf")


def test_select_resume_missing_rule_file_falls_back_to_default(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "RESUME_DIR", str(tmp_path))
    monkeypatch.setattr(config, "DEFAULT_RESUME", "general.pdf")
    monkeypatch.setattr(config, "RESUME_RULES", [(["ai"], "ai.pdf")])
    (tmp_path / "general.pdf").write_text("x")
    assert resumes.select_resume("AI Engineer").endswith("general.pdf")
