# Changelog

Format: [Keep a Changelog](https://keepachangelog.com). Newest first.

## [Unreleased]

### Added
- `view.py` Scraped column (when `scrape.py` saved the job), sortable.
- `view.py` Deleted tab: every soft-deleted job, with Restore.
- `jobstore.py`: SQLite store (`strict-search-results/jobs.db`) shared by
  `scrape.py` and `view.py`. Existing results CSVs and `deleted.json` are
  imported the first time it is created.

### Changed
- `scrape.py` skips any job already in the store, from any run (same jobId, or
  same employer + title), including jobs deleted in `view.py`. It no longer
  writes CSVs.
- `view.py` updates live: applied, delete and restore save immediately, and new
  scrapes appear without reloading. The Save button and CSV pickers are gone.
- `view.py` serves only the page and `/api/`, not the results folder.
- Settings are one `config.toml` with a section per script (`[browser]`,
  `[scrape]`, `[fill]`, `[profile]`, `[eeo]`). To migrate, copy your values from
  `scrape.toml`, `profile.toml` and the old `config.toml` into the sections of
  `config.example.toml`; `cdp_url` is now under `[browser]` and `[screening]`
  is `[fill.screening]`.

### Removed
- `scrape.toml`, `profile.toml`, `profile.example.toml`.

### Fixed
- Workday: Middle Name is no longer filled with your full name.
- Workday: work-history entries keep the resume parse's company, title,
  location and dates; the filler used to overwrite Company with your name and
  the Year fields with your years of experience.
- Workday: clicks Add under Portfolio/Websites so `website` gets filled, and
  waits for the step's sections to finish rendering before filling (the
  LinkedIn field, last on My Experience, could be missed).
- Generic adapter: the same Add click and render wait. Fields in an indexed
  work-history entry (`experience[0][company]`, `employment-1-title`) are left
  alone on any form.
