# 0001. SQLite store for scraped jobs
- Status: Accepted
- Date: 2026-10-27

## Context
Scraped jobs were one CSV per run, with `deleted.json` beside them. `view.py`
deleted a job by rewriting every CSV, while `scrape.py` could be appending to
one, so a row saved in between could be lost. The scraper only deduped within
its own run, and a delete removed the row's data, leaving just an id.

## Decision
Keep jobs in one SQLite database (`jobstore.py`, WAL mode), one row per
`job_id`. Delete is soft (`deleted_at`). `find_duplicate` matches on jobId and
on employer + title across every row, deleted or not. `view.py` serves a JSON
API over it, and the page polls it.

## Consequences
- A delete or applied toggle is one transaction; `scrape.py` and `view.py` can
  write at the same time.
- The scraper sees every earlier run, and never re-saves a deleted job.
- A deleted job keeps its details, so the Deleted tab can show and restore it.
- Employer + title matching is permanent: a re-post of the same title under a
  new jobId is skipped. Relax `find_duplicate` if that proves too strict.
- Data is no longer a spreadsheet-openable file. There is no CSV export.
- Alternative rejected: one shared CSV behind a lock. It fixes deletes but not
  concurrent writers, and each new per-row field would need its own rewrite.
