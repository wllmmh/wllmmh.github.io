# 0002. One config.toml with a section per script
- Status: Accepted
- Date: 2026-10-27

## Context
Settings were in `config.toml` (fill.py and the browser), `scrape.toml`
(scrape.py, plus the `cdp_url` every script used) and `profile.toml` (personal
details). Scripts read each other's files, and setup meant copying two example
files.

## Decision
One `config.toml` (gitignored, template `config.example.toml`) with sections
`[browser]` (shared), `[scrape]`, `[fill]` (with `[fill.screening]`),
`[profile]` and `[eeo]`. `config.py` flattens `[fill]` and `[browser]` into
`config.UPPERCASE` names, so call sites are unchanged.

## Consequences
- One place to edit and one file to copy during setup.
- The file holds the password, so it is all gitignored; the example holds only
  placeholders, and `config.py` ignores its `[profile]`/`[eeo]` when
  `config.toml` is missing.
- Scrape settings are no longer a tracked file with defaults; they come from
  the example.
