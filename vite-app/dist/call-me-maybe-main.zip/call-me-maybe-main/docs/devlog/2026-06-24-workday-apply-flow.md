# Workday apply flow, as observed

Notes from driving the real flow on a trekbikes.wd1 posting while building
`adapters/workday.py`.

1. Job posting page: "Apply" button (`data-automation-id=adventureButton`).
2. Clicking it opens an in-page choice popup, not a navigation: "Autofill with
   Resume" / "Apply Manually" / "Apply with LinkedIn" cards.
3. "Autofill with Resume" navigates to a sign-in landing page with only SSO
   buttons (Sign in with Email / Google / Apple). No email or password field
   yet.
4. "Sign in with Email" reveals the real form
   (`data-automation-id=email` / `password` / `signInSubmitButton`).
5. Not verified live past this point. Expected: the resume upload step, the
   multi-step application form, then Review/Submit.

Because a URL can land on any of these screens depending on the tenant and
whether you're signed in, the adapter re-detects the step after every
transition instead of assuming an order.

The popup in step 2 and the upload step share the `autofillWithResume`
automation id. The adapter tells them apart by checking for a file drop zone
first.

## 2026-10-22: salesforce.wd12 (Create Account tenant)

- "Apply Manually" lands on a **Create Account** page, not sign-in: `email`,
  `password`, `verifyPassword`, `createAccountCheckbox`,
  `createAccountSubmitButton`, plus `signInLink` for existing accounts. Six
  steps: Create Account/Sign In, My Information, My Experience, Application
  Questions, Voluntary Disclosures, Review.
- Buttons sit under a transparent `click_filter` div that swallows clicks.
- `beecatcher` is a honeypot input labelled "Enter website. This input is for
  robots only"; the filler's `website` hint would fill it.
- Creating the account sent **no verification email**: the account was active
  immediately. The only Salesforce mail was the password reset requested later.
  So only wait for a code when the page asks for one.
- Repeated failed sign-ins locked the account. The adapter now makes one
  automatic attempt per run and hands over to you after that.
- Another tenant's (Commerce) account email had no code in its subject
  ("Create your Candidate Home Hub Account with Commerce!").
- A posting with an application in progress shows "Continue Application"
  (`<a data-automation-id="continueButton">`, href `.../apply`) instead of
  Apply; it's treated as the Apply button and lands on the saved step.
- Playwright's real clicks hang while the browser window isn't painted
  (minimized or covered); clicks fall back to `element.click()`.

## 2026-10-22: accenture.wd103 (sign-in-first tenant)

Reached from accenture.com's "Apply for this job" link. What broke along the
way is in the
[postmortem](../postmortems/2026-10-22-workday-create-account-failures.md).

- `/apply` opens the choice popup, then a Sign In landing (Sign in with
  Email), then the Sign In form, with `createAccountLink` for new users.
  Seven steps, starting with Create Account/Sign In.
- A sign-in for an email with no account here fails with "You may have
  entered the wrong email address or password or your account might be
  locked", the same text as a real lockout.
- Create Account (`POST /register`) returns to the Sign In form and emails
  "Verify your candidate account" from `accenture@otp.workday.com`, with an
  `/AccentureCareers/activate/<token>` link. The page says nothing about it.
- Signing in unverified: "Verify your account before you sign in or request a
  verification email", plus a "Resend Account Verification" button
  (`informationalBlurbButton`).
- Forgot Password always says "You will receive an email ... if an account
  exists", whether or not one does.
- Sign-in and dropdown selections take a few seconds to settle.
- Application Questions are `button[aria-haspopup=listbox]` dropdowns with
  long legalese labels (the 18-years-of-age question opens with two sentences
  about minimum legal age).
