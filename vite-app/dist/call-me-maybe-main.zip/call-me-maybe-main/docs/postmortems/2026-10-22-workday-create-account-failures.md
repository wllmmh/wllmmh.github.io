# 2026-10-22: Workday Create Account / sign-in failures

## Summary

Two Workday applications that needed a new employer account (Sedgwick, then
Accenture reached through accenture.com) stopped at the manual sign-in pause
instead of creating and verifying the account. The cause was not one bug but a
chain of them, found by driving the Accenture flow live and logging every
Workday button click and POST request.

## Impact

- Every application on a tenant where you had no account yet, and whose flow
  opens on Sign In rather than Create Account, needed you to create and verify
  the account by hand.
- Careers sites with a chat widget never reached their ATS, and the resume
  went into the widget's video upload.
- Workday dropdown answers that did get selected were reported as unmapped,
  so the summary said "Filled 0".

Nothing was submitted (`submit_application = false` throughout).

## What went wrong

1. **Sedgwick: Create Account click sent nothing.** The form was valid (fields
   filled, terms checked, password met every rule, no error), but no
   `/register` request went out and the adapter gave up after its wait. A
   single real click on the same `click_filter` overlay afterwards created
   the account at once. Root cause not found (see Open questions).
2. **accenture.com: Apply link not followed.** `common.open_apply_link`
   assumed any `input[type=file]` meant "already on the application form". The
   page's chat widget has `<input type=file accept="video/*">`, so the
   "Apply for this job" link to Accenture's Workday was never followed, and
   `upload_resume` set the resume on that video input.
3. **A failed sign-in was read as a lockout.** Workday says "You may have
   entered the wrong email address or password or your account might be
   locked" also when no account exists for that tenant. The adapter matched
   "lock" and requested a password reset. The reset POST succeeded, but
   Workday only emails "if an account exists", so it waited 180s for nothing.
4. **Created, then back on Sign In, treated as signed in.** After `/register`,
   Accenture returns to the Sign In form and emails "Verify your candidate
   account", with no "check your email" text on the page. `_create_account`
   only waited for email when the page asked, so it returned success, and the
   loop then took the Sign In form as "the account exists" and reset the
   password.
5. **"Verify your account before you sign in" had no handler.** An unverified
   account always ended at the manual pause.
6. **Sign-in judged after 1s.** Accenture takes several seconds to sign in.
   The adapter checked after a 1s settle, saw the form still up, and paused;
   on another run it detected the next step before the upload page rendered,
   so the resume step was skipped.
7. **Dropdown choice judged after 0.3s.** `_fill_button_dropdowns` treated a
   button still showing its placeholder 0.3s after the click as "not
   selected". Accenture updates it later, so selected answers were reported as
   unmapped.

## Fixes

- `adapters/workday.py`
  - Create Account submit is clicked again (up to 3 times) while the form is
    still up with no error (1).
  - A failed sign-in goes to Create Account first; Create Account answering
    "already exists" leads to the one password reset (3).
  - Landing back on Sign In after Create Account waits for the verification
    email and opens its link; a new account gets a fresh sign-in (4).
  - `_resend_verification`: on "Verify your account", click Resend Account
    Verification (`informationalBlurbButton`), open the link from Gmail, sign
    in again, once per run (5).
  - Sign-in waits up to 15s for the form to go or an error to show (6).
- `adapters/common.py`: `is_media_only` (was `is_image_only`) also skips
  video/audio-only inputs, both for the upload and for `open_apply_link`'s
  "already on the form" check (2).
- `filler.py`: the dropdown poll waits up to 2s for the button to show the
  choice (7).
- Tests: `test_is_media_only` (Accenture's video input) and the Accenture
  "Verify your candidate account" subject in `tests/test_gmail.py`.

Verified live on Accenture: Apply link, sign-in, resend verification, Gmail
link, sign-in, resume upload and autofill, through to Application Questions.

## Prevention

- When a Workday auth step fails, log the button clicks and POSTs before
  changing code: here every click landed, and the real failures were in how
  responses were interpreted.
- Workday's sign-in error text is not evidence of a lockout. Branch on what a
  following step says (Create Account's "already exists"), not on that text.
- Tenant waits are polls with a cap ("form gone or error shown"), never a
  fixed settle. The same rule as Invariant 5 in ARCHITECTURE.md.

## Open questions

- Why the first Sedgwick click sent no request. Every Accenture click landed
  as a real Playwright click with the page visible, so the retry is a guard,
  not a diagnosis. If it recurs, log whether `_click_button` used the real
  click or the `element.click()` fallback, and whether a POST was sent.
- After clearing sign-in cookies mid-application, Accenture's My Information
  step showed "Something went wrong"; a reload fixed it. Not seen in a normal
  run, so not handled.

Observed Accenture flow details: [devlog](../devlog/2026-06-24-workday-apply-flow.md#2026-10-22-accenturewd103-sign-in-first-tenant).
