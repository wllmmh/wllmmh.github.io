"""Fill the application forms already open in your browser.

Attaches to the browser with remote debugging on (cdp_url in
scrape.toml, same as scrape.py; started if it isn't running)
and fills every open tab in place, except LinkedIn, Gmail and the
view-results.py page. The board (Greenhouse, Ashby, Workday, Dayforce,
Workable, TalentHop, or generic) is picked from each tab's URL.

For each tab: picks a resume by job title / description, fills the form
heuristically from profile.toml and config.toml, uploads the resume, and
either stops before the final submit (submit_application = false) or
submits. Every attempt is recorded to applications/log.csv. The browser is
left open afterwards.

Usage:
    python fill.py [--stealth]

--stealth: if no browser is running at cdp_url, start it with config.toml's
stealth_args instead of standard_args (overrides stealth_mode for this run).
"""

import argparse
import asyncio
import os
import sys
import tomllib
from datetime import datetime
from urllib.parse import urlparse

# Playwright's bundled Node driver calls url.parse() on connect_over_cdp; hide its DEP0169 warning.
os.environ["NODE_OPTIONS"] = (os.environ.get("NODE_OPTIONS", "") + " --disable-warning=DEP0169").strip()

from playwright.async_api import async_playwright
from playwright.async_api import TimeoutError as PlaywrightTimeoutError

import adapters
import applog
import config
import filler
import resumes
from adapters import common
from browser import STEALTH, attach_browser

with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "scrape.toml"), "rb") as _f:
    CDP_URL = tomllib.load(_f)["cdp_url"]

VIEW_RESULTS_PAGE = "/search-results-view.html"  # view-results.py's PAGE


def is_application_tab(url):
    """True for a web page that isn't LinkedIn, Gmail or the view-results.py page."""
    u = urlparse(url)
    if u.scheme not in ("http", "https"):  # chrome://newtab, about:blank, devtools://
        return False
    host = u.hostname or ""
    if host == "linkedin.com" or host.endswith(".linkedin.com"):
        return False
    if host == "mail.google.com":  # the Gmail tab Workday verification reads
        return False
    return not (host in ("127.0.0.1", "localhost") and u.path == VIEW_RESULTS_PAGE)


def _pause(message):
    """Block for manual entry in the browser."""
    print(f"\n  >> {message}")
    input("  >> Fill anything needed in the browser, then press Enter to continue...")


async def _save_run_artifacts(page, slug):
    out_dir = os.path.join("applications", datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + slug)
    os.makedirs(out_dir, exist_ok=True)

    # Screenshot of the visible page.
    try:
        await page.screenshot(path=os.path.join(out_dir, "filled.png"), full_page=True)
        print(f"  Screenshot: {out_dir}/filled.png")
    except Exception as e:
        print(f"  (screenshot failed: {e})")

    # Full outer page HTML.
    try:
        html = await page.content()
        with open(os.path.join(out_dir, "page.html"), "w", encoding="utf-8") as f:
            f.write(html)
        print(f"  HTML dump:  {out_dir}/page.html")
    except Exception as e:
        print(f"  (page HTML dump failed: {e})")


async def apply_to(page, url):
    """Fill (and optionally submit) the application open in `page`, in place."""
    print(f"\n=== {url} ===")

    if applog.already_applied(url):
        print("  Already submitted previously -- skipping.")
        return

    adapter = adapters.pick_adapter(url)
    print(f"  Board: {adapter.NAME}")

    try:
        await page.wait_for_load_state("domcontentloaded", timeout=5000)
    except PlaywrightTimeoutError:
        pass

    # A listing page (e.g. an aggregator) whose Apply link leads to the real
    # ATS: follow it and route on the destination instead.
    if adapter is adapters.generic and await common.open_apply_link(page):
        adapter = adapters.pick_adapter(page.url)
        print(f"  Now at {page.url}\n  Board: {adapter.NAME}")

    title, company = await common.detect_job(page)
    job_text = f"{title} {company}".strip()
    job_description = await common.detect_job_description(page)
    print(f"  Title: {title or '(unknown)'}   Company: {company or '(unknown)'}")

    try:
        resume_path = resumes.select_resume(job_text, job_description)
    except FileNotFoundError as e:
        print(f"  ERROR: {e}")
        applog.record(url, adapter.NAME, company, title, "", "error")
        return
    print(f"  Resume: {resume_path}")
    filler.RESUME_TEXT = resumes.resume_text(resume_path)
    result = await adapter.apply(page, resume_path, job_text=job_text, company=company,
                                 job_description=job_description)

    print(f"  Filled {len(result['filled'])} field(s); "
          f"{len(result['unknown'])} unmapped; "
          f"resume uploaded: {result.get('resume_uploaded')}")
    if result["unknown"]:
        print("  Unmapped fields:")
        for u in result["unknown"]:
            print(f"    - {u}")

    # Manual entry for anything we couldn't fill.
    if result["unknown"] and config.MANUAL_FILL_PAUSE:
        _pause("Some fields could not be auto-filled (listed above).")

    if config.DRY_RUN_SCREENSHOT:
        await _save_run_artifacts(page, adapter.NAME)

    # Required-field guard.
    if config.CHECK_REQUIRED_BEFORE_SUBMIT and result.get("required_empty"):
        print("  Required fields still empty:")
        for r in result["required_empty"]:
            print(f"    - {r}")
        if config.MANUAL_FILL_PAUSE:
            _pause("Fill the required fields above before submitting.")
        else:
            print("  Refusing to submit with empty required fields.")
            applog.record(url, adapter.NAME, company, title,
                          os.path.basename(resume_path), "filled")
            return

    # Submit or stop.
    if await common.should_submit():
        btn = await common.find_submit_button(page)
        if btn is None:
            print("  Could not find a submit button; left filled.")
            applog.record(url, adapter.NAME, company, title,
                          os.path.basename(resume_path), "filled")
            return
        await btn.click()
        await page.wait_for_timeout(3000)
        print("  Submitted.")
        applog.record(url, adapter.NAME, company, title,
                      os.path.basename(resume_path), "submitted")
    else:
        print("  Form filled, NOT submitted (submit_application = false).")
        applog.record(url, adapter.NAME, company, title,
                      os.path.basename(resume_path), "filled")
        # Keep the browser open so the filled form can be reviewed before closing.
        _pause("Review the filled form in the browser.")


async def run(stealth=None):
    async with STEALTH.use_async(async_playwright()) as p:
        browser, _ = await attach_browser(p, CDP_URL, stealth=stealth)
        pages = [pg for ctx in browser.contexts for pg in ctx.pages if is_application_tab(pg.url)]
        if not pages:
            print("No application tabs open.")
            return
        print(f"Found {len(pages)} application tab(s).")
        # One at a time: apply_to pauses for review on each tab.
        for page in pages:
            url = page.url
            try:
                await page.bring_to_front()
                await apply_to(page, url)
            except Exception as e:
                print(f"  ERROR on {url}: {e}")
                applog.record(url, status="error")
        print("\nDone. Browser left open.")


if __name__ == "__main__":
    for path in (config.CONFIG_PATH, config.PROFILE_PATH):
        if not os.path.exists(path):
            name = os.path.basename(path)
            sys.exit(f"{name} not found: copy {name.replace('.toml', '.example.toml')} to {name} and fill it in.")
    parser = argparse.ArgumentParser(description="Fill the application forms open in your browser.")
    parser.add_argument("--stealth", action="store_true", default=None,
                        help="start the browser (if not running) with stealth_args")
    try:
        asyncio.run(run(stealth=parser.parse_args().stealth))
    except (KeyboardInterrupt, asyncio.exceptions.CancelledError):
        print("\nStopped.")
