"""Resume and cover-letter selection based on job-title keywords."""

import os
import re
import subprocess

import config

# A rule must hit the job description this many times to pick its resume when
# the title matched nothing; one passing "AI" mention shouldn't.
JD_MIN_HITS = 3


def _keyword_hits(keyword, text):
    """Whole-word occurrences, so "ui" doesn't hit "Build" nor "ai" "Maintain"."""
    return len(re.findall(rf"(?<![a-z0-9]){re.escape(keyword.lower())}(?![a-z0-9])",
                          (text or "").lower()))


def _match_rules(text: str, rules):
    """Return the value of the first rule whose any keyword is in `text`."""
    for keywords, value in rules:
        if any(_keyword_hits(kw, text) for kw in keywords):
            return value
    return None


def _best_rule_by_hits(text: str, rules):
    """Return the value of the rule with the most keyword hits in `text`
    (earlier rule on a tie), or None below JD_MIN_HITS."""
    best, best_hits = None, JD_MIN_HITS - 1
    for keywords, value in rules:
        hits = sum(_keyword_hits(kw, text) for kw in keywords)
        if hits > best_hits:
            best, best_hits = value, hits
    return best


def select_resume(job_text: str, job_description: str = "") -> str:
    """Pick a resume file path for the given job title / page text.

    Title keywords first (first rule wins); else the rule the job description
    mentions most; else DEFAULT_RESUME. A chosen file that's missing also
    falls back to DEFAULT_RESUME (with a warning). Returns an absolute-ish
    path under RESUME_DIR. Raises FileNotFoundError if the default is missing.
    """
    filename = (_match_rules(job_text, config.RESUME_RULES)
                or _best_rule_by_hits(job_description, config.RESUME_RULES)
                or config.DEFAULT_RESUME)
    path = os.path.join(config.RESUME_DIR, filename)
    if not os.path.exists(path) and filename != config.DEFAULT_RESUME:
        print(f"  WARNING: Resume '{filename}' not found in '{config.RESUME_DIR}/'; "
              f"using {config.DEFAULT_RESUME}.")
        filename = config.DEFAULT_RESUME
        path = os.path.join(config.RESUME_DIR, filename)
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Resume '{filename}' not found in '{config.RESUME_DIR}/'. "
            f"Add it, or fix resume_rules / default_resume in config.toml."
        )
    return path


def resume_text(path: str) -> str:
    """Plain text of a resume PDF (via poppler's pdftotext), or "" if it
    can't be read. Used to answer "have you worked with X?" honestly."""
    try:
        return subprocess.run(["pdftotext", "-layout", path, "-"], capture_output=True,
                              text=True, timeout=20, check=True).stdout
    except (OSError, subprocess.SubprocessError):
        return ""


def select_cover_letter(job_text: str, company: str = "") -> str:
    """Return cover-letter text for the job, with {company} substituted."""
    template = _match_rules(job_text, config.COVER_LETTER_RULES)
    if template is None:
        template = config.COVER_LETTER_DEFAULT
    return template.replace("{company}", company or "your team")
