"""Dayforce (jobs.dayforcehcm.com) adapter.

The posting page has an "Apply" button that leads to a choice page; "Apply
without an Account" opens the actual form (.../apply/manualApplication),
sometimes behind a privacy-statement modal we agree to.
We click through to it, then fill it like any other board via generic.
"""

import re

import filler
from adapters import generic

NAME = "dayforce"


async def _open_form(page):
    """Click Apply -> Apply without an Account, skipping steps already past."""
    steps = [
        page.locator("button").filter(has_text=re.compile(r"^\s*Apply\s*$")),
        page.locator("button").filter(has_text=re.compile(r"apply without an account", re.I)),
    ]
    for btn in steps:
        if "manualApplication" in page.url:
            break
        try:
            await btn.first.click(timeout=5000)
            await page.wait_for_load_state("domcontentloaded", timeout=10000)
        except Exception:
            continue  # already past this step (e.g. tab opened on the choice page)
    await page.locator("input[type=file]").first.wait_for(state="attached", timeout=10000)
    await _accept_privacy(page)


async def _accept_privacy(page):
    """Some tenants (e.g. Vantage) open a privacy-statement modal over the form;
    its Save stays disabled until "I agree" is checked."""
    modal = page.locator(".ant-modal, [role=dialog]").filter(has_text=re.compile("privacy", re.I)).first
    try:
        await modal.wait_for(state="visible", timeout=5000)
    except Exception:
        return  # this tenant has no privacy modal
    # Ant Design's checkbox input is opacity:0; click its visible label.
    await filler.click_visible_or_label(modal.locator("input[type=checkbox]").first)
    await modal.locator("button").filter(has_text=re.compile(r"^\s*Save\s*$")).first.click()
    await modal.wait_for(state="hidden", timeout=5000)


async def apply(page, resume_path, job_text="", company="", job_description=""):
    await _open_form(page)
    # "Import Resume" parses the upload into the form ~2.5s later, overwriting
    # (or clearing) anything filled before then.
    return await generic.apply(page, resume_path, job_text=job_text, company=company,
                               job_description=job_description, upload_settle_ms=4000)
