"""Ashby (jobs.ashbyhq.com) adapter.

Ashby application pages are a React single-page form. The "Application"
section holds the fields. Resume upload is a drop-zone backed by a hidden
file input, which set_input_files handles fine.

A posting opened on its Overview tab has no form: the apply button at the
bottom and the Application tab both link to <job-url>/application, so click
that link first.
"""

import filler
from adapters import common

NAME = "ashby"


async def apply(page, resume_path, job_text="", company="", job_description=""):
    from playwright.async_api import TimeoutError as PlaywrightTimeoutError
    if not page.url.split("?")[0].rstrip("/").endswith("/application"):
        # The link keeps the posting's query string (/application?src=Linkedin).
        apply_link = page.locator('a[href$="/application"], a[href*="/application?"]').first
        if await apply_link.count():
            await apply_link.click()
    try:
        await page.locator("input:not([type=hidden]):not([type=submit]):not([type=button]):not([type=file]), textarea").first.wait_for(state="attached", timeout=10000)
    except PlaywrightTimeoutError:
        pass
    result = await filler.fill_form(page, job_text=job_text, company=company, page=page, job_description=job_description)
    uploaded = await common.upload_resume(page, resume_path)
    result["resume_uploaded"] = uploaded
    return result
