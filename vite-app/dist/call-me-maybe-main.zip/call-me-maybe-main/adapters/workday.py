"""Workday (myworkdayjobs.com) adapter.

Workday's apply flow is a multi-step wizard, and a URL can land on any step
(posting, Apply popup, sign-in, resume upload, form) depending on the tenant
and whether you're signed in. Each loop iteration detects the current step and
acts on it. Accounts are per employer, with PROFILE["email"] /
PROFILE["workday_password"]; Gmail (another tab, see gmail.py) supplies any
verification or reset email. Sign-in is tried once per run. If it fails,
Workday's message can't tell "no account" from "wrong password" or "locked",
so we try Create Account; if that says the account exists, one password
reset, then one more sign-in. A new account is verified if the tenant emails
a link (on-page prompt or back on Sign In); a sign-in refused as unverified
gets one resend. Anything that fails falls back to a manual pause. Never
clicks the final Submit; fill.py owns that.

Observed flow: docs/devlog/2026-06-24-workday-apply-flow.md
"""

import asyncio
import re
from urllib.parse import urlparse

import filler
import gmail
from adapters import common

NAME = "workday"

MAX_STEPS = 20

_APPLY_BUTTON_SELECTORS = [
    "[data-automation-id='adventureButton']",
    # Shown instead of Apply when an application is already in progress.
    "[data-automation-id='continueButton']",
    "a:has-text('Continue Application')",
    "button:has-text('Continue Application')",
]

# The in-page popup shown after clicking Apply. Same id as the upload step's
# own "Autofill with Resume" trigger -- distinguished from it in _detect_step
# by checking for an actual file input/dropzone first.
_APPLY_CHOICE_MARKERS = [
    "[data-automation-id='autofillWithResume']",
    "[data-automation-id='applyManually']",
]

_SIGNIN_LANDING_SELECTORS = [
    "[data-automation-id='SignInWithEmailButton']",
]

_CREATE_ACCOUNT_MARKERS = [
    "[data-automation-id='createAccountSubmitButton']",
]

_SIGNIN_FORM_MARKERS = [
    "[data-automation-id='email']",
    "[data-automation-id='password']",
    "input[type=password]",
]

_EMAIL_SELECTORS = [
    "[data-automation-id='email']",
    "[data-automation-id='signInName']",
    "input[type=email]",
]

_PASSWORD_SELECTORS = [
    "[data-automation-id='password']",
    "input[type=password]",
]

_SIGNIN_SUBMIT_SELECTORS = [
    "[data-automation-id='signInSubmitButton']",
    "button:has-text('Sign In')",
]

_RESUME_UPLOAD_MARKERS = [
    "[data-automation-id='file-upload-drop-zone']",
    "input[type=file]",
]

_AUTOFILL_BUTTON_SELECTORS = [
    "[data-automation-id='autofillWithResume']",
    "button:has-text('Autofill with Resume')",
    "button:has-text('Autofill With Resume')",
]

_NEXT_SELECTORS = [
    "[data-automation-id='pageFooterNextButton']",  # "Save and Continue"
    "[data-automation-id='bottom-navigation-next-button']",
    "button:has-text('Next')",
    "button:has-text('Save and Continue')",
    "button:has-text('Continue')",
]


async def _visible_first(page, selectors):
    for sel in selectors:
        loc = page.locator(sel).first
        try:
            if await loc.count() and await loc.is_visible():
                return loc
        except Exception:
            continue
    return None


async def _fill_first(page, selectors, value):
    loc = await _visible_first(page, selectors)
    if loc is None:
        return False
    try:
        await loc.fill(value)
        return True
    except Exception:
        return False


async def _click_first(page, selectors):
    loc = await _visible_first(page, selectors)
    if loc is None:
        return False
    try:
        await loc.click(timeout=3000)
        return True
    except Exception:
        pass
    # A real click never settles while the browser window isn't being
    # painted (minimized/covered); element.click() still works -- on visible
    # elements only.
    return await filler.click_visible(loc)


async def _click_with_retry(page, selectors, attempts=10, interval_ms=300):
    """Click the first matching, visible selector, retrying briefly.

    Workday mounts the popup/landing-page buttons a beat after the
    triggering click resolves -- a single immediate attempt can race that.
    """
    for _ in range(attempts):
        if await _click_first(page, selectors):
            return True
        await page.wait_for_timeout(interval_ms)
    return False


async def _is_resume_upload_page(page):
    """The real upload step -- distinct from the Apply-choice popup, which
    shares the same "Autofill with Resume" element id but has no file input."""
    return await _visible_first(page, _RESUME_UPLOAD_MARKERS) is not None


async def _is_apply_choice_page(page):
    return await _visible_first(page, _APPLY_CHOICE_MARKERS) is not None


async def _is_create_account_page(page):
    return await _visible_first(page, _CREATE_ACCOUNT_MARKERS) is not None


async def _is_signin_form_page(page):
    return await _visible_first(page, _SIGNIN_FORM_MARKERS) is not None


async def _is_signin_landing_page(page):
    return await _visible_first(page, _SIGNIN_LANDING_SELECTORS) is not None


async def _is_job_posting_page(page):
    return await _visible_first(page, _APPLY_BUTTON_SELECTORS) is not None


async def _looks_like_form(page):
    """True once at least one real input/select/textarea has rendered.

    Workday is a heavy SPA -- right after navigation/domcontentloaded none of
    the step markers exist yet. Without this, a too-early scan falls through
    to "form" on a still-blank page and the apply loop bails immediately.
    """
    try:
        return await page.locator("input, select, textarea").first.is_visible()
    except Exception:
        return False


# Order matters: more specific steps first, since e.g. the resume upload page
# may also render the same "autofillWithResume" id as the choice popup.
_STEP_CHECKS = [
    # Before signin_form: the create-account page has email/password fields too.
    ("create_account", _is_create_account_page),
    ("signin_form", _is_signin_form_page),
    ("signin_landing", _is_signin_landing_page),
    ("resume_upload", _is_resume_upload_page),
    ("apply_choice", _is_apply_choice_page),
    ("job_posting", _is_job_posting_page),
]


async def _detect_step(page, timeout_ms=8000):
    """Classify the current step, waiting for the SPA to render if needed."""
    deadline = asyncio.get_event_loop().time() + timeout_ms / 1000
    while True:
        for label, check in _STEP_CHECKS:
            if await check(page):
                return label
        if await _looks_like_form(page):
            return "form"
        if asyncio.get_event_loop().time() >= deadline:
            return "form"
        await page.wait_for_timeout(250)


async def _wait_for_nav(page, timeout_ms=5000, settle_ms=700):
    try:
        await page.wait_for_load_state("domcontentloaded", timeout=timeout_ms)
    except Exception:
        pass
    await page.wait_for_timeout(settle_ms)


async def _attempt_auto_signin(page):
    """Fill in the configured Workday credentials and submit.

    Returns True once credentials were submitted -- not a guarantee sign-in
    succeeded. The caller re-checks whether we're still on a sign-in page
    afterwards (covers wrong password, 2FA, email verification, etc.).
    """
    from config import PROFILE
    password = PROFILE.get("workday_password")
    if not password:
        return False
    filled_email = await _fill_first(page, _EMAIL_SELECTORS, PROFILE["email"])
    filled_password = await _fill_first(page, _PASSWORD_SELECTORS, password)
    if not (filled_email and filled_password):
        return False
    await _click_button(page, "signInSubmitButton")
    await _wait_for_nav(page, settle_ms=1000)
    # Accenture takes a few seconds: wait for the form to go or an error to
    # show, else the caller sees the form still up and gives up.
    for _ in range(30):
        if await _page_error(page) or not await _is_signin_form_page(page):
            break
        await page.wait_for_timeout(500)
    await _wait_for_nav(page)
    error = await _page_error(page)
    if error:
        print(f"  Workday sign-in: {error}")
    return True


async def _click_button(page, automation_id):
    """Click a Workday button by automation id. Workday hides the real button
    (aria-hidden, covered) under a `click_filter` div that takes the click, so
    click that -- never the hidden button. A real click first; if it can't
    settle (the window isn't being painted), filler.click_visible."""
    btn = page.locator(f"[data-automation-id='{automation_id}']").first
    overlay = btn.locator("xpath=following-sibling::*[@data-automation-id='click_filter'] | "
                          "preceding-sibling::*[@data-automation-id='click_filter']").first
    target = overlay if await overlay.count() else btn
    try:
        await target.click(timeout=3000)
        return
    except Exception:
        pass
    if not await filler.click_visible(target):
        print(f"  Couldn't click Workday button {automation_id!r} (not visibly clickable).")


async def _page_error(page):
    """Text of a visible Workday form error, or ""."""
    err = page.locator("[data-automation-id='errorMessage'], [role=alert]").filter(visible=True)
    try:
        return " ".join(t.strip() for t in await err.all_inner_texts()).strip()
    except Exception:
        return ""


async def _asks_for_verification(page):
    """True if the page after Create Account asks to verify the email."""
    try:
        text = await page.locator("[data-automation-id='auth_container'], "
                                  "[data-automation-id='applyFlowPage']").first.inner_text(timeout=2000)
    except Exception:
        return False
    low = text.lower()
    return any(k in low for k in ("verification code", "verify your", "enter the code",
                                  "check your email", "confirm your email"))


async def _create_account(page):
    """Create this employer's account and verify it via Gmail. Returns False
    if it needs you (no password configured, password rules, unknown screen),
    "exists" if the account already existed (now on Sign In), else True."""
    from config import PROFILE
    password = PROFILE.get("workday_password")
    if not password:
        return False

    inbox = await gmail.open_inbox(page)
    before = await gmail.inbox_snapshot(inbox)
    await page.bring_to_front()

    await _fill_first(page, ["[data-automation-id='email']"], PROFILE["email"])
    await _fill_first(page, ["[data-automation-id='password']"], password)
    await _fill_first(page, ["[data-automation-id='verifyPassword']"], password)
    # The checkbox input is opacity:0 under a styled box: click its label.
    box = page.locator("[data-automation-id='createAccountCheckbox']").first
    if await box.count() and not await box.is_checked():
        await filler.click_visible_or_label(box)
    # The first click sometimes doesn't register (Sedgwick: valid form, no
    # request sent), so click again if the form is still there with no error.
    for _ in range(3):
        await _click_button(page, "createAccountSubmitButton")
        await _wait_for_nav(page, settle_ms=1000)
        # Some tenants (e.g. DXC) take several seconds to accept: wait for the
        # form to go away or an error to show, not a fixed delay.
        for _ in range(20):
            if await _page_error(page) or not await _is_create_account_page(page):
                break
            await page.wait_for_timeout(500)
        else:
            continue
        break

    error = await _page_error(page)
    if "already" in error.lower():
        print("  Workday account already exists; signing in.")
        await _click_button(page, "signInLink")
        await _wait_for_nav(page)
        return "exists"  # the loop picks up the sign-in form
    if await _is_create_account_page(page):
        print(f"  Create Account didn't go through: {error or '(no message)'}")
        return False
    # Back on Sign In (Accenture): created but unverified, with the email
    # sent and no on-page hint.
    if not await _asks_for_verification(page) and not await _is_signin_form_page(page):
        # Most tenants (e.g. Salesforce) activate the account immediately and
        # sign you in -- no email is sent, so don't wait for one.
        return True

    print("  Waiting for the Workday verification email...")
    try:
        found = await gmail.wait_for_email(inbox, before, "verify", tenant=_tenant(page))
    except TimeoutError as e:
        print(f"  {e}")
        return False
    await page.bring_to_front()
    if found["code"]:
        print("  Entering verification code from email.")
        field = page.locator("input[type=text], input:not([type])").filter(visible=True).first
        await field.fill(found["code"])
        await _click_first(page, ["button[type=submit]", "button:has-text('Verify')",
                                  "button:has-text('Submit')", "button:has-text('Continue')"])
    else:
        print("  Opening verification link from email.")
        back = page.url
        await page.goto(found["link"])
        await _wait_for_nav(page, settle_ms=2000)
        await page.goto(back)
    await _wait_for_nav(page, settle_ms=2000)
    return True


def _tenant(page):
    # Workday mails as the tenant ("salesforce"), the URL's first label.
    return (urlparse(page.url).hostname or "").split(".")[0]


_LOCKED = re.compile(r"lock|too many", re.I)


async def _reset_password(page):
    """After a lockout: request a reset, take the link from Gmail, and set the
    password back to PROFILE["workday_password"]. Returns True if the new
    password was submitted; the caller then signs in once more."""
    from config import PROFILE
    password = PROFILE.get("workday_password")
    if not password:
        return False
    inbox = await gmail.open_inbox(page)
    before = await gmail.inbox_snapshot(inbox)
    await page.bring_to_front()
    back = page.url

    await _click_button(page, "forgotPasswordLink")
    await _wait_for_nav(page)
    await _fill_first(page, _EMAIL_SELECTORS, PROFILE["email"])
    await _click_button(page, "resetPasswordButton")
    await _wait_for_nav(page, settle_ms=1500)

    print("  Waiting for the Workday password-reset email...")
    try:
        found = await gmail.wait_for_email(inbox, before, "reset", tenant=_tenant(page))
    except TimeoutError as e:
        print(f"  {e}")
        return False
    await page.bring_to_front()
    await page.goto(found["link"])
    await _wait_for_nav(page, settle_ms=2000)
    fields = page.locator("input[type=password]").filter(visible=True)
    if not await fields.count():
        print("  Reset page has no password fields; leaving it to you.")
        return False
    for i in range(await fields.count()):
        await fields.nth(i).fill(password)
    await _click_first(page, ["[data-automation-id*='ubmit']", "button[type=submit]",
                              "button:has-text('Reset')", "button:has-text('Submit')",
                              "button:has-text('Save')"])
    await _wait_for_nav(page, settle_ms=2000)
    error = await _page_error(page)
    if error:
        # e.g. the tenant refuses a previously used password.
        print(f"  Password reset: {error}")
        return False
    print("  Password reset to the configured workday_password.")
    await page.goto(back)
    await _wait_for_nav(page, settle_ms=1500)
    return True


_UNVERIFIED = re.compile(r"verify your account|verification email", re.I)


async def _resend_verification(page):
    """Sign-in refused an unverified account (Accenture: "Verify your account
    before you sign in"): resend the email, open its link from Gmail, and come
    back. Returns True if the link was opened; the caller signs in once more."""
    from config import PROFILE
    resend = ["[data-automation-id='informationalBlurbButton']"]
    if await _visible_first(page, resend) is None:
        return False
    inbox = await gmail.open_inbox(page)
    before = await gmail.inbox_snapshot(inbox)
    await page.bring_to_front()
    back = page.url

    await _fill_first(page, _EMAIL_SELECTORS, PROFILE["email"])
    await _click_button(page, "informationalBlurbButton")
    await _wait_for_nav(page, settle_ms=1500)

    print("  Account not verified; waiting for the Workday verification email...")
    try:
        found = await gmail.wait_for_email(inbox, before, "verify", tenant=_tenant(page))
    except TimeoutError as e:
        print(f"  {e}")
        return False
    await page.bring_to_front()
    if not found["link"]:
        print("  Verification email had no link; leaving it to you.")
        return False
    print("  Opening verification link from email.")
    await page.goto(found["link"])
    await _wait_for_nav(page, settle_ms=2000)
    await page.goto(back)
    await _wait_for_nav(page, settle_ms=1500)
    return True


async def _wait_for_manual_signin(page):
    """Block until the user finishes signing in manually (no matching fields,
    wrong password, 2FA, email verification)."""
    common.pause_for_manual_action(
        "Couldn't sign in to this Workday application automatically "
        "(2FA, verification, or a password mismatch). Log in (or create an "
        "account) in the browser, then continue."
    )
    await _wait_for_nav(page, timeout_ms=10000)


async def _has_uploaded_file(page):
    """True if this step already lists an uploaded file (Workday shows
    "<name> Successfully Uploaded!" as a file-upload-item)."""
    return await _visible_first(page, ["[data-automation-id='file-upload-item']"]) is not None


async def _autofill_with_resume(page, resume_path):
    """Upload the resume and trigger Workday's "Autofill with Resume" parse."""
    uploaded = await common.upload_resume(page, resume_path)
    if not uploaded:
        return False
    await _click_first(page, _AUTOFILL_BUTTON_SELECTORS)
    return uploaded


async def _active_step(page):
    """The progress bar's current step ("My Experience"), or "" if none."""
    try:
        text = await page.locator("[data-automation-id='progressBarActiveStep']").first.text_content(timeout=1000)
    except Exception:
        return ""
    return re.sub(r"^\s*current step \d+ of \d+\s*", "", text or "").strip()


async def _step_changed(page, before, timeout_ms=20000):
    # Saving a step with several parsed work-history entries can take >6s.
    if not before:
        return True  # no progress bar (sign-in, posting): can't tell, assume yes
    for _ in range(timeout_ms // 250):
        if await _active_step(page) != before:
            return True
        await page.wait_for_timeout(250)
    return False


async def _wait_for_upload(page, timeout_ms=15000):
    try:
        await page.locator("[data-automation-id='file-upload-successful']").first.wait_for(
            state="attached", timeout=timeout_ms)
    except Exception:
        print("  (resume upload not confirmed by Workday)")


async def _find_next_button(page):
    """Return the step's Next/Continue button, or None on the final Submit step.

    Workday reuses the same bottom-navigation button across steps, only
    relabeling it "Submit" on the review step -- we must not auto-click that;
    leave it for fill.py's submit gating.
    """
    loc = await _visible_first(page, _NEXT_SELECTORS)
    if loc is None:
        return None
    try:
        text = (await loc.inner_text()).strip().lower()
    except Exception:
        return loc
    if "submit" in text:
        return None
    return loc


async def _poll_for_next_button(page, timeout_ms=4000):
    deadline = asyncio.get_event_loop().time() + timeout_ms / 1000
    while True:
        btn = await _find_next_button(page)
        if btn is not None:
            return btn
        if asyncio.get_event_loop().time() >= deadline:
            return None
        await page.wait_for_timeout(250)


async def apply(page, resume_path, job_text="", company="", job_description=""):
    resume_uploaded = False
    auth_tried = set()
    filled_all, unknown_all = [], []
    result = {"filled": [], "unknown": [], "required_empty": []}

    for _ in range(MAX_STEPS):
        step = await _detect_step(page)

        if step == "job_posting":
            if not await _click_first(page, _APPLY_BUTTON_SELECTORS):
                break
            await _wait_for_nav(page)
            continue

        if step == "apply_choice":
            # In-page popup, not a navigation -- the click can race the
            # popup's mount, so retry briefly.
            if not await _click_with_retry(page, _APPLY_CHOICE_MARKERS):
                break
            await _wait_for_nav(page)
            continue

        if step == "signin_landing":
            # Only SSO buttons are shown at first; reveal the email/password
            # form before the next loop iteration tries to fill it.
            if not await _click_with_retry(page, _SIGNIN_LANDING_SELECTORS):
                await _wait_for_manual_signin(page)
            await _wait_for_nav(page)
            continue

        # Back on Sign In after a failed sign-in and Create Account said the
        # account exists: the password differs, so reset it once.
        if step == "signin_form" and {"signin_form", "create_account"} <= auth_tried \
                and "reset" not in auth_tried:
            auth_tried.add("reset")
            if await _reset_password(page):
                auth_tried.discard("signin_form")
            else:
                await _wait_for_manual_signin(page)
            continue

        # One automatic try each per run: repeated failed sign-ins lock the
        # Workday account, so a second visit goes straight to you.
        if step in ("create_account", "signin_form") and step in auth_tried:
            await _wait_for_manual_signin(page)
            continue
        auth_tried.add(step)

        if step == "create_account":
            created = await _create_account(page)
            if not created:
                await _wait_for_manual_signin(page)
            elif created != "exists":
                auth_tried.discard("signin_form")  # a new account: sign in with it
            continue

        if step == "signin_form":
            attempted = await _attempt_auto_signin(page)
            if attempted and await _is_signin_form_page(page) \
                    and _UNVERIFIED.search(await _page_error(page)) and "verify" not in auth_tried:
                # Created but never verified: resend once, then sign in again.
                auth_tried.add("verify")
                if await _resend_verification(page):
                    auth_tried.discard("signin_form")
                    continue
            failed = attempted and await _is_signin_form_page(page) \
                and _LOCKED.search(await _page_error(page))
            if failed and "create_account" not in auth_tried \
                    and await _visible_first(page, ["[data-automation-id='createAccountLink']"]):
                # Workday says "wrong email or password or ... locked" for a
                # tenant you have no account on too (Accenture): create one
                # first; "already exists" there leads to the reset above.
                await _click_button(page, "createAccountLink")
                await _wait_for_nav(page)
                continue
            if failed and "reset" not in auth_tried:
                # Locked out: reset once, then allow one more sign-in.
                auth_tried.add("reset")
                if await _reset_password(page):
                    auth_tried.discard("signin_form")
                    continue
            if not attempted or await _is_signin_form_page(page):
                await _wait_for_manual_signin(page)
            continue

        if step == "resume_upload":
            # Any step with a file drop zone: the first "Autofill with Resume"
            # page, and later My Experience, which shows an empty upload again
            # even after that. Upload whenever no file is listed.
            if not await _has_uploaded_file(page):
                if await _autofill_with_resume(page, resume_path):
                    resume_uploaded = True
                    await _wait_for_upload(page)
            # Fall through: the step's other fields (e.g. LinkedIn URL) and Next.

        result = await filler.fill_form(
            page, job_text=job_text, company=company, page=page,
            job_description=job_description,
        )
        filled_all.extend(result["filled"])
        unknown_all.extend(result["unknown"])

        next_btn = await _poll_for_next_button(page)
        if next_btn is None:
            break
        before = await _active_step(page)
        # Works even when the window isn't being painted.
        if not await filler.click_visible(next_btn):
            print("  Next button isn't visibly clickable; stopping here.")
            break
        await _wait_for_nav(page)
        # Blocked (a required answer missing or rejected): refilling the same
        # step would loop, so stop and leave it to you.
        if not await _step_changed(page, before):
            print(f"  '{before}' didn't advance (required answers missing?); stopping here.")
            break

    return {
        "filled": filled_all,
        "unknown": list(dict.fromkeys(unknown_all)),
        "required_empty": result.get("required_empty", []),
        "resume_uploaded": resume_uploaded,
    }
