"""Board adapters and routing.

Each adapter knows how to locate the application form, upload the right
resume, and (optionally) submit, for one job board. `pick_adapter` chooses
one based on the URL host.
"""

from urllib.parse import urlparse

from adapters import greenhouse, ashby, workday, dayforce, talenthop, workable, generic

# host substring -> adapter module
_ROUTES = [
    ("greenhouse.io", greenhouse),
    ("ashbyhq.com", ashby),
    ("myworkdayjobs.com", workday),
    ("dayforcehcm.com", dayforce),
    ("talenthop.com", talenthop),
    ("workable.com", workable),
]


def pick_adapter(url: str):
    host = (urlparse(url).netloc or "").lower()
    for needle, mod in _ROUTES:
        if needle in host:
            return mod
    return generic
