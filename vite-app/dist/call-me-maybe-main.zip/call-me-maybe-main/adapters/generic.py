"""Generic fallback adapter.

Used for any board without a dedicated adapter. Finds the form scope (an
iframe or the page), uploads the resume, fills each page with
filler.fill_form, and clicks Next across multi-page forms. All field handling
lives in filler.py (see ARCHITECTURE.md).

Also does, generically, what the Workday adapter learned: a sign-in /
create-account page is filled once per run (email + workday_password, with a
Gmail verification code or link if the site asks); a later page with an empty
resume upload gets the resume again; slow saves are waited for; an empty
Website/Portfolio section gets its Add clicked, and a page's late-mounting
sections are waited for (up to 5s) before filling. Every one of
these is tried at most once per page or run, with a capped wait, so a site
without them never loops.

And what the Ashby adapter learned: a form rendered by JavaScript is waited
for, and a posting opened on its description (Ashby's Overview tab) is
clicked through to its application form via a link to <job-url>/application
or /apply. Once per run, before the first page, with capped waits.
"""

import asyncio
import re
from urllib.parse import urlparse

import filler
import gmail
from adapters import common

NAME = "generic"


async def get_form_scope(page):
    """Return the locator/frame containing the application form.

    Many ATSes (Greenhouse's older variant, some embeds) render the form inside
    an iframe. We try iframes that look like application forms; otherwise we use
    the page itself, preferring a <form> element if present.
    """
    from playwright.async_api import TimeoutError as PlaywrightTimeoutError

    # 1. Look for an iframe that contains a form. Check the most likely first.
    iframe_selectors = [
        "iframe[id*=grnhse]", "iframe[src*=greenhouse]",
        "iframe[id*=application]", "iframe[src*=apply]",
        "iframe[src*=ashby]", "iframe[title*=application i]",
        "iframe",  # last resort: any iframe with a form inside
    ]
    for sel in iframe_selectors:
        try:
            loc = page.locator(sel).first
            if not await loc.count():
                continue
            frame = page.frame_locator(sel)
            # Confirm it actually has a form before committing to it.
            await frame.locator("form, input, select").first.wait_for(
                state="attached", timeout=1500)
            return frame
        except PlaywrightTimeoutError:
            continue
        except Exception:
            continue

    # 2. No usable iframe -- prefer a single top-level <form>, else the page
    # (Dayforce splits one application across a <form> per section).
    try:
        forms = page.locator("form")
        if await forms.count() == 1:
            return forms.first
    except Exception:
        pass
    return page


_NEXT_SELECTORS = [
    "button:has-text('Next')",
    "button:has-text('Save and Continue')",
    "button:has-text('Continue')",
    "button:has-text('Next step')",
    "button:has-text('Next Step')",
    "button[aria-label*='next' i]",
    "a:has-text('Next')",
]


async def _find_next_button(page):
    """Return a visible Next/Continue button if one exists, else None."""
    for sel in _NEXT_SELECTORS:
        loc = page.locator(sel).first
        try:
            if await loc.count() and await loc.is_visible():
                return loc
        except Exception:
            continue
    return None


async def _field_ids(scope):
    """Ids/names of the visible form fields -- changes when a wizard advances."""
    try:
        return await scope.locator("input, select, textarea").evaluate_all(
            "els => els.filter(e => e.offsetParent).map(e => e.id || e.name)")
    except Exception:
        return None


async def _advanced(scope, before, timeout_ms=15000):
    # Returns as soon as the step changes; a long cap only matters when Next
    # is blocked. Some ATSes take several seconds to save a step.
    """Poll until the visible fields differ from `before` (the step changed)."""
    for _ in range(timeout_ms // 250):
        if await _field_ids(scope) != before:
            return True
        await asyncio.sleep(0.25)
    return False


_AUTH_SUBMIT_TEXT = re.compile(
    r"^\s*(?:create (?:my )?account|sign in|log ?in|register|sign up|continue)\s*$", re.I)
_VERIFY_TEXT = re.compile(r"verification code|verify your (?:email|account)|enter the code|"
                          r"check your email|confirm your email", re.I)


async def _visible(locator):
    """Locators among `locator` a person can see (not off-screen/hidden)."""
    out = []
    for i in range(await locator.count()):
        el = locator.nth(i)
        try:
            if await el.evaluate(filler._FIELD_VISIBLE_JS):
                out.append(el)
        except Exception:
            continue
    return out


async def _click(loc):
    """A real click first; if it can't settle (window not painted), a
    filler.click_visible one -- never on a hidden element."""
    try:
        await loc.click(timeout=3000)
        return True
    except Exception:
        return await filler.click_visible(loc)


async def _sign_in(page, scope, company):
    """A sign-in / create-account form (a visible password field): fill the
    email and every password field from config.toml [profile], let fill_form tick
    consent boxes, submit, and verify the email via Gmail if asked. Called at
    most once per run. Returns True if it submitted."""
    from config import PROFILE
    password = PROFILE.get("workday_password")
    passwords = await _visible(scope.locator("input[type=password]"))
    if not password or not passwords:
        return False
    emails = await _visible(scope.locator("input[type=email], input[name*=email i], "
                                          "input[id*=email i], input[autocomplete=username]"))
    if not emails:
        return False
    host = urlparse(page.url).hostname or ""
    inbox = before = None
    try:
        inbox = await gmail.open_inbox(page, timeout_s=60)
        before = await gmail.inbox_snapshot(inbox)
        await page.bring_to_front()
    except Exception:
        pass  # no Gmail: still try; a verification step then falls to you
    print("  Sign-in / account form: filling email and password.")
    await emails[0].fill(PROFILE["email"])
    for field in passwords:
        await field.fill(password)
    await filler.fill_form(scope, company=company, page=page)  # consent boxes etc.
    buttons = await _visible(scope.locator("button, input[type=submit], [role=button]").filter(
        has_text=_AUTH_SUBMIT_TEXT))
    if not buttons or not await _click(buttons[0]):
        print("  No visible sign-in / create-account button; leaving it to you.")
        return False
    try:
        await page.wait_for_load_state("domcontentloaded", timeout=10000)
    except Exception:
        pass
    await asyncio.sleep(2)

    try:
        text = await page.locator("body").inner_text(timeout=3000)
    except Exception:
        text = ""
    if inbox is None or not _VERIFY_TEXT.search(text):
        return True
    print("  Waiting for the verification email...")
    tenant = (company or "").split()[0].lower() if company else host.split(".")[0]
    try:
        found = await gmail.wait_for_email(inbox, before, "verify", tenant=tenant, host=host)
    except TimeoutError as e:
        print(f"  {e}")
        return True
    await page.bring_to_front()
    if found["code"]:
        fields = await _visible(page.locator("input[type=text], input[type=number], input:not([type])"))
        if fields:
            await fields[0].fill(found["code"])
            submit = await _visible(page.locator("button, input[type=submit]").filter(
                has_text=re.compile(r"verify|submit|continue|confirm", re.I)))
            if submit:
                await _click(submit[0])
    elif found["link"]:
        back = page.url
        await page.goto(found["link"])
        await asyncio.sleep(2)
        await page.goto(back)
    return True


async def _upload_again(scope, resume_path):
    """On a later page: an empty file input labelled resume/CV (not a cover
    letter) gets the resume, as Workday's My Experience page needs."""
    for el in await _visible(scope.locator("input[type=file]")):
        try:
            info = await el.evaluate("""e => ({empty: !e.files || e.files.length === 0,
                text: ((e.labels && e.labels[0] && e.labels[0].innerText) || '') + ' ' +
                      (e.closest('fieldset, section, [class*=upload i], [data-automation-id]') || e.parentElement).innerText})""")
        except Exception:
            continue
        low = info["text"].lower()
        if info["empty"] and re.search(r"resume|\bcv\b|curriculum", low) and "cover" not in low:
            await el.set_input_files(resume_path)
            print("    [upload] resume set on a later page's empty upload")
            return True
    return False


_FILLABLE = ("input:not([type=hidden]):not([type=submit]):not([type=button])"
             ":not([type=file]), textarea, select")
_APPLY_PATH = re.compile(r"/(?:application|apply)/?$", re.I)


def _is_apply_href(href, page_url):
    """True for a same-site link to an application form (".../application",
    ".../apply") that isn't the page we're already on."""
    target, here = urlparse(href or ""), urlparse(page_url or "")
    if target.hostname and target.hostname != here.hostname:
        return False
    if not _APPLY_PATH.search(target.path):
        return False
    return target.path.rstrip("/") != here.path.rstrip("/")


async def _wait_for_fields(page, timeout_ms):
    """True once a visible fillable field exists (page or form iframe),
    False after timeout_ms."""
    from playwright.async_api import TimeoutError as PlaywrightTimeoutError
    scope = await get_form_scope(page)
    try:
        await scope.locator(_FILLABLE).filter(visible=True).first.wait_for(
            state="attached", timeout=timeout_ms)
        return True
    except PlaywrightTimeoutError:
        return False
    except Exception:
        return False


async def _apply_link(page):
    """The first visible link to this job's application form, else None."""
    links = page.locator("a[href]")
    try:
        # One round-trip for every href; visibility (a scroll each) only for candidates.
        hrefs = await links.evaluate_all("els => els.map(a => a.href)")
    except Exception:
        return None
    for i, href in enumerate(hrefs):
        if _is_apply_href(href, page.url) and await _visible(links.nth(i)):
            return links.nth(i)
    return None


async def _open_application_form(page, mount_ms=5000, after_click_ms=10000):
    """A page with no fields yet: wait for a JavaScript form to mount, else
    follow a link to the application form once and wait for it. Returns True
    if it followed a link. At most one link and two capped waits per run."""
    if await _wait_for_fields(page, mount_ms):
        return False
    link = await _apply_link(page)
    if link is None:
        return False
    print("  No form on this page; opening the application form.")
    if (await link.get_attribute("target") or "").lower() == "_blank":
        await page.goto(await link.evaluate("a => a.href"))  # stay in this tab
    elif not await _click(link):
        return False
    try:
        await page.wait_for_load_state("domcontentloaded", timeout=5000)
    except Exception:
        pass
    await _wait_for_fields(page, after_click_ms)
    return True


async def apply(page, resume_path, job_text="", company="", job_description="",
                upload_settle_ms=1000):
    """upload_settle_ms: pause after the resume upload before filling; boards
    that parse the resume into the form (Dayforce) need longer."""
    filled_all, unknown_all = [], []
    uploaded = False
    result = {"filled": [], "unknown": [], "required_empty": []}
    MAX_PAGES = 10

    await _open_application_form(page)
    signed_in = False
    for page_num in range(MAX_PAGES):
        scope = await get_form_scope(page)

        # A sign-in / create-account page: once per run, then re-scan.
        if not signed_in and await _visible(scope.locator("input[type=password]")):
            signed_in = True
            if await _sign_in(page, scope, company):
                continue

        # Upload resume before filling so any fields that appear conditionally
        # after upload (e.g. Rippling's sponsorship question) are present.
        if not uploaded:
            uploaded = await common.upload_resume(scope, resume_path)
            if not uploaded and scope is not page:
                uploaded = await common.upload_resume(page, resume_path)
            if uploaded and page_num == 0:
                # Wait for any dynamically revealed fields to render.
                await page.wait_for_timeout(upload_settle_ms)
        elif page_num > 0:
            await _upload_again(scope, resume_path)

        # Additions, both bounded: reveal an empty Website/Portfolio entry,
        # then let late-mounting sections render (<= 5s) before filling.
        await common.open_website_entry(scope)
        await filler.wait_for_fields_settled(scope)
        result = await filler.fill_form(
            scope, job_text=job_text, company=company, page=page,
            job_description=job_description,
        )

        filled_all.extend(result["filled"])
        unknown_all.extend(result["unknown"])

        next_btn = await _find_next_button(page)
        if next_btn is None:
            break

        before = await _field_ids(scope)
        if not await _click(next_btn):
            print("  Next isn't visibly clickable; stopping here.")
            break
        try:
            await page.wait_for_load_state("domcontentloaded", timeout=5000)
        except Exception:
            pass
        # Next blocked (usually a required field is empty): refilling the same
        # step would loop, so stop and leave it to the caller's manual pause.
        if not await _advanced(scope, before):
            print("  Next didn't advance (required field empty?); stopping here.")
            break

    return {
        "filled": filled_all,
        "unknown": unknown_all,
        "required_empty": result.get("required_empty", []),
        "resume_uploaded": uploaded,
    }
