"""Shared helpers for board adapters."""

import html
import json
import re

import config

# "Apply", "Apply Now", "Apply for This Job", "Continue Application" (an
# application in progress) -- but not "Applied" or "How to apply".
_APPLY_TEXT = re.compile(r"^\s*(?:apply\b|continue application\b)", re.I)


def is_apply_text(text):
    return bool(_APPLY_TEXT.match(text or ""))


async def open_apply_link(page):
    """On a listing page with no resume upload yet (aggregators, careers
    sites), follow its Apply link/button. Links are followed in this tab even
    when they're target=_blank, so the caller keeps working on `page`.
    Returns True if it navigated."""
    for frame in page.frames:
        try:
            accepts = await frame.locator("input[type=file]").evaluate_all(
                "els => els.map(e => e.getAttribute('accept'))")
        except Exception:
            continue
        if any(not is_media_only(a) for a in accepts):
            return False
    candidates = page.locator("a, button, [role=button]").filter(has_text=_APPLY_TEXT)
    for i in range(await candidates.count()):
        btn = candidates.nth(i)
        try:
            if not await btn.is_visible():
                continue
            href = await btn.evaluate("el => el.href || ''")
            print(f"  Following apply link: {(await btn.inner_text()).strip()!r}")
            if href.startswith("http"):
                await page.goto(href, timeout=30000)
            else:
                await btn.click(timeout=5000)
            await page.wait_for_load_state("domcontentloaded", timeout=10000)
            return True
        except Exception as e:
            print(f"  (apply link failed: {e})")
            continue
    return False


def job_posting_from_ld(blobs):
    """Pull {title, company, description} from the first schema.org JobPosting
    in a page's ld+json blobs (most ATSes emit one). Empty dict if none."""
    def postings(node):
        if isinstance(node, list):
            for n in node:
                yield from postings(n)
        elif isinstance(node, dict):
            types = node.get("@type")
            if "JobPosting" in (types if isinstance(types, list) else [types]):
                yield node
            yield from postings(node.get("@graph", []))

    for blob in blobs:
        try:
            data = json.loads(blob)
        except (TypeError, ValueError):
            continue
        for jp in postings(data):
            out = {}
            if jp.get("title"):
                out["title"] = str(jp["title"]).strip()
            org = jp.get("hiringOrganization")
            if isinstance(org, dict) and org.get("name"):
                # Workday prefixes an internal company code: "100 Salesforce, Inc."
                out["company"] = re.sub(r"^\d+\s+", "", str(org["name"]).strip())
            if jp.get("description"):
                text = html.unescape(re.sub(r"<[^>]+>", " ", str(jp["description"])))
                out["description"] = re.sub(r"\s+", " ", text).strip()
            return out
    return {}


async def _job_posting(page):
    blobs = []
    for frame in page.frames:
        try:
            blobs += await frame.locator("script[type='application/ld+json']").all_text_contents()
        except Exception:
            continue
    return job_posting_from_ld(blobs)


async def detect_job(page):
    """Best-effort (title, company) extraction from a job/application page.
    Prefers the JobPosting JSON-LD; generic class guesses like [class*=title]
    are avoided (Gem's first one is an EEO widget)."""
    jp = await _job_posting(page)
    title, company = jp.get("title", ""), jp.get("company", "")
    if not title:
        try:
            title = await page.evaluate(
                """() => {
                    const h1 = document.querySelector('h1');
                    if (h1 && h1.innerText.trim()) return h1.innerText.trim();
                    const og = document.querySelector('meta[property="og:title"]');
                    if (og && og.content) return og.content;
                    return document.title || '';
                }"""
            )
        except Exception:
            pass
    if not company:
        try:
            company = await page.evaluate(
                """() => {
                    const og = document.querySelector('meta[property="og:site_name"]');
                    if (og && og.content) return og.content;
                    const el = document.querySelector('[class*=company]');
                    return el ? el.innerText.trim() : '';
                }"""
            )
        except Exception:
            pass
    return title.strip(), company.strip()


# Runs in each frame. Searches the DOM and every shadow root under it
# (recursively) for a description container; else the meta description;
# else all text, shadow DOM included (innerText skips shadow roots).
_DESCRIPTION_JS = """() => {
    const roots = [document];
    for (let i = 0; i < roots.length; i++)
        for (const el of roots[i].querySelectorAll('*'))
            if (el.shadowRoot) roots.push(el.shadowRoot);
    const sel = ['[class*=description]', '[id*=description]', '[class*=job-details]',
                 '[class*=posting]', '[class*=content]', 'main', 'article'];
    for (const s of sel)
        for (const root of roots)
            for (const el of root.querySelectorAll(s))
                if (el.innerText && el.innerText.trim().length > 200) return [el.innerText, true];
    for (const s of ['meta[name=description]', 'meta[property="og:description"]']) {
        const m = document.querySelector(s);
        if (m && m.content && m.content.length > 200) return [m.content, true];
    }
    const deep = node => node.nodeType === Node.TEXT_NODE ? node.textContent
        : [...(node.shadowRoot ? node.shadowRoot.childNodes : []), ...node.childNodes]
              .filter(n => !['SCRIPT', 'STYLE', 'NOSCRIPT'].includes(n.nodeName))
              .map(deep).join(' ');
    return [document.body ? deep(document.body).replace(/\\s+/g, ' ') : '', false];
}"""


async def detect_job_description(page):
    """Return the job-posting text (used to pick a resume and read a salary
    range). JobPosting JSON-LD first; then the first frame (main page first)
    where _DESCRIPTION_JS finds a description; else the longest frame text."""
    jp = await _job_posting(page)
    if len(jp.get("description", "")) > 200:
        return jp["description"]
    best = ""
    for frame in page.frames:
        try:
            text, found = await frame.evaluate(_DESCRIPTION_JS)
        except Exception:
            continue
        if found:
            return text
        if len(text.strip()) > len(best.strip()):
            best = text
    return best


async def new_tab(near, url):
    """Open url in a new tab beside page `near`, in its window. A plain
    context.new_page() over CDP sometimes opens a whole new window; the
    opener's own window.open() can't, and userGesture gets it past the popup
    blocker. Returns the new page."""
    cdp = await near.context.new_cdp_session(near)
    try:
        async with near.context.expect_page() as info:
            await cdp.send("Runtime.evaluate", {
                "expression": f"window.open({json.dumps(url)}, '_blank', 'noopener'); 0",
                "userGesture": True})
        page = await info.value
    finally:
        await cdp.detach()
    await page.wait_for_load_state("domcontentloaded")
    return page


def is_media_only(accept):
    """True for a file input's `accept` that allows only images/video/audio (a
    photo field, a chat widget's video upload), which must not get the resume."""
    kinds = [k.strip().lower() for k in (accept or "").split(",") if k.strip()]
    return bool(kinds) and all(k.startswith(("image/", "video/", "audio/")) or k in _MEDIA_EXTS
                               for k in kinds)


_MEDIA_EXTS = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".heic", ".bmp", ".svg",
               ".mp4", ".m4v", ".mov", ".webm", ".mp3", ".wav"}


async def upload_resume(scope, resume_path):
    """Set the resume on the first file input under `scope` that isn't an
    image/video-only (photo, chat widget) field.

    File inputs are often hidden (display:none) behind a custom button, so we
    don't filter by visibility — set_input_files works on hidden inputs.
    Returns True if a file input was found and set.
    """
    count = await scope.locator("input[type=file]").count()
    print(f"    [upload] found {count} file input(s)")
    for i in range(count):
        handle = scope.locator("input[type=file]").nth(i)
        try:
            if is_media_only(await handle.get_attribute("accept")):
                print(f"    [upload] input #{i} is image/video-only; skipped")
                continue
            await handle.set_input_files(resume_path)
            print(f"    [upload] set file on input #{i}")
            return True
        except Exception as e:
            print(f"    [upload] input #{i} failed: {e}")
            continue
    return False


# JS: mark the one "Add" button of each empty Website/Portfolio section. A
# section is the nearest ancestor (up to 3 levels) of its heading that holds
# an Add button; it's skipped if it already has a field (the heading labels a
# real input, or the ancestor is wider than one section) or several Adds.
_MARK_WEBSITE_ADD_JS = """els => {
    let n = 0;
    for (const h of els) {
        const text = (h.innerText || '').trim();
        if (text.length > 80 || !/\\b(websites?|portfolio)\\b/i.test(text)) continue;
        let box = h.parentElement;
        for (let i = 0; box && i < 3; i++, box = box.parentElement) {
            // Never a form's submit button: clicking one could send the application.
            const adds = [...box.querySelectorAll('button')].filter(b =>
                !(b.form && b.type === 'submit')
                && /^\\+?\\s*add\\b/i.test((b.innerText || '').trim())
                && (b.innerText || '').trim().length < 30);
            if (!adds.length) continue;
            if (adds.length === 1 && !box.querySelector('input:not([type=hidden]), textarea')) {
                adds[0].setAttribute('data-cmm-add-website', '');
                n++;
            }
            break;
        }
    }
    return n;
}"""


async def open_website_entry(scope):
    """Click Add in an empty Website/Portfolio section, so fill_form can put
    profile.website in the URL field it reveals. One click per section, no
    waiting: a page without such a section costs one round-trip. No-op
    without a configured website."""
    if not config.PROFILE.get("website"):
        return
    try:
        marked = await scope.locator("h1, h2, h3, h4, h5, h6, legend, label").evaluate_all(
            _MARK_WEBSITE_ADD_JS)
    except Exception:
        return
    if not marked:
        return
    buttons = scope.locator("[data-cmm-add-website]")
    for i in range(await buttons.count()):
        try:
            await buttons.nth(i).click(timeout=3000)
        except Exception:
            print("    Couldn't click Add under Website/Portfolio; leaving it.")
    try:
        await buttons.evaluate_all("els => els.forEach(e => e.removeAttribute('data-cmm-add-website'))")
    except Exception:
        pass


def pause_for_manual_action(message):
    """Block the terminal for a manual action in the browser (e.g. signing in)."""
    print(f"\n  >> {message}")
    input("  >> Press Enter once done...")


async def should_submit():
    return config.SUBMIT_APPLICATION


async def find_submit_button(scope):
    """Locate the final submit/apply button without clicking it."""
    candidates = [
        "button[type=submit]",
        "button:has-text('Submit application')",
        "button:has-text('Submit Application')",
        "button:has-text('Submit')",
        "button:has-text('Apply')",
        "input[type=submit]",
    ]
    for sel in candidates:
        loc = scope.locator(sel).first
        try:
            if await loc.count() and await loc.is_visible():
                return loc
        except Exception:
            continue
    return None
