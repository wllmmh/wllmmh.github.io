"""Workable (jobs.workable.com, apply.workable.com) adapter.

The form has an "Import resume from" dropdown; its "My computer" option holds a
hidden file input that parses the resume into the form (name, email, phone,
summary) and sets the Resume field. We use it, then fill the rest via generic.
"""

from adapters import common, generic

NAME = "workable"


async def _import_resume(page, resume_path):
    button = page.locator("[data-ui=autofill-button] button").first
    try:
        await button.click(timeout=10000)
        await page.locator("input[type=file][data-ui=autofill-computer]").set_input_files(resume_path)
        print("    [upload] resume imported via 'Import resume from'")
    except Exception as e:
        print(f"    (Import resume from failed: {e})")


async def apply(page, resume_path, job_text="", company="", job_description=""):
    await common.open_apply_link(page)  # the posting page's "Apply now"; no-op on the form
    await _import_resume(page, resume_path)
    # The import parses into the form ~2s later, overwriting anything filled before.
    return await generic.apply(page, resume_path, job_text=job_text, company=company,
                               job_description=job_description, upload_settle_ms=3000)
