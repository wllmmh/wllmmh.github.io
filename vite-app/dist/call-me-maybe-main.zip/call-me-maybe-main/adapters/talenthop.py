"""TalentHop (talenthop.com/apply-with-ai/...) adapter.

TalentHop is an aggregator. "Apply Now" opens a menu, or a sign-up dialog when
logged out, which we switch to "Log In" and fill with talenthop_login /
talenthop_password from config.toml [profile]. The menu's "Proceed to Application"
opens the real posting in a new tab; we load it in this tab instead (like
common.open_apply_link) and hand off to that board's adapter.
"""

import re

import adapters
from adapters import common
from config import PROFILE

NAME = "talenthop"

_PROCEED = "[data-testid=apply-now-proceed]"


async def _open_apply_menu(page):
    await page.locator("button").filter(has_text=re.compile(r"^\s*Apply Now\s*$")).filter(visible=True).first.click()


async def _log_in(page):
    """Fill the login dialog that "Apply Now" shows when logged out."""
    dialog = page.locator("[role=dialog]").filter(visible=True).first
    await dialog.get_by_role("button", name="Log In", exact=True).click()
    login, password = PROFILE.get("talenthop_login"), PROFILE.get("talenthop_password")
    if not (login and password):
        common.pause_for_manual_action("Set talenthop_login/talenthop_password in config.toml [profile], or log in to TalentHop now.")
    else:
        await dialog.locator("input[name=email]").fill(login)
        await dialog.locator("input[name=password]").fill(password)
        await dialog.locator("button[type=submit]").click()
    await dialog.wait_for(state="hidden", timeout=15000)
    print("  Logged in to TalentHop.")


async def _proceed(page):
    """Apply Now -> (log in, Apply Now again) -> Proceed to Application; load the
    posting in this tab."""
    await _open_apply_menu(page)
    proceed = page.locator(_PROCEED)
    dialog = page.locator("[role=dialog]").filter(visible=True)
    await proceed.or_(dialog).first.wait_for(timeout=10000)
    if not await proceed.is_visible():
        await _log_in(page)
        await _open_apply_menu(page)
    async with page.context.expect_page(timeout=10000) as popup_info:
        await proceed.click()
    popup = await popup_info.value
    await popup.wait_for_url(re.compile(r"^https?://"), timeout=15000)  # opens as about:blank
    url = popup.url
    await popup.close()
    print(f"  Proceeding to {url}")
    await page.goto(url, timeout=30000)
    await page.wait_for_load_state("domcontentloaded", timeout=10000)


async def apply(page, resume_path, job_text="", company="", job_description=""):
    await _proceed(page)
    adapter = adapters.pick_adapter(page.url)
    # Same as fill.apply_to: the destination may itself be a listing page.
    if adapter is adapters.generic and await common.open_apply_link(page):
        adapter = adapters.pick_adapter(page.url)
    print(f"  Now at {page.url}\n  Board: {adapter.NAME}")
    return await adapter.apply(page, resume_path, job_text=job_text, company=company,
                               job_description=job_description)
