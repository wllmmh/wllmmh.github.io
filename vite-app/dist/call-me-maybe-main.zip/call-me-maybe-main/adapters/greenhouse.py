"""Greenhouse (job-boards.greenhouse.io) adapter.

Greenhouse application pages are a single long form. Newer boards embed the
form directly; older ones use an #grnhse_iframe. We locate the form scope,
fill it heuristically, and upload the resume.
"""

import filler
from adapters import common

NAME = "greenhouse"


async def get_form_scope(page):
    """Return the locator/frame containing the application form."""
    from playwright.async_api import TimeoutError as PlaywrightTimeoutError
    try:
        await page.locator("#grnhse_iframe").wait_for(state="attached", timeout=1000)
        frame = page.frame_locator("#grnhse_iframe")
        await frame.locator("form").wait_for(state="attached", timeout=1000)
        return frame
    except PlaywrightTimeoutError:
        pass
    except Exception:
        pass
    return page


async def apply(page, resume_path, job_text="", company="", job_description=""):
    from config import PROFILE
    scope = await get_form_scope(page)

    # candidate-location is a search autocomplete (type to filter a remote list,
    # then pick) so it goes through autocomplete_ids. country is a plain select
    # dropdown -- it's handled by fill_form's normal dropdown path (click open +
    # keyboard select), no typing/searching needed. Pass page so suggestions
    # rendered outside the iframe are still reachable.
    result = await filler.fill_form(
        scope, job_text=job_text, company=company, page=page,
        job_description=job_description,
        autocomplete_ids={
            "candidate-location": PROFILE["city"],
        },
    )

    uploaded = await common.upload_resume(scope, resume_path)
    result["resume_uploaded"] = uploaded
    return result
