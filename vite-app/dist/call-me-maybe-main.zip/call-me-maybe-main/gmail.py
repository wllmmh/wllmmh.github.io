"""Read Workday account emails from Gmail in a browser tab.

Workday makes you create an account per employer, and may ask you to verify
it or (after a lockout) reset its password by email. This opens (or reuses) a
Gmail tab in the same browser, waits for you to sign in there if needed, then
watches the inbox (no search) for mail that arrived after the trigger. A new
message is opened, and its body read, only if its subject and sender mark it
as that kind of Workday account email. No Gmail API or credentials: it's
your own session.
"""

import asyncio
import re
from urllib.parse import urlparse

INBOX_URL = "https://mail.google.com/mail/u/0/"
_ROW = "[role=main] tr.zA"   # a message row in Gmail's list view
_BODY = "div.a3s"            # an opened message's body

# Per inbox row: thread id plus newest-message time (a reply to a thread
# keeps the id), subject, and sender name/address. textContent, because
# Gmail's rows report an empty innerText.
_ROWS_JS = """rs => rs.map(r => {
    const id = r.querySelector('[data-legacy-thread-id]');
    const when = r.querySelector('td.xW span[title]');
    const from = r.querySelector('[email]');
    return {
        key: (id ? id.getAttribute('data-legacy-thread-id') : '') + '|' + (when ? when.title : ''),
        subject: ((r.querySelector('.bog') || {}).textContent || '').trim(),
        sender: from ? (from.getAttribute('name') || '') + ' ' + from.getAttribute('email') : '',
    };
})"""

_KIND_SUBJECT = {
    "verify": re.compile(r"verif|confirm|activat|\bcode\b|create your .*account", re.I),
    "reset": re.compile(r"reset.*password|password.*reset", re.I),
}

# Path markers of the link each kind of email carries, on a Workday host.
_KIND_LINK = {
    "verify": ("activate", "verif", "confirm"),
    "reset": ("passwordreset",),
}

# "code is 482913" / "Code: AB12CD", or "482913 is your ... code". The code
# must sit next to the keyword so a requisition id or year isn't taken.
_CODE_AFTER = re.compile(r"\bcode\b\W{0,3}(?:is\W{0,3})?([A-Z0-9]{4,8})\b", re.I)
_CODE_BEFORE = re.compile(r"\b([A-Z0-9]{4,8})\W{1,3}is your\b[^.]{0,40}\bcode\b", re.I)


def extract_code(text):
    for pattern in (_CODE_AFTER, _CODE_BEFORE):
        for m in pattern.finditer(text or ""):
            if any(c.isdigit() for c in m[1]):
                return m[1]
    return None


def subject_matches(subject, kind, sender="", tenant=""):
    """True if a message is a Workday account email of `kind` ("verify" or
    "reset"): the subject says so, and it's from Workday -- "workday" or
    "candidate" in the subject/sender, or the sender is the tenant (Workday
    sends as e.g. "salesforce")."""
    text = f"{subject} {sender}".lower()
    workday = ("workday" in text or "candidate" in text
               or bool(tenant) and tenant.lower() in (sender or "").lower())
    return workday and bool(_KIND_SUBJECT[kind].search(subject or ""))


def extract_link(links, kind, host=None):
    """The verification or password-reset link among an email's links: on a
    myworkday(jobs).com host (or `host`, the application's own site), with
    the kind's path marker."""
    for href in links:
        u = urlparse(href)
        h = u.hostname or ""
        if ("myworkday" in h or (host and h == host)) and any(m in u.path.lower() for m in _KIND_LINK[kind]):
            return href
    return None


async def open_inbox(near, timeout_s=600):
    """Return a signed-in Gmail tab, reusing an open one or opening one beside
    page `near`. If Gmail shows a sign-in page, waits (polling) for you to
    finish signing in there."""
    from adapters.common import new_tab
    page = next((p for p in near.context.pages if p.url.startswith(INBOX_URL)), None)
    if page is None:
        page = await new_tab(near, INBOX_URL)
    told = False
    for _ in range(timeout_s):
        if page.url.startswith(INBOX_URL):
            try:
                await page.locator("[role=main]").first.wait_for(timeout=1000)
                return page
            except Exception:
                pass
        elif not told:
            print("  >> Sign in to Gmail in the new tab; waiting...")
            await page.bring_to_front()
            told = True
        await asyncio.sleep(1)
    raise TimeoutError("Gmail sign-in not completed")


async def _rows(page):
    """The inbox's visible rows (newest first) as dicts from _ROWS_JS."""
    if not page.url.startswith(INBOX_URL + "#inbox"):
        await page.goto(INBOX_URL + "#inbox")
    rows = page.locator(_ROW).filter(visible=True)
    try:
        await rows.first.wait_for(timeout=20000)
        return await rows.evaluate_all(_ROWS_JS)
    except Exception:
        return []


async def inbox_snapshot(page):
    """Keys of the messages in the inbox now. Take it before triggering the
    email and pass it to wait_for_email, so only newer mail is considered."""
    return {r["key"] for r in await _rows(page)}


async def _refresh(page):
    try:
        await page.locator("[aria-label=Refresh]").filter(visible=True).first.click(timeout=2000)
    except Exception:
        await page.reload()


async def wait_for_email(page, before, kind, tenant="", timeout_s=180, host=None):
    """Watch the inbox for a new Workday account email of `kind` and return
    {"code": ..., "link": ...} (either may be None). Only new messages whose
    subject/sender match (subject_matches) are opened; a code in the subject
    is used without opening it."""
    seen = set(before)
    deadline = asyncio.get_event_loop().time() + timeout_s
    while asyncio.get_event_loop().time() < deadline:
        for row in await _rows(page):
            if row["key"] in seen:
                continue
            seen.add(row["key"])
            subject = row["subject"]
            if not subject_matches(subject, kind, row["sender"], tenant):
                continue
            code = extract_code(subject) if kind == "verify" else None
            if code:
                return {"code": code, "link": None}
            found = await _open(page, row["key"], kind, host)
            if found["code"] or found["link"]:
                return found
            print(f"  Email {subject!r} had no {kind} code or link.")
        await asyncio.sleep(5)
        await _refresh(page)
    raise TimeoutError(f"No Workday {kind} email within {timeout_s}s")


async def _open(page, key, kind, host=None):
    """Open the message with this key, read its newest message, go back.
    Opens it by URL (#inbox/<thread id>, what clicking the row does): a Gmail
    window that isn't painting never lets a real click settle."""
    thread_id = key.split("|")[0]
    await page.goto(f"{INBOX_URL}#inbox/{thread_id}")
    body = page.locator(_BODY).last
    await body.wait_for(state="attached", timeout=15000)
    text = await body.text_content() or ""
    links = await body.locator("a[href]").evaluate_all("as => as.map(a => a.href)")
    await page.goto(INBOX_URL + "#inbox")
    return {"code": extract_code(text) if kind == "verify" else None,
            "link": extract_link(links, kind, host)}
