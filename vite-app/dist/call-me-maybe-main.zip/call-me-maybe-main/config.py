"""Configuration for call-me-maybe.

Loads config.toml (edit that, not this) and exposes each key in UPPERCASE,
e.g. submit_application -> config.SUBMIT_APPLICATION. Also loads your details
from profile.toml as PROFILE ([profile]) and EEO ([eeo]).
"""

import os
import tomllib

_ROOT = os.path.dirname(os.path.abspath(__file__))

# config.toml and profile.toml are personal and gitignored, so they may not
# exist: scrape.py, view.py and the tests run on config.example.toml
# and an empty profile; fill.py refuses to run without both.
CONFIG_PATH = os.path.join(_ROOT, "config.toml")
_config_file = CONFIG_PATH if os.path.exists(CONFIG_PATH) else os.path.join(_ROOT, "config.example.toml")
with open(_config_file, "rb") as _f:
    globals().update({k.upper(): v for k, v in tomllib.load(_f).items()})

PROFILE_PATH = os.path.join(_ROOT, "profile.toml")
try:
    with open(PROFILE_PATH, "rb") as _f:
        _profile = tomllib.load(_f)
except FileNotFoundError:
    _profile = {}
PROFILE = _profile.get("profile", {})
EEO = _profile.get("eeo", {})
