"""Configuration for call-me-maybe.

Loads config.toml (edit that, not this), one section per script:
[fill] and [browser] keys are exposed in UPPERCASE, e.g.
submit_application -> config.SUBMIT_APPLICATION, cdp_url -> config.CDP_URL
([fill.screening] is config.SCREENING). [scrape] is the config.SCRAPE dict.
[profile] and [eeo] are config.PROFILE and config.EEO.
"""

import os
import tomllib

_ROOT = os.path.dirname(os.path.abspath(__file__))

# config.toml is personal and gitignored, so it may not exist: scrape.py,
# view.py and the tests run on config.example.toml and an empty profile;
# fill.py refuses to run without it.
CONFIG_PATH = os.path.join(_ROOT, "config.toml")
_has_config = os.path.exists(CONFIG_PATH)
with open(CONFIG_PATH if _has_config else os.path.join(_ROOT, "config.example.toml"), "rb") as _f:
    _config = tomllib.load(_f)

globals().update({k.upper(): v for k, v in {**_config["fill"], **_config["browser"]}.items()})
SCRAPE = _config["scrape"]
# The example's placeholder details must never be filled into a real form.
PROFILE = _config.get("profile", {}) if _has_config else {}
EEO = _config.get("eeo", {}) if _has_config else {}
