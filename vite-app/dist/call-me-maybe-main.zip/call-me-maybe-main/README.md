# Call Me Maybe ☎️

Automated job-application autofiller. Open job applications in your browser,
run `python fill.py`, and it fills every open tab: picks the right resume for
the job, fills the form from your profile and config, uploads the resume, and
either stops before the final submit (**do-not-send mode**) or submits for you.

Built on Playwright, driving a real Chrome or Brave with only the WebDriver
flag masked, which holds up well against bot detection.

Supports **Greenhouse** (`job-boards.greenhouse.io`), **Ashby**
(`jobs.ashbyhq.com`), **Workday** (`myworkdayjobs.com`), **Dayforce**
(`dayforcehcm.com`), **Workable** (`workable.com`), the **TalentHop**
aggregator (`talenthop.com`), and a generic fallback for any other board
(including careers sites and aggregators, whose Apply link it follows to the
real form).

## ✨ Features

### 🎯 Heuristic form filling
Reads each field's label, `name`, `id`, `placeholder`, and `aria-label` to
work out what it's asking for, then fills it from your profile. No per-form
configuration needed for standard fields.

### 📄 Keyword-based resume selection
Matches the job title against `resume_rules` in `config.toml` (first rule
wins): keywords like `ai` / `agent` pick your AI resume, `react` / `frontend`
your frontend resume. If the title matches nothing, it uses the rule the job
description mentions most (at least 3 times). Otherwise `default_resume`.

### 📝 Cover-letter & free-text answers
Fills cover-letter boxes from `cover_letter_default` (with `{company}`
substituted) or a matching `cover_letter_rules` template, and "Why do you
want to work here?" boxes from `why_interested_default` (the cover letter if
that's empty).

### 💬 Screening questions
Answers "Have you worked with X?" with Yes when X appears in the chosen
resume's text (otherwise leaves it for you), "Have you worked for us before?"
from `previous_employers`, salary from the top of a range in the job
description (else `base_salary`), and the yes/no questions in `[screening]`.

### 🧑‍⚖️ EEO / demographic questions
Answers the standard race / gender / veteran / disability / work-authorization
questions from the `[eeo]` table in `profile.toml`.

### 🛑 Do-not-send mode
`submit_application = false` fills everything but never clicks the final
submit button, so you can review before sending.

### ✋ Manual-fill pause
With `manual_fill_pause = true`, once a form is filled it lists the fields it
couldn't map and pauses so you can type them in the browser, then press Enter
to continue. (With it off, unknown fields are just logged.)

### ✅ Required-field guard & run artifacts
Before submitting, it flags any empty *required* field (and pauses or
refuses). With `dry_run_screenshot = true` it saves a screenshot and the page
HTML of each filled form to `applications/<timestamp>-<board>/`.

### 📒 Applications log & dedupe
Every attempt is recorded to `applications/log.csv` (URL, company, title,
resume, status, timestamp). Jobs already **submitted** are skipped on re-run.

### 🔒 Accounts & sign-in
Workday needs an account per employer. It signs in, or creates the account,
with `email` and `workday_password` from `profile.toml`, and walks every page
of the application. A failed sign-in leads to Create Account, then (if the
account exists) a password reset. Verification codes and links, and reset
links, are read from Gmail in a tab of the same browser (you sign in to Gmail
there once). Each step is tried once per run; anything else pauses for you.

On other boards, the generic adapter fills a sign-in / create-account page
once per run with the same `email` and `workday_password`, taking a
verification code or link from Gmail if asked. TalentHop logs in with
`talenthop_login` / `talenthop_password`.

## 🏗️ Architecture

See [ARCHITECTURE.md](ARCHITECTURE.md). Rules for AI coding agents are in
[AGENTS.md](AGENTS.md); open bugs and test URLs are in [TODO.md](TODO.md).

## ⚙️ Setup

1. Install dependencies:
   ```
   pip install -r requirements.txt
   playwright install chrome
   ```
   Also install `pdftotext` (poppler-utils) to answer skill questions from
   your resume. Without it, those questions are left for you.
2. Add your resume PDFs to `resumes/` (they're gitignored).
3. Copy `profile.example.toml` to `profile.toml` (gitignored) and fill in
   `[profile]` (including `workday_password` for site accounts,
   `talenthop_login` / `talenthop_password` if you use TalentHop, and
   `years_of_experience`) and review the `[eeo]` answers.
4. Copy `config.example.toml` to `config.toml` (gitignored) and edit it:
   write your cover letter and `why_interested_default`, map `resume_rules`
   to your PDF filenames, set
   `default_resume`, and pick `browser` (`"chrome"`, or `"brave"` with
   `brave_path`).

On Windows, follow the steps below instead.

### 🪟 Windows, step by step

No coding needed. You'll type a few commands into a terminal window: copy
each one, right-click in the window to paste it, and press Enter.

1. **Install Python.** Download it from
   [python.org/downloads](https://www.python.org/downloads/) and run the
   installer. On its first screen, tick **Add python.exe to PATH**, then click
   **Install Now**.
2. **Install [Brave](https://brave.com/download/).** The script opens and
   works in its own Brave window.
3. **Get the code.** On this project's GitHub page, click **Code → Download
   ZIP**. Right-click the downloaded ZIP → **Extract All**.
4. **Open a terminal in that folder.** In File Explorer, open the extracted
   folder (the one with `fill.py` in it), right-click an empty spot and choose
   **Open in Terminal**. On Windows 10, hold Shift while right-clicking and
   choose **Open PowerShell window here**.
5. **Install what it needs:**
   ```
   py -m pip install -r requirements.txt
   ```
6. **Add your resumes.** Copy your resume PDFs into the `resumes` folder.
7. **Enter your details:**
   ```
   copy profile.example.toml profile.toml
   notepad profile.toml
   ```
   Replace the sample values with your own, then save. Text goes inside the
   quotes; `true`, `false` and numbers have no quotes. This file holds your
   personal info and password, so don't share it.
8. **Adjust the settings:**
   ```
   copy config.example.toml config.toml
   notepad config.toml
   ```
   - In `resume_rules` and `default_resume`, change the file names to match
     your PDFs exactly.
   - Set `brave_path` to where Brave is installed. It's usually
     `'C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe'`.
     If it isn't there, right-click Brave in the Start menu → **Open file
     location**, right-click the shortcut → **Properties**, and copy
     **Target** (without its double quotes). Paste the path between single
     quotes like the example, so the backslashes are kept.
   - Write your own `cover_letter_default` and `why_interested_default`.
   - Leave `submit_application = false` until you trust it. It then fills each
     form and waits for you to check it and click submit yourself.

To use it, open a terminal in the folder (step 4) each time, then:

1. Run `py fill.py`. The first time, it opens a new Brave window and reports
   no application tabs. Keep that window open and do your job hunting in it.
   If you'll apply on Workday, sign in to Gmail there once.
2. Open each job application in its own tab in that window.
3. Run `py fill.py` again. It fills the tabs one at a time. When it stops
   and asks, finish or check the form in Brave, then click back into the
   terminal and press Enter. Press Ctrl+C to stop early.

To collect jobs from a LinkedIn search first, run `py scrape.py`, then
`py view.py` to browse them (both described below). Questions like
"Have you worked with React?" are left for you to answer, because answering
them needs `pdftotext`, which is hard to install on Windows.

## 🚀 Usage

Open the job applications you want in the remote-debugging browser (see
below, or use `python view.py`), then:

```
python fill.py [--stealth]
```

It fills every open tab in place, one at a time, skipping LinkedIn, Gmail and
the results page. If no browser is listening at `cdp_url` it starts one;
`--stealth` starts it with `stealth_args` instead of `standard_args` from
`config.toml` (same as `stealth_mode = "stealth"`).

With `submit_application = false` (the default) it pauses on each filled form
so you can review and submit it yourself. Set `submit_application = true` in
`config.toml` to have it click submit for you.

### 🔎 Collect LinkedIn search results (no applying)

```
python scrape.py
```

Clicks through a LinkedIn job search and saves each job that passes the
filters (ID, title, location, work type, employer, logo, age, applicant
count, Easy Apply) to `strict-search-results/<keywords>_<date>_<time>.csv`. It never
applies. Keywords, filters (max applicants, max age, work type, excluded title
words), start page and page limit are set in `scrape.toml`. With
`new_search = false` it starts on the LinkedIn search-results tab you already
have open (its filters and page) instead of opening a new search. Within a run,
duplicates (same ID, or same employer and title) are skipped, as are jobs you
deleted in the results page.

It attaches to the browser already listening at `cdp_url`
(`http://localhost:9222`). If there isn't one, it starts Brave or Chrome (per
`browser` in `config.toml`) with remote debugging on that port and a separate
profile (`~/.config/brave-strict-search` or `~/.config/chrome-strict-search`),
then waits for you to log in to LinkedIn. The profile keeps you logged in for
later runs; recent Chrome refuses remote debugging on your default profile,
hence the separate one. It opens its own tab and leaves the browser open when
it finishes.

To start the browser yourself instead:

```
brave-browser --remote-debugging-port=9222 --user-data-dir="$HOME/.config/brave-strict-search"
google-chrome --remote-debugging-port=9222 --user-data-dir="$HOME/.config/chrome-strict-search"
```

### 📋 Browse the results

```
python view.py
```

Serves a page listing every results CSV and opens it as a tab in the
remote-debugging browser, so the jobs you open from it are ready for
`fill.py`. Deleting a job there removes it from the CSVs, and later
`scrape.py` runs skip it.

## 🧪 Tests

```
python -m pytest tests -q
```
