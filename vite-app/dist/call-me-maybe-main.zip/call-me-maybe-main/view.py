"""Serve search-results-view.html and a small JSON API over the jobstore, and open it in the browser.

The page opens as a tab in the remote-debugging browser at cdp_url
(config.toml), started if it isn't running, so jobs opened from it land
where fill.py can fill them. Only the page and /api/ are served, so the rest
of the repo (config.toml) stays private.
"""
import asyncio
import http.server
import json
import os
import posixpath
import re
import threading
import time
import webbrowser
from urllib.parse import parse_qs, unquote, urlparse

import config
import jobstore

# Playwright's bundled Node driver calls url.parse() on connect_over_cdp; hide its DEP0169 warning.
os.environ["NODE_OPTIONS"] = (os.environ.get("NODE_OPTIONS", "") + " --disable-warning=DEP0169").strip()

ROOT = os.path.dirname(os.path.abspath(__file__))
PAGE = "/search-results-view.html"
ACTIONS = {
    "delete": jobstore.delete_job,
    "restore": jobstore.restore_job,
    "applied": jobstore.set_applied,
}


class Handler(http.server.SimpleHTTPRequestHandler):
    # Windows takes these from the registry, where .html can be something else.
    extensions_map = {**http.server.SimpleHTTPRequestHandler.extensions_map,
                      ".html": "text/html", ".json": "application/json"}

    def __init__(self, *args, **kw):
        super().__init__(*args, directory=ROOT, **kw)

    def send_json(self, body):
        data = json.dumps(body).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        url = urlparse(self.path)
        path = posixpath.normpath(unquote(url.path))  # resolves any ".."
        if "\\" in path:  # a Windows path separator normpath doesn't resolve
            self.send_error(404)
        elif path == "/":
            self.send_response(302)
            self.send_header("Location", PAGE)
            self.end_headers()
        elif path == "/api/jobs":
            deleted = parse_qs(url.query).get("deleted") == ["1"]
            conn = jobstore.connect()
            try:
                self.send_json(jobstore.list_jobs(conn, deleted))
            finally:
                conn.close()
        elif path == PAGE:
            self.path = path
            super().do_GET()
        else:
            self.send_error(404)

    do_HEAD = do_GET

    def do_POST(self):
        # Requiring application/json makes browsers preflight cross-site posts, which we never answer.
        action = ACTIONS.get(posixpath.basename(self.path))
        if (not action or posixpath.dirname(self.path) != "/api"
                or self.headers.get("Content-Type") != "application/json"):
            return self.send_error(404)
        try:
            body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            job_id = str(body["job_id"])
            args = [bool(body["applied"])] if action is jobstore.set_applied else []
        except (ValueError, KeyError, TypeError):
            return self.send_error(400)
        if not re.fullmatch(r"\d+", job_id):
            return self.send_error(400)
        conn = jobstore.connect()
        try:
            changed = action(conn, job_id, *args)
        finally:
            conn.close()
        if not changed:
            return self.send_error(404, "no such job")
        self.send_response(204)
        self.end_headers()

    def log_message(self, *args):
        pass


async def open_in_debug_browser(url):
    """Open url in a new tab of the cdp_url browser, starting it if needed.
    The browser outlives this script."""
    from playwright.async_api import async_playwright
    from adapters.common import new_tab
    from browser import attach_browser
    async with async_playwright() as p:
        browser, _ = await attach_browser(p, config.CDP_URL)
        context = browser.contexts[0]
        # A tab beside an existing one (not the Gmail tab), not a new window.
        near = [pg for pg in context.pages if "mail.google.com" not in pg.url] or context.pages
        if near:
            page = await new_tab(near[-1], url)
        else:
            page = await context.new_page()
            await page.goto(url)
        await page.bring_to_front()


if __name__ == "__main__":
    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    url = f"http://127.0.0.1:{server.server_port}{PAGE}"
    print(f"Serving {url} (Ctrl+C to stop)")
    threading.Thread(target=server.serve_forever, daemon=True).start()
    try:
        asyncio.run(open_in_debug_browser(url))
    except (Exception, SystemExit) as e:  # attach_browser sys.exit()s when it can't start one
        print(f"Couldn't open it in the debug browser ({e}); opening the default browser.")
        webbrowser.open(url)
    try:
        while True:
            time.sleep(1)  # unlike Event().wait(), Ctrl+C interrupts this on Windows
    except KeyboardInterrupt:
        pass
