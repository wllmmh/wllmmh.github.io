const g=(e,...t)=>chrome.i18n.getMessage(e,t.map(String));export{g as t};
