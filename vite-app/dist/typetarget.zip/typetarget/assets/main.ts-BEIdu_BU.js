import{i}from"./bridge-BautBPhx.js";import"./messages-DzAIXD04.js";import"./elapsed-D2T7e2sX.js";import"./i18n-BZ88W2hT.js";i();
