import{i}from"./bridge-CQlBQADI.js";import"./messages-CeBbd93q.js";import"./elapsed-D2T7e2sX.js";import"./i18n-BZ88W2hT.js";i();
